# Contrats d'interface — Plugin IDz ↔ Jenkins et GitLab

Ce document est la **référence exhaustive des échanges** entre le plugin IDz et les systèmes externes (Jenkins FabCI et GitLab). Pour chaque fonction du plugin, il décrit précisément :
- Ce que le plugin lit en local
- L'appel HTTP exact émis
- Ce que le système externe renvoie
- Comment le plugin traite la réponse
- Les effets de bord visibles dans IDz

---

## Conventions

### Authentification Jenkins (toutes les fonctions Jenkins)
```
Header : Authorization: Basic <credentials>
credentials = Base64("<login_windows>@id.fr.cly:<token_jenkins>")
```
- `login_windows` : `System.getProperty("user.name")` — déduit automatiquement
- `token_jenkins` : lu depuis le Secure Storage Eclipse au nœud `<toolchain>/fr.lcl.zdevops.jenkins.auth/jenkins_token`

### Authentification GitLab (toutes les fonctions GitLab)
```
JGit (clone/push/pull) : UsernamePasswordCredentialsProvider("<login_windows>", "<token_gitlab>")
API REST (gitlab4j)    : GitLabApi("<gitlab_base_url>", "<token_gitlab>")
```
- `token_gitlab` : lu depuis le Secure Storage Eclipse au nœud `/GIT/https:\2f\2fscm.saas.cagip.group.gca:443`, clé `password` (nœud partagé avec EGit)

---

## Fonctions déclenchant Jenkins

### F8 — Builder (`Ctrl+0`) → pipeline `BuildAndPush`

**Ce que le plugin lit :**
```
IProject actif
→ META-INF/<nom>.mf.json
→ nom du manifest = "da01_correction_bug_42" (nom du fichier sans .mf.json)
```

**Appel HTTP émis :**
```
POST https://<jenkins_url>/job/<JENKINS_PIPELINE_BUILDER>/buildWithParameters
     ?NomManifest=da01_correction_bug_42
Header : Authorization: Basic <credentials>
Body   : (vide)
```
- `<jenkins_url>` : valeur de `jenkins.url.base` dans les properties du toolchain (ex: `https://fabci-prd.ci.lcl.group.gca/api/json` → **noter que l'API JSON est dans l'URL de base** — le plugin construit l'URL en retirant `/api/json`)
- `<JENKINS_PIPELINE_BUILDER>` : valeur de `jenkins.pipeline.build` (ex: `BuildAndPush`)

**Réponse attendue :**
```
HTTP 201 Created
Header Location: https://fabci-prd.ci.lcl.group.gca/queue/item/12345/
```
Si HTTP ≠ 201 → exception `RuntimeException("Échec du lancement du job Jenkins")`

**Phase 1 — Attente du démarrage (polling queue) :**
```
GET https://fabci-prd.ci.lcl.group.gca/queue/item/12345/api/json
→ Répétition toutes les 2 secondes, max 30 tentatives (60 s)
→ Condition de sortie : réponse JSON contient "executable.url"
→ Extrait : buildUrl = response.executable.url
```
Si timeout → `IdzPluginException("Le build n'a pas démarré après 60 secondes")`

**Phase 2 — Surveillance du build (polling build) :**
```
GET <buildUrl>/api/json
→ Répétition toutes les 2 secondes, SANS LIMITE DE TENTATIVES
→ Condition de sortie : response.building == false
```

**Vue Jenkins Browser (Blue Ocean) :**
```
URL calculée :
  <base_url>/blue/organizations/jenkins/BuildAndPush/detail/BuildAndPush/<num>/pipeline/
  
Exemple :
  https://fabci-prd.ci.lcl.group.gca/blue/organizations/jenkins/BuildAndPush/detail/BuildAndPush/42/pipeline/
```
Vue ouverte dès que `buildUrl` est disponible. Affichée dans la vue IDz (pas maximisée).

**Résultat affiché :**
- SUCCESS → log info
- FAILURE → `StatusManager.handle(Status.ERROR, ...)`

**Paramètre unique envoyé à Jenkins :**
| Nom | Type | Exemple | Source |
|---|---|---|---|
| `NomManifest` | String | `da01_correction_bug_42` | Nom du fichier `.mf.json` sans extension |

---

### F9 — Déployer (`Ctrl+B`) → pipeline `ProxyCD`

**Identique à F8, sauf :**

| Différence | Valeur |
|---|---|
| Pipeline | `ProxyCD` (valeur de `jenkins.pipeline.deploy`) |
| Vue Blue Ocean | Ouverte en mode **MAXIMISÉ** (`IWorkbenchPage.STATE_MAXIMIZED`) |

**Appel HTTP émis :**
```
POST https://<jenkins_url>/job/ProxyCD/buildWithParameters
     ?NomManifest=da01_correction_bug_42
```

**Paramètre unique envoyé à Jenkins :**
| Nom | Type | Exemple | Source |
|---|---|---|---|
| `NomManifest` | String | `da01_correction_bug_42` | Nom du fichier `.mf.json` sans extension |

---

### F10 — Audit (`Ctrl+6`) → pipeline `auditEtQualite`

**Identique à F8, sauf :**

| Différence | Valeur |
|---|---|
| Pipeline | `auditEtQualite` (valeur de `jenkins.pipeline.audit.qualite`) |
| Vue Blue Ocean | Ouverte normalement (pas maximisée) |

**Appel HTTP émis :**
```
POST https://<jenkins_url>/job/auditEtQualite/buildWithParameters
     ?NomManifest=da01_correction_bug_42
```

**Paramètre unique envoyé à Jenkins :**
| Nom | Type | Exemple | Source |
|---|---|---|---|
| `NomManifest` | String | `da01_correction_bug_42` | Nom du fichier `.mf.json` sans extension |

**Prérequis côté Jenkins (non vérifié par le plugin) :**
Le descripteur `da01_correction_bug_42.desc.json` doit exister dans Artifactory scratch. S'il n'existe pas, le pipeline Jenkins échoue avec une erreur explicite, mais le plugin voit seulement un build en FAILURE sans message détaillé.

---

### F11 — Promote Unitaire (clic droit) → pipeline `PromoteUnitaire`

**Ce que le plugin lit :**
```
IFile sélectionné (ex: src/CALCUTVA.cbl)
→ nom du répertoire parent : "src"
→ nom du fichier sans extension : "CALCUTVA"
→ META-INF/<nom>.mf.json
   → application_code : "da01"
   → manifest_number  : "20250401-001"
   → application_type : "STD"
```

**Calcul du couloir :**
```
application_type == "STD" → couloir = "STDA"
application_type == "CRF" → couloir = "CRFA"
autre                     → couloir = application_type (valeur brute)
```

**Calcul des componentTypes selon le répertoire :**
```
"src"                → ["LOD", "BGB", "DBR"]
"srt"                → ["LOT", "BGT", "DBR"]
tout autre répertoire → [répertoire.toUpperCase()] ex: "asm" → ["ASM"]
```

**Construction du JSON `commande` :**
```json
{
  "appName":       "da01",
  "version":       "20250401-001",
  "site":          "DEV",
  "couloir":       "STDA",
  "environment":   "TU",
  "componentType": ["LOD", "BGB", "DBR"],
  "component":     "CALCUTVA"
}
```
- `site` : valeur de `deploy.site.name` dans les properties du toolchain
- `environment` : toujours `"TU"` (constante fixe dans le code)
- `component` : nom du fichier sans extension, en MAJUSCULES

**Appel HTTP émis :**
```
POST https://<jenkins_url>/job/PromoteUnitaire/buildWithParameters
     ?commande=<JSON_URL_ENCODED>

Exemple décodé :
  commande={"appName":"da01","version":"20250401-001","site":"DEV",
            "couloir":"STDA","environment":"TU",
            "componentType":["LOD","BGB","DBR"],"component":"CALCUTVA"}
```
- Le pipeline utilisé est `PromoteUnitaire` (valeur de `jenkins.pipeline.promote.unitaire`)

**Polling et Blue Ocean :** identique aux autres fonctions Jenkins.

**Paramètre unique envoyé à Jenkins :**
| Nom | Type | Exemple | Description |
|---|---|---|---|
| `commande` | String (JSON URL-encodé) | voir ci-dessus | Objet JSON complet décrivant le composant |

**Schéma complet de l'objet `commande` :**
| Champ JSON | Type | Source plugin | Valeurs possibles |
|---|---|---|---|
| `appName` | String | manifest `.application_code` | ex: `da01`, `dyxz` |
| `version` | String | manifest `.manifest_number` | ex: `20250401-001` |
| `site` | String | `deploy.site.name` (properties) | `DEV` en prd |
| `couloir` | String | déduit de `.application_type` | `STDA`, `CRFA`, ou valeur brute |
| `environment` | String | constante fixe | toujours `TU` |
| `componentType` | Array[String] | déduit du répertoire parent | `["LOD","BGB","DBR"]`, `["ASM"]`, etc. |
| `component` | String | nom du fichier sélectionné sans extension | en MAJUSCULES |

---

### F12 — Clean Unitaire (clic droit) → pipeline `CleanUnitaire`

**Identique à F11, sauf :**

| Différence | Valeur |
|---|---|
| Pipeline | `CleanUnitaire` (valeur **codée en dur** dans `DeployHandler.java`, pas dans les properties) |
| Paramètre | `commande` (même JSON exact qu'en F11) |

**Appel HTTP émis :**
```
POST https://<jenkins_url>/job/CleanUnitaire/buildWithParameters
     ?commande=<JSON_URL_ENCODED>
```

---

## Fonctions interagissant avec GitLab (pas Jenkins)

### F1 — Démarrer une évolution (`Ctrl+1`)

**Interactions GitLab (API REST via gitlab4j) :**

| Étape | Type | Endpoint/Opération | Description |
|---|---|---|---|
| Validation du code | GET | `GET /api/v4/groups/<GITLAB_APP_GROUP_DA_ID>/projects?search=<code>` | Vérifie que le projet existe dans le groupe DA ou DY |
| Chargement branches | GET | `GET /api/v4/projects/<projectId>/repository/branches` | Charge la liste pour la liste déroulante |
| Lecture applications.json | GET | `GET /api/v4/projects/<GITLAB_APP_PARAM_ID>/repository/files/applications.json/raw?ref=master` | Vérifie l'existence du code application |
| Mise à jour applications.json | PUT | `PUT /api/v4/projects/<GITLAB_APP_PARAM_ID>/repository/files/applications.json` | Incrémente `next_artifact_number` |
| Création branche | POST | `POST /api/v4/projects/<projectId>/repository/branches` body: `{branch: "feature_xxx", ref: "master"}` | Crée la branche distante |

**Interactions JGit (opérations locales) :**

| Étape | Opération JGit | Description |
|---|---|---|
| Clone | `Git.cloneRepository().setURI(...).call()` | Clone depuis GitLab sur master |
| Création branche locale | `git.branchCreate().setName("feature_xxx").call()` | Crée la branche localement |
| Checkout | `git.checkout().setName("feature_xxx").call()` | Bascule sur la branche |
| Écriture manifest | Opération fichier Java (`Files.write()`) | Écrit `META-INF/<nom>.mf.json` |
| Commit | `git.add().addFilepattern(".").call()` + `git.commit().setMessage(...).call()` | Commite le manifest |
| Push | `git.push().setCredentialsProvider(PROVIDER).call()` | Pousse la branche vers GitLab |

**Entrées utilisateur → Sortie manifest :**
| Saisie utilisateur | Champ manifest | Exemple |
|---|---|---|
| Code application | `application_code` | `"da01"` |
| Nom évolution | `manifest_name` | `"da01_correction_bug_42"` |
| Description | `description` | `"Correction du calcul TVA"` |
| Type composant (radio) | `component_type` | `"BATCH"` ou `"TP"` |
| — (déduit du code) | `application_type` | `"STD"` (pour `da`) ou `"CRF"` (pour `dy`) |
| — (constante) | `entity` | `"LCL"` |
| — (vide à la création) | `content` | `{}` |
| — (vide à la création) | `dependancies` | `[]` |

---

### F2 — Participer à une évolution (`Ctrl+2`)

**Interactions GitLab (API REST via gitlab4j) :**

| Étape | Opération | Description |
|---|---|---|
| Validation code | GET `/groups/.../projects?search=` | Vérifie l'existence du projet |
| Chargement branches | GET `/projects/<id>/repository/branches` | Liste pour la combo READ_ONLY |
| Lecture manifest sélectionné | GET `/projects/<id>/repository/files/META-INF%2F<manifest>.mf.json/raw?ref=<branche>` | Pré-remplit type et description en lecture seule |

**Différence avec F1 :** pas de création de branche GitLab, pas de mise à jour de `applications.json`.

---

### F5 — Mettre à jour les copybooks (`Ctrl+4`)

**Interactions GitLab (API REST via gitlab4j) :**

| Source | Endpoint | Contenu récupéré |
|---|---|---|
| Copybooks partagées | GET `/projects/<GITLAB_APP_COPYS_PARTAGEES_ID>/repository/files/<fichier>.cpy/raw?ref=master` | Copybooks `.cpy` communs à toutes les applications |
| Copybooks publiées CRFP | GET `/projects/<GITLAB_APP_COPYS_PUBLIEES_CRFP_ID>/repository/files/.../raw?ref=master` | Copybooks publiées pour type CRF |
| Copybooks publiées PUSTD | GET `/projects/<GITLAB_APP_COPYS_PUBLIEES_PUSTD_ID>/repository/files/.../raw?ref=master` | Copybooks publiées pour type STD |
| Copybooks participating | GET `/projects/<id_dep>/repository/files/META-INF%2F<dep>.mf.json/raw?ref=<branche_dep>` | Manifest des dépendances → liste des cpy/dcl/in2 |
| Fichiers cpy des dépendances | GET `/projects/<id_dep>/repository/files/<type>%2F<fichier>/raw?ref=<branche_dep>` | Les fichiers copybooks eux-mêmes |

**Flux de traitement :**
```
1. Lire manifest courant → extraire content (liste des sources .cbl)
2. Lire chaque .cbl → parser COPY <nom> et EXEC SQL INCLUDE <nom>
3. Comparer avec cpy/ dcl/ in2/ internes → identifier les externes
4. Télécharger depuis GitLab copybooks partagées
5. Télécharger depuis GitLab copybooks publiées (selon type d'application)
6. Pour chaque dépendance dans manifest.dependancies :
   a. Lire le manifest de la dépendance dans GitLab
   b. Extraire les fichiers cpy/dcl/in2 du content
   c. Télécharger chaque fichier depuis le dépôt de la dépendance
7. Écrire dans dex_read_only/cpy|dcl|in2/
8. Générer les fichiers de rapport dans META-INF/
```

---

### F6 — Gérer les composants du manifest (`Ctrl+5`)

**Aucun appel externe.** Tout est local :
1. Lire `META-INF/<nom>.mf.json` (Java `Files.readString`)
2. Lister les fichiers du projet sur le disque local
3. Afficher l'arbre avec les cases pré-cochées selon `content`
4. À la validation : réécrire `META-INF/<nom>.mf.json` avec le nouveau `content`

---

### F7 — Gérer les dépendances (`Ctrl+7`)

**Interactions GitLab :**

| Étape | Opération | Description |
|---|---|---|
| Recherche application | GET `/groups/.../projects?search=<code>` | Trouver le projet de l'application dépendante |
| Chargement branches (async) | GET `/projects/<id>/repository/branches` | Dans un Eclipse Job séparé (sans bloquer l'UI) |
| Lecture manifest d'une branche | GET `/projects/<id>/repository/files/META-INF%2F<manifest>.mf.json/raw?ref=<branche>` | Pour obtenir le `manifest_name` à stocker dans `dependancies` |

**Sortie : champ `dependancies` mis à jour dans le manifest local**
```json
"dependancies": ["da02_evolution_partagee", "da03_autre_dep"]
```

---

## Tableau de synthèse global

| Fonction | Raccourci | Système appelé | Protocole | Paramètre principal |
|---|---|---|---|---|
| Démarrer évolution | Ctrl+1 | GitLab | JGit + REST (gitlab4j) | Code app, nom évol, description, type |
| Participer évolution | Ctrl+2 | GitLab | JGit + REST (gitlab4j) | Code app, branche |
| Évol depuis évol | Ctrl+8 | GitLab | JGit + REST (gitlab4j) | Code app, branche source, nom évol |
| Consulter sources | Ctrl+9 | GitLab | JGit | Code app |
| MAJ copybooks | Ctrl+4 | GitLab | REST (gitlab4j) | Projet actif (manifest + sources) |
| Gérer composants | Ctrl+5 | — (local) | Fichier local | Projet actif |
| Gérer dépendances | Ctrl+7 | GitLab | REST (gitlab4j, async) | Code app dépendante |
| Builder | Ctrl+0 | Jenkins | HTTP POST + polling | `NomManifest` |
| Déployer | Ctrl+B | Jenkins | HTTP POST + polling | `NomManifest` |
| Audit | Ctrl+6 | Jenkins | HTTP POST + polling | `NomManifest` |
| Promote Unitaire | Clic droit | Jenkins | HTTP POST + polling | `commande` (JSON) |
| Clean Unitaire | Clic droit | Jenkins | HTTP POST + polling | `commande` (JSON) |
| GitLab Token | Ctrl+E | Equinox Storage | Secure Storage local | Token GitLab |
| Jenkins Token | Ctrl+K | Equinox Storage | Secure Storage local | Token Jenkins |

---

## Codes d'erreur HTTP et comportements

| Code HTTP | Contexte | Comportement du plugin |
|---|---|---|
| 201 | Déclenchement Jenkins réussi | Démarre le polling de la queue |
| 401 | Token Jenkins invalide | `IdzPluginException("Token Jenkins invalide")` |
| 403 | Droits insuffisants Jenkins | Erreur générique |
| 404 | Pipeline Jenkins non trouvé | `IllegalArgumentException("Aucun job Jenkins trouvé")` |
| autre | Toute erreur | `RuntimeException` avec le corps de la réponse |

---

## Limites et comportements à connaître

1. **Pas de timeout global Jenkins** : le polling `isBuildRunning()` n'a pas de limite de tentatives. Un pipeline suspendu bloque le job Eclipse indéfiniment.

2. **Pas de rafraîchissement du PROVIDER JGit** : si le token GitLab est changé via `Ctrl+E` en cours de session, `AppProperties.PROVIDER` n'est pas nécessairement mis à jour — cela dépend de l'implémentation du handler `GitLabTokenHandler`.

3. **`CleanUnitaire` n'est pas dans les properties** : le nom du pipeline `CleanUnitaire` est codé en dur dans `DeployHandler.java`, contrairement à tous les autres pipelines qui lisent leur nom depuis les properties.

4. **URL de base Jenkins** : `jenkins.url.base` contient `/api/json` à la fin (ex: `https://fabci-prd.ci.lcl.group.gca/api/json`). Le plugin extrait la base en supprimant `/api/json` pour construire les URLs Blue Ocean.
