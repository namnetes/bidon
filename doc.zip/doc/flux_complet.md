# Flux complet de développement — du code à la production

Ce document décrit le **parcours complet d'un développeur mainframe** avec la plateforme zDevOps : depuis la décision de modifier du code jusqu'à la mise en production. Chaque étape indique quelle fonction du plugin utiliser, ce que Jenkins fait côté serveur, et quels fichiers sont produits.

> **Prérequis :** avoir configuré ses tokens GitLab (`Ctrl+E`) et Jenkins (`Ctrl+K`), et avoir `zdevops.ini` dans son workspace.

---

## Vue d'ensemble du flux

```
┌──────────────────────────────────────────────────────────────────────────┐
│                         DÉVELOPPEMENT LOCAL (IDz)                        │
├──────────────────────────────────────────────────────────────────────────┤
│ Étape 1  Créer une évolution         → Ctrl+1   (Démarrer une évolution) │
│ Étape 2  Modifier les sources COBOL  → Éditeur IDz                       │
│ Étape 3  Déclarer les composants     → Ctrl+5   (Gérer les composants)   │
│ Étape 4  Mettre à jour les copybooks → Ctrl+4   (MAJ copybooks)          │
│ Étape 5  Déclarer les dépendances    → Ctrl+7   (Gérer les dépendances)  │
│          [optionnel si dépendances]                                       │
├──────────────────────────────────────────────────────────────────────────┤
│                    COMPILATION ET TEST UNITAIRE                           │
├──────────────────────────────────────────────────────────────────────────┤
│ Étape 6  Builder                     → Ctrl+0   (Builder)                │
│          Jenkins : BuildAndPush                                           │
│ Étape 7  Test rapide d'un composant  → Clic droit > Promote Unitaire     │
│          Jenkins : PromoteUnitaire                                        │
│ Étape 8  Nettoyage TU si nécessaire  → Clic droit > Clean Unitaire       │
│          Jenkins : CleanUnitaire                                          │
├──────────────────────────────────────────────────────────────────────────┤
│                    QUALITÉ ET DÉPLOIEMENT                                 │
├──────────────────────────────────────────────────────────────────────────┤
│ Étape 9  Audit qualité               → Ctrl+6   (Audit)                  │
│          Jenkins : auditEtQualite                                         │
│ Étape 10 Déployer                    → Ctrl+B   (Déployer)               │
│          Jenkins : ProxyCD → service CD CAGIP                             │
├──────────────────────────────────────────────────────────────────────────┤
│                    SUIVI JENKINS (vue Blue Ocean dans IDz)                │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## Étape 1 — Créer une évolution (`Ctrl+1`)

**Qui ?** Le développeur qui va commencer une modification sur une application.

**Quoi ?** Le plugin crée une branche `feature_<nom>` dans GitLab, clone le dépôt localement dans IDz, et crée le fichier manifest.

**Comment ?**
1. Appuyer sur `Ctrl+1`
2. Saisir le code de l'application (ex : `da01`)
3. Saisir le nom de l'évolution (ex : `correction_calcul_tva`)
4. Saisir une description
5. Choisir BATCH ou TP
6. Cliquer sur Valider

**Résultat :**
- Branche `feature_correction_calcul_tva` créée dans GitLab
- Dépôt cloné localement dans le workspace Eclipse
- Fichier `META-INF/da01_correction_calcul_tva.mf.json` créé avec un `content` vide

> **Variantes :**
> - Pour rejoindre une évolution existante : `Ctrl+2` (Participer à une évolution)
> - Pour créer depuis une autre évolution : `Ctrl+8`
> - Pour lire le code sans modifier : `Ctrl+9` (Consulter les sources)

---

## Étape 2 — Modifier les sources COBOL

**Qui ?** Le développeur.

**Quoi ?** Éditer les fichiers COBOL (`.cbl`), PL/I (`.pli`), Assembleur (`.asm`), etc. dans l'éditeur IDz normalement, comme pour tout projet Eclipse.

**Où ?** Dans le répertoire approprié du projet :
- `src/` → programmes COBOL BATCH
- `srt/` → programmes COBOL TP (CICS)
- `asm/` → programmes Assembleur
- `srx/` → scripts REXX
- `cpy/` → copybooks internes propres au projet

Les modifications ne sortent pas du poste tant qu'aucun `git push` n'est effectué. Le push se fait via les fonctions du plugin (pas manuellement).

---

## Étape 3 — Déclarer les composants à compiler (`Ctrl+5`)

**Qui ?** Le développeur, après avoir modifié ses sources.

**Quoi ?** Le manifest doit lister explicitement les fichiers à compiler. Un fichier non déclaré ne sera PAS compilé par Jenkins.

**Comment ?**
1. Appuyer sur `Ctrl+5`
2. L'arbre affiche tous les fichiers du projet, organisés par répertoire
3. Cocher les fichiers modifiés (ou nouveaux)
4. Cliquer sur Valider

**Résultat :** Le manifest `META-INF/da01_correction_calcul_tva.mf.json` est mis à jour avec la section `content` :
```json
"content": {
  "src": ["CALCUTVA.cbl", "MONPROG.cbl"],
  "cpy": ["MACOPY.cpy"]
}
```

> **Astuce :** Utiliser le filtre (champ de recherche) pour retrouver rapidement un fichier dans un projet volumineux.

---

## Étape 4 — Mettre à jour les copybooks (`Ctrl+4`)

**Qui ?** Le développeur, avant tout build.

**Quoi ?** Les programmes COBOL utilisent des copybooks (instructions `COPY`). Certains copybooks sont internes au projet (`cpy/`), d'autres sont partagés entre plusieurs applications. Cette fonction télécharge les copybooks externes depuis GitLab dans le répertoire `dex_read_only/`.

**Quand l'utiliser ?**
- Après avoir participé à une évolution
- Quand un collègue a modifié un copybook partagé
- Avant un build, pour s'assurer d'avoir la version correcte

**Comment ?**
1. S'assurer qu'un projet est sélectionné dans l'explorateur IDz
2. Appuyer sur `Ctrl+4`
3. Attendre la fin (une barre de progression s'affiche)

**Résultat :**
- `dex_read_only/cpy/`, `dex_read_only/dcl/`, `dex_read_only/in2/` sont remplis des copybooks externes
- Des rapports sont générés dans `META-INF/` (`dependancies.txt`, `errors.txt`, etc.)

---

## Étape 5 — Déclarer les dépendances (`Ctrl+7`) _(optionnel)_

**Qui ?** Le développeur, si son application utilise des copybooks développés dans **une autre application** dont l'évolution n'est pas encore en `master`.

**Quoi ?** Déclare dans le manifest que l'évolution courante dépend d'une autre évolution d'une autre application.

**Quand l'utiliser ?**
- Quand le build Jenkins remonte une erreur "copybook non trouvé"
- Quand on sait que son programme utilise un copybook qui est en cours de développement dans une autre branche `feature_`

**Comment ?**
1. Appuyer sur `Ctrl+7`
2. Dans le champ de recherche, saisir le code de l'autre application (ex : `da02`)
3. Cocher les branches dont on dépend
4. Valider

**Résultat :** Le manifest est mis à jour avec :
```json
"dependancies": ["da02_copybook_partage"]
```

---

## Étape 6 — Builder (`Ctrl+0`)

**Qui ?** Le développeur, une fois les sources modifiées et le manifest à jour.

**Quoi ?** Déclenche le pipeline Jenkins `BuildAndPush` qui va compiler tous les composants déclarés dans le manifest.

**Comment ?**
1. S'assurer qu'un projet est sélectionné dans l'explorateur IDz
2. Appuyer sur `Ctrl+0`
3. La vue Blue Ocean s'ouvre automatiquement dans IDz

**Ce que Jenkins fait (pipeline `BuildAndPush`) :**

```
Stage 1 — Init Environnement
  • Lecture du manifest depuis GitLab
  • Initialisation des variables (app, version, toolchain)

Stage 2 — Compilation & Link-Edit (via DBB sur z/OS USS)
  • Clone du dépôt Git sur le mainframe (USS)
  • Exécution de zAppBuild/build.groovy pour chaque composant
  • Pour chaque fichier COBOL :
    - Pré-compilation (si SQL DB2) → produit DBRM
    - Compilation → produit .obj
    - Link-Edit → produit LOD/LOT (module charge)
  • Archivage des listings de compilation

Stage 3 — Analyse qualité SonarQube
  • Envoi des sources vers SonarQube
  • Vérification de la quality gate

Stage 4 — Packaging
  • Création d'un fichier .tar contenant tous les objets compilés
  • Création du fichier descripteur (.desc.json)
  • Push du .tar vers Artifactory feed scratch
  • Tag Git de l'évolution
```

**Résultat :**
- Artefact `.tar` disponible dans Artifactory (feed scratch)
- Fichier `.desc.json` (descripteur) disponible dans Artifactory
- La vue Blue Ocean affiche SUCCESS ou FAILURE

**Codes retour :**
- `SUCCESS` → compilation réussie, artefact disponible
- `FAILURE` → erreur de compilation (lire les logs Jenkins)
- `UNSTABLE` → compilation réussie mais quality gate non atteinte

---

## Étape 7 — Promote Unitaire (clic droit)

**Qui ?** Le développeur, pour tester rapidement un composant précis.

**Quoi ?** Déploie un **seul composant** dans l'environnement de Test Unitaire (TU). Plus rapide qu'un déploiement complet.

**Prérequis :** Le composant doit avoir été compilé (étape 6) au préalable.

**Comment ?**
1. Dans l'explorateur IDz, **clic droit** sur un fichier source (ex : `src/CALCUTVA.cbl`)
2. Sélectionner **Promote Unitaire**
3. La vue Blue Ocean s'ouvre

**Ce que Jenkins fait (pipeline `PromoteUnitaire`) :**

```
Stage 1 — Start Pipeline
  • Lecture du JSON de commande (appName, version, couloir, componentType, component)

Stage 2 — Construction du JCL
  • Génération d'une carte JOB (en-tête du JCL)
  • Pour chaque type de composant (ex: LOD, BGB, DBR) :
    - Copie du PDS source vers le PDS cible TU
    - Étapes spécifiques selon le type :
      • DBR  → BIND DB2 (créer/mettre à jour le plan d'exécution)
      • MSK  → Exécution du programme de traitement des masques BMS
      • LOT  → PHASEIN CICS (recharger le module dans CICS)
      • SPN  → Exécution du programme SPN

Stage 3 — Exécution du JCL
  • Soumission du JCL sur le mainframe via DBB
  • Récupération du numéro de JOB, code retour

Stage 4 — Résultat
  • CR=0  ✅ Déploiement OK
  • CR=1  ⚠️ Composant écrasé (déjà présent, remplacé)
  • CR<5  ⚠️ Certains composants absents du PDS source
  • CR<9  ❌ Composants non déployés
  • CR≥9  ❌ Erreur grave
```

---

## Étape 8 — Clean Unitaire (clic droit)

**Qui ?** Le développeur, pour annuler un Promote Unitaire.

**Quoi ?** Retire le composant de l'environnement TU (nettoyage).

**Comment ?** Clic droit sur le fichier → **Clean Unitaire**

**Ce que Jenkins fait (pipeline `CleanUnitaire`) :**

```
Stage 1 — Construction du JCL
  • Génération d'une étape de suppression du composant dans le PDS TU
  • Si LOT (programme TP) : ajout d'un PHASEIN CICS pour décharger le module

Stage 2 — Exécution du JCL

Stage 3 — Résultat
  • CR=0  ✅ Nettoyage OK
  • CR=8  ⚠️ Composant déjà absent (ignoré)
  • CR>8  ❌ Erreur
```

---

## Étape 9 — Audit qualité (`Ctrl+6`)

**Qui ?** Le développeur ou l'équipe qualité, avant la promotion en recette.

**Quoi ?** Déclenche une analyse de qualité du code source de l'évolution via le pipeline `auditEtQualite`.

**Ce que Jenkins fait (pipeline `auditEtQualite`) :**

```
Stage 1 — Init Env Vars
  • Lecture du manifest et du descripteur Artifactory
  • Téléchargement du fichier applications.json

Stage 2 — Audit
  • Clone du dépôt Git de l'application
  • Appel de la fonction audit() :
    - Vérification de conformité des composants par rapport à master
    - Détection des copybooks modifiés
    - Résolution des dépendances

Stage 3 — Validation Quality Gate
  • Interrogation de l'API SonarQube
  • Vérification que la quality gate est au statut OK
  • Échec si quality gate non passée
```

---

## Étape 10 — Déployer (`Ctrl+B`)

**Qui ?** Le développeur ou le Release Manager, après un build réussi.

**Quoi ?** Déclenche le pipeline Jenkins `ProxyCD` qui transmet la demande de déploiement vers l'environnement cible (recette, pré-production, production).

**Comment ?**
1. Sélectionner son projet dans IDz
2. Appuyer sur `Ctrl+B`
3. La vue Blue Ocean s'ouvre en mode maximisé

**Ce que Jenkins fait (pipeline `ProxyCD`) :**
Jenkins soumet une demande de déploiement au **service CD CAGIP** (`serv-101-cagip-trf-z-013-production.devops.caas.cagip.group.gca`). Le service CD orchestre ensuite l'installation sur les différents sites de déploiement.

Après chaque action de déploiement sur un site, un **callback** est renvoyé vers le pipeline `proxyci.jenkinsfile` avec un paramètre `action` :
- `doAfterMep` → installation terminée
- `doAfterMepApproved` → installation approuvée
- `doAfterMepRejected` → installation rejetée
- `doAfterMepCanceled` → installation annulée
- `doAfterRollback` → rollback effectué
- `doWhenExpired` → expiration de la demande

---

## Résumé des paramètres envoyés à Jenkins

### Pour Builder, Déployer, Audit
```
Paramètre : NomManifest = "da01_correction_calcul_tva"
(nom du fichier manifest sans l'extension .mf.json)
```

### Pour Promote Unitaire et Clean Unitaire
```json
{
  "appName": "da01",
  "version": "20250401-001",
  "site": "DEV",
  "couloir": "STDA",
  "environment": "TU",
  "componentType": ["LOD", "BGB", "DBR"],
  "component": "CALCUTVA"
}
```

---

## Tableaux de correspondance

### Répertoire → Types de composants envoyés à Jenkins

| Répertoire | Types (`componentType`) | Signification |
|---|---|---|
| `src/` | `[LOD, BGB, DBR]` | Programme COBOL BATCH avec Load + Debug + DB2 |
| `srt/` | `[LOT, BGT, DBR]` | Programme COBOL TP avec Load Transaction + Debug + DB2 |
| `asm/` | `[ASM]` | Programme Assembleur |
| `ast/` | `[AST]` | Asset CICS |
| `cli/` | `[CLI]` | Client CICS |
| `mps/` | `[MAP]` | Map CICS |
| `msk/` | `[MSK]` | Masque BMS |
| `par/` | `[PAR]` | Paramètre |
| `poe/` | `[POE]` | Procédure opérationnelle |
| `skl/` | `[SKL]` | Squelette JCL |
| `spn/` | `[SPN]` | Spanning |
| `srp/` | `[PAN]` | Sous-routine PANVALET |
| `srx/` | `[REX]` | Script REXX |

### Toolchain → URLs Jenkins (FabCI)

| `zdevops.toolchain` | URL FabCI |
|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca` |

### Type d'application → Couloir

| `application_type` dans le manifest | Couloir envoyé à Jenkins |
|---|---|
| `STD` | `STDA` |
| `CRF` | `CRFA` |
| Toute autre valeur | Valeur brute (ex: `XYZ`) |
