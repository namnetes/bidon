# Fonction 1 — Démarrer une évolution

**Raccourci clavier :** `Ctrl+1`
**Menu :** zDevOps > Démarrer une évolution

---

## Contexte et objectif

Dans le processus de développement mainframe LCL, toute modification du code source d'une application doit se faire dans le cadre d'une **évolution**. Une évolution est une unité de travail isolée, matérialisée par une **branche Git** dédiée dans le dépôt GitLab de l'application.

Cette fonction permet à un développeur de **créer une nouvelle évolution** pour une application donnée : elle crée la branche Git sur le serveur GitLab, clone le dépôt localement dans l'IDE IDz, et initialise le fichier manifest associé.

---

## Concepts clés à connaître

### Code application
Chaque application mainframe est identifiée par un code de **4 caractères exactement**, qui correspond au nom du dépôt GitLab de cette application.
- Les codes commençant par `da` désignent des applications de type **BATCH** (traitements différés, noctumes).
- Les codes commençant par `dy` désignent des applications de type **TP** (transactions en ligne, CICS).
- Exemples : `daab`, `dyxz`, `da01`, `dy99`.

### Évolution (branche Git)
Une évolution est une branche Git portant le préfixe `feature_`. Le développeur choisit un nom libre (ex : `correction_bug_42`), et le plugin crée automatiquement la branche `feature_correction_bug_42` dans GitLab et localement.

### Fichier manifest (`.mf.json`)
Chaque évolution possède un fichier manifest, stocké dans le répertoire `META-INF/` du projet. Ce fichier JSON décrit l'évolution :
- le code application
- le type de composant (BATCH ou TP)
- la description de l'évolution
- la liste des fichiers sources à builder
- les dépendances éventuelles vers d'autres évolutions

### `applications.json`
Fichier de référence hébergé dans GitLab, qui liste toutes les applications autorisées. Si un code application n'y est pas référencé, la création de l'évolution est refusée.

### Toolchain
L'environnement cible (dev, rec, frm, prd) configuré dans le fichier `zdevops.ini` du workspace. Il détermine les URLs GitLab et Jenkins à utiliser.

---

## Saisies requises par l'utilisateur

| Champ | Obligatoire | Règles de validation |
|---|---|---|
| **Code de l'application** | Oui | Exactement 4 caractères, commence par `da` ou `dy` |
| **Nom de l'évolution** | Oui | Alphanumérique + `_` uniquement, sans espace, ne commence pas par `feature`, pas déjà existant sous la forme `feature_XXX` dans GitLab |
| **Description** | Oui | Texte libre, non vide |
| **Type de composant** | Oui | Au choix : `BATCH` ou `TP` (bouton radio) |

---

## Règles métier détaillées

### RG-01 : Validation du code application
- Le champ passe en **vert** si le code est syntaxiquement valide (4 chars, `da` ou `dy`).
- Le champ passe en **rouge** si le code est invalide.
- La validation syntaxique est faite en temps réel. La vérification d'existence dans GitLab est faite à la perte du focus du champ.
- Si le code n'existe pas dans GitLab, la liste des évolutions reste vide.

### RG-02 : Chargement des évolutions existantes
- Dès que le code application perd le focus, le plugin interroge GitLab pour charger toutes les branches existantes du dépôt.
- Ces branches sont proposées dans une liste déroulante avec autocomplétion, **à titre informatif uniquement** : le développeur doit saisir un nom **différent** de toutes les branches existantes.
- La liste permet d'éviter de créer un doublon involontaire.

### RG-03 : Validation du nom de l'évolution
- Le nom saisi ne doit **pas** être identique à une branche déjà existante dans le dépôt.
- Le nom ne doit **pas** commencer par `feature` (le préfixe est ajouté automatiquement).
- Le nom ne doit **pas** contenir d'espace.
- Seuls les caractères alphanumériques (`a-z`, `A-Z`, `0-9`) et le tiret bas (`_`) sont autorisés.
- La branche `feature_<nom_saisi>` ne doit pas déjà exister dans GitLab.

### RG-04 : Vérification dans `applications.json`
Avant toute opération Git, le plugin vérifie que le code application est bien référencé dans le fichier `applications.json` hébergé sur GitLab. Si ce n'est pas le cas, la création est annulée avec un message d'erreur explicite.

### RG-05 : Gestion du dépôt local existant
Si le dépôt de l'application est déjà cloné dans le workspace IDz, le plugin propose deux options :

**Option A — Supprimer et recréer**
1. Confirmation demandée à l'utilisateur.
2. Le dépôt local est supprimé physiquement du workspace.
3. Le dépôt est re-cloné depuis GitLab depuis `master`.
4. La nouvelle branche `feature_XXX` est créée depuis `master`.
5. Le manifest est initialisé et commité.
6. La branche est poussée vers GitLab.
7. Le projet est importé dans IDz.

**Option B — Mettre à jour**
1. Les modifications en cours sur la branche locale actuelle sont commitées (message automatique).
2. Bascule sur `master`.
3. `master` est mis à jour depuis GitLab (pull).
4. La nouvelle branche `feature_XXX` est créée depuis `master`.
5. Le manifest est initialisé et commité.
6. La branche est poussée vers GitLab.
7. Le projet est importé dans IDz.

### RG-06 : Dépôt non encore cloné (cas nominal)
1. Clone du dépôt depuis GitLab (avec suivi de progression).
2. Création de la branche `feature_<nom>` depuis `master`.
3. Configuration du dépôt Git local (hooks, protection de `master`).
4. Écriture du fichier manifest dans `META-INF/`.
5. Commit initial sur la branche.
6. Push de la branche vers GitLab.
7. Conversion du dépôt Git en projet IDz (visibilité dans l'explorateur).

### RG-07 : Contenu du manifest initialisé
Le manifest créé contient :
- `entity` : `LCL`
- `application_code` : le code saisi
- `application_type` : déduit du code (`STD` pour `da`, `CRF` pour `dy` selon les règles de l'application)
- `component_type` : `BATCH` ou `TP` selon la sélection
- `description` : la description saisie (encodée en UTF-8)
- `manifest_name` : `<code>_<nom_evolution>`
- `content` : vide à la création, à remplir via la fonction [Gérer les composants](#)
- `dependancies` : vide à la création

### RG-08 : Bouton Reset
Vide tous les champs du formulaire sans fermer la boîte de dialogue.

### RG-09 : Bouton Quitter
Ferme la boîte de dialogue sans aucune action.

---

## Séquence complète (cas nominal)

```
1. L'utilisateur ouvre la boîte de dialogue (Ctrl+1)
2. Saisit le code application (ex : "da01")
   → Le plugin charge les branches existantes de GitLab
3. Saisit le nom de l'évolution (ex : "correction_bug_42")
   → Le plugin vérifie que "feature_correction_bug_42" n'existe pas
4. Saisit une description
5. Sélectionne le type : BATCH
6. Clique sur "Valider"
   → Vérification dans applications.json
   → Clone ou mise à jour du dépôt
   → Création de la branche feature_correction_bug_42
   → Écriture du manifest dans META-INF/
   → Commit et push
   → Import dans IDz
7. Message de confirmation affiché
8. Le projet "da01" apparaît dans l'explorateur IDz sur la branche feature_correction_bug_42
```

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Code application syntaxiquement incorrect | "Le nom du repo doit commencer par 'da' ou 'dy'" |
| Code non trouvé dans applications.json | "Le code d'application XXX n'est pas référencé dans le fichier de référence" |
| Nom d'évolution déjà existant | "L'évolution feature_XXX existe déjà dans le dépôt distant" |
| Nom contenant des espaces | "Le nom de l'évolution ne doit pas contenir d'espace" |
| Aucun type composant sélectionné | "Veuillez sélectionner le type de composant" |
| Échec du clone | "Échec de l'opération de clone du dépôt XXX" |
