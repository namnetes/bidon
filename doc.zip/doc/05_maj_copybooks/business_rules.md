# Fonction 5 — Mettre à jour les copybooks

**Raccourci clavier :** `Ctrl+4`
**Menu :** zDevOps > Mettre à jour les copybooks

---

## Contexte et objectif

Les **copybooks** (aussi appelés "copy" ou "copys") sont des fichiers partagés utilisés par les programmes COBOL : ils contiennent des définitions de structures de données, de constantes ou de paragraphes réutilisables. Un programme COBOL les importe via les instructions `COPY` ou `EXEC SQL INCLUDE`.

Cette fonction synchronise les copybooks **externes** nécessaires au projet courant depuis les dépôts GitLab partagés, et les dépose dans un répertoire local **`dex_read_only`** du projet IDz.

### Quand l'utiliser ?
- Après avoir participé à une évolution ou mis à jour le manifest.
- Quand un collègue a modifié un copybook partagé dont votre application dépend.
- Avant un build, pour s'assurer que les copybooks sont à jour.
- Régulièrement pendant le développement, pour éviter des erreurs de compilation dues à des copybooks obsolètes.

---

## Concepts clés

### Types de copybooks

#### Copybooks internes
Stockés dans les répertoires `cpy/`, `dcl/` et `in2/` **du projet lui-même**. Ce sont des copybooks propres à l'application.

#### Copybooks externes
Copybooks utilisés par les programmes du projet mais **définis dans d'autres projets**. Ils proviennent de deux sources :
1. **Copybooks partagées** (`gitlab.app.copies.partagees.id`) : utilisables par toutes les applications.
2. **Copybooks publiées** : selon le type d'application (`CRFP` ou `PUSTD`), il existe des dépôts de copybooks publiés spécifiques.
3. **Copybooks participating** : copybooks appartenant aux **dépendances déclarées** dans le manifest (autres évolutions d'autres applications dont on dépend).

### Répertoire `dex_read_only`
Répertoire local dans le projet IDz (au même niveau que `src/`, `cpy/`, etc.) qui contient les copybooks externes téléchargés. Il est organisé en sous-répertoires :
- `dex_read_only/cpy/` → copybooks `.cpy`
- `dex_read_only/dcl/` → copybooks `.dcl`
- `dex_read_only/in2/` → copybooks `.in2`

Ce répertoire est **en lecture seule** : on ne doit pas modifier son contenu directement. Il est régénéré à chaque exécution de cette fonction.

---

## Prérequis

- Un projet doit être sélectionné dans l'explorateur IDz (ou un fichier du projet doit être ouvert dans l'éditeur).
- Le projet doit posséder un fichier manifest (`.mf.json`) dans son répertoire `META-INF/`.
- Le token GitLab doit être configuré (fonction 13).

---

## Règles métier détaillées

### RG-01 : Identification du projet courant
Le plugin détermine le projet actif de deux façons :
1. Par la sélection dans l'explorateur de projet IDz.
2. À défaut, par le projet du fichier ouvert dans l'éditeur actif.
Si aucun projet n'est identifiable, un avertissement est affiché.

### RG-02 : Nettoyage préalable de `dex_read_only`
Avant tout téléchargement, le contenu existant de `dex_read_only` est **supprimé** :
- `dex_read_only/cpy/*.cpy` → supprimés
- `dex_read_only/dcl/*.dcl` → supprimés
- `dex_read_only/in2/*.in2` → supprimés

### RG-03 : Identification des copybooks à télécharger
Le plugin scanne tous les fichiers sources du projet listés dans le manifest (`.cob`, `.cbl`) et en extrait les noms de copybooks référencés par :
- L'instruction `COPY <nom>`
- L'instruction `EXEC SQL INCLUDE <nom> END-EXEC`

Les lignes commentées en COBOL (caractère `*` ou `/` en colonne 7) sont ignorées.

Les copybooks trouvés sont ensuite comparés à la liste des copybooks **internes** (ceux déjà présents dans `cpy/`, `dcl/`, `in2/`). Seuls les copybooks **absents localement** (= copybooks externes) sont téléchargés.

### RG-04 : Téléchargement depuis GitLab
Le plugin télécharge les copybooks externes depuis les dépôts GitLab de copybooks partagés. Les copybooks sont cherchés dans l'ordre :
1. Dépôt des copybooks partagées (commun à toutes les applications).
2. Dépôt des copybooks publiées (spécifique au type d'application).

### RG-05 : Copybooks participating (depuis les dépendances)
Si le manifest contient des dépendances (autres évolutions d'autres applications), le plugin va également :
1. Lire le manifest de chaque évolution dépendante dans GitLab.
2. En extraire les fichiers de type `cpy`, `dcl`, `in2` listés dans le `content`.
3. Télécharger ces fichiers dans `dex_read_only`.

Une barre de progression affiche l'avancement pour chaque dépendance traitée.

### RG-06 : Génération de fichiers de rapport dans `META-INF/`
Après la mise à jour, le plugin génère plusieurs fichiers texte de rapport dans le répertoire `META-INF/` du projet :

| Fichier | Contenu |
|---|---|
| `dependancies.txt` | Liste de tous les copybooks référencés par chaque programme source, avec leurs chemins |
| `dex_read_only_cpy.txt` | Copybooks `.cpy` présents dans `dex_read_only` et les programmes qui les utilisent |
| `dex_read_only_dcl.txt` | Idem pour `.dcl` |
| `dex_read_only_in2.txt` | Idem pour `.in2` |
| `manifest_dependancies.txt` | Pour chaque programme du manifest, liste des copybooks qu'il inclut |
| `errors.txt` | Copybooks référencés mais non trouvés (si des erreurs ont eu lieu) |

Les anciens fichiers `.txt` dans `META-INF/` sont supprimés avant la génération.

### RG-07 : Rafraîchissement du projet IDz
En fin d'opération, le projet IDz est rafraîchi (`refreshLocal`) pour que les nouveaux fichiers apparaissent dans l'explorateur.

---

## Séquence complète

```
1. L'utilisateur sélectionne son projet dans l'explorateur IDz
2. Appuie sur Ctrl+4
3. Le plugin identifie le projet courant
4. Nettoyage de dex_read_only/ (suppression des anciens fichiers)
5. Lecture du manifest pour identifier les sources
6. Scan des fichiers sources pour extraire les noms de copybooks
7. Comparaison avec les copybooks internes (cpy/, dcl/, in2/)
8. Téléchargement des copybooks externes depuis GitLab
9. Traitement des copybooks participating (dépendances du manifest)
10. Génération des fichiers de rapport dans META-INF/
11. Rafraîchissement du projet IDz
```

---

## Structure du répertoire résultant

```
mon-projet/
├── META-INF/
│   ├── xxxx_evolution.mf.json
│   ├── dependancies.txt        ← généré
│   ├── dex_read_only_cpy.txt   ← généré
│   ├── dex_read_only_dcl.txt   ← généré
│   ├── dex_read_only_in2.txt   ← généré
│   ├── manifest_dependancies.txt ← généré
│   └── errors.txt              ← généré si erreurs
├── src/
├── cpy/                        ← copybooks internes
├── dex_read_only/
│   ├── cpy/                    ← copybooks externes téléchargés
│   ├── dcl/
│   └── in2/
...
```

---

## Erreurs possibles

| Situation | Comportement |
|---|---|
| Aucun projet sélectionné | Message d'avertissement, opération annulée |
| Manifest absent ou multiple dans META-INF/ | Message d'erreur, opération annulée |
| Copybook non trouvé dans GitLab | Nom du copybook ajouté dans `errors.txt` |
| Token GitLab invalide ou absent | Erreur de connexion à GitLab |
