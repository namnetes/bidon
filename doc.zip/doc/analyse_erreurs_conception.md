# Analyse des erreurs de conception — Plugin zDevOps IDz

> **Ce document a été supplanté par une analyse plus complète.**  
> Voir le répertoire [analyse/](analyse/README.md) qui contient :
> - [bugs_averes.md](analyse/bugs_averes.md) — bugs confirmés enrichis (M1–M5, m1–m5)
> - [questions_architecture.md](analyse/questions_architecture.md) — questions architecturales (A1–A13)
> - [risques_securite.md](analyse/risques_securite.md) — risques de sécurité (S1–S6)
> - [risques_processus.md](analyse/risques_processus.md) — risques processus CI/CD (P1–P9)
>
> Le contenu ci-dessous est conservé pour référence historique.

---

**Date :** 2026-05-08
**Périmètre :** `plugin/src/fr/lcl/zdevops/idz/plugin/`
**Version analysée :** 2.0.1-SNAPSHOT

---

## Synthèse

| # | Problème | Fichier | Lignes | Gravité |
|---|---|---|---|---|
| M1 | Race condition sur le numéro d'artéfact (`applications.json`) | `GitLabService.java` | 811–833 | **Majeur** |
| M2 | `changeListener` jamais assigné au champ d'instance | `Activator.java` | 45, 53 | **Majeur** |
| M3 | `writeBranchManifest` non atomique — état incohérent garanti en cas d'échec | `GitLabService.java` | 565–628 | **Majeur** |
| M4 | `commitChanges` avale silencieusement les erreurs Git | `GitLabService.java` | 380–386 | **Majeur** |
| M5 | `switcherBranche` commite automatiquement sans consentement utilisateur | `GitLabService.java` | 440–451 | **Majeur** |
| m1 | `TextProgressMonitor` double-initialisé dans le constructeur | `GitLabService.java` | 141, 144 | Mineur |
| m2 | `updateHlq` retourne silencieusement en cas d'erreur | `GitLabService.java` | 637–694 | Mineur |
| m3 | Remplacement du HLQ par recherche de chaîne fixe fragile | `GitLabService.java` | 687 | Mineur |
| m4 | `startNewEvolution` — corps vide (TODO) dans l'interface publique | `GitLabService.java` | 866–873 | Mineur |
| m5 | Stratégies de logging incohérentes | Partout | — | Mineur |
| A1 | `AppProperties` entièrement statique : testabilité nulle | `AppProperties.java` | — | Amélioration |
| A2 | `GitLabService` est un God Object | `GitLabService.java` | — | Amélioration |
| A3 | Validation du token GitLab commentée | `GitLabService.java` | 131–137 | Amélioration |
| A4 | Absence de stratégie de retry réseau | `JenkinsJobService.java` | — | Amélioration |

---

## Erreurs MAJEURES

### M1 — Race condition sur `applications.json` (numéro d'artéfact non transactionnel)

**Fichiers :** `GitLabService.java` — `writeBranchManifest` (l.565), `updateApplication` (l.811), `pushUpdatedApplications` (l.790)

#### Description

Le numéro d'artéfact (champ `next_artifact_number` dans `applications.json`) est incrémenté via un cycle Read → Modify → Write **non atomique** sur un fichier hébergé dans GitLab :

```java
// updateApplication() — aucun verrou, aucune transaction
List<Application> applications = fetchApplications();     // 1. Lit depuis GitLab
application.setNextArtifactNumber(current + 1);           // 2. Incrémente en mémoire locale
pushUpdatedApplications(applications);                     // 3. Ré-écrit sur GitLab
```

Si deux développeurs démarrent une évolution sur la **même application** simultanément, les deux lisent `next_artifact_number = 42`, les deux l'incrémentent à `43`, et l'un écrase le commit de l'autre. Les deux évolutions reçoivent le **même numéro de manifest**.

#### Conséquences

- Deux branches `feature_` avec un `manifest_name` identique dans leur `.mf.json`
- Le pipeline Jenkins `BuildAndPush` reçoit deux fois `NomManifest=da01_000043` — l'un des builds écrase l'autre ou les deux échouent selon la logique pipeline
- Corruption silencieuse du référentiel `applications.json`

#### Comment démontrer le bug

```python
# test_race_condition.py — simulation via l'API GitLab directement
import threading, requests, json, time

GITLAB_URL = "https://scm.saas.cagip.group.gca/api/v4"
TOKEN = "<token>"
PROJECT_ID = 134997  # gitlab.app.params.id
HEADERS = {"PRIVATE-TOKEN": TOKEN}

def lire_numero_artefact():
    r = requests.get(
        f"{GITLAB_URL}/projects/{PROJECT_ID}/repository/files/applications.json/raw",
        params={"ref": "master"},
        headers=HEADERS
    )
    apps = json.loads(r.text)
    return next(a for a in apps if a["application_code"] == "da01")["next_artifact_number"]

resultats = []

def simuler_demarrage_evolution():
    """Simule le Read-Modify-Write de writeBranchManifest"""
    n = lire_numero_artefact()
    time.sleep(0.5)          # Simule le travail entre lecture et écriture
    resultats.append(n)

t1 = threading.Thread(target=simuler_demarrage_evolution)
t2 = threading.Thread(target=simuler_demarrage_evolution)
t1.start(); t2.start()
t1.join(); t2.join()

print(f"Numéros lus simultanément : {resultats}")
assert resultats[0] == resultats[1], "Race condition : deux évolutions avec le même numéro"
```

**Résultat attendu :** `[42, 42]` — collision confirmée.

#### Correction envisageable

Utiliser l'API GitLab avec un **commit conditionnel** (paramètre `last_commit_id`) pour obtenir un comportement optimistic locking, ou passer par un mécanisme de lock externe (fichier sentinel ou issue GitLab).

---

### M2 — `changeListener` jamais assigné au champ d'instance

**Fichier :** `Activator.java`, lignes 45 et 53

#### Description

La variable `changeListener` déclarée ligne 45 est une **variable locale** qui cache le champ d'instance `this.changeListener`. Le champ d'instance reste `null` pour toute la durée de vie du plugin.

```java
// start() — bug : 'changeListener' est une variable LOCALE, pas this.changeListener
ManifestFileChangeListener changeListener = new ManifestFileChangeListener(); // ← local !
ResourcesPlugin.getWorkspace().addResourceChangeListener(changeListener, IResourceChangeEvent.POST_CHANGE);

// stop() — this.changeListener est NULL → le listener réel n'est jamais retiré
ResourcesPlugin.getWorkspace().removeResourceChangeListener(changeListener); // ← null !
```

#### Conséquences

- Le `ManifestFileChangeListener` n'est **jamais retiré** à l'arrêt du plugin
- Fuite mémoire : l'objet reste référencé par le workspace Eclipse
- Comportement fantôme : si le plugin est redémarré dans la même session Eclipse, l'ancien listener continue d'être actif
- `removeResourceChangeListener(null)` ne lève pas d'exception mais ne fait rien

#### Comment démontrer le bug

```java
@Test
public void testChangeListenerLeaked() throws Exception {
    List<IResourceChangeListener> registered = new ArrayList<>();
    List<IResourceChangeListener> removed = new ArrayList<>();

    IWorkspace mockWorkspace = mock(IWorkspace.class);
    doAnswer(inv -> { registered.add(inv.getArgument(0)); return null; })
        .when(mockWorkspace).addResourceChangeListener(any(), anyInt());
    doAnswer(inv -> { removed.add(inv.getArgument(0)); return null; })
        .when(mockWorkspace).removeResourceChangeListener(any());

    Activator activator = new Activator();
    activator.start(mockContext);
    activator.stop(mockContext);

    assertThat(removed.get(0)).isNull();       // null passé à removeResourceChangeListener
    assertThat(registered.get(0)).isNotNull(); // le vrai listener n'est jamais retiré
}
```

#### Correction

```java
// Remplacer la ligne 45 dans start() :
// Avant (bug) :
ManifestFileChangeListener changeListener = new ManifestFileChangeListener();
// Après (correct) :
changeListener = new ManifestFileChangeListener();
```

---

### M3 — `writeBranchManifest` non atomique : état incohérent garanti en cas d'échec

**Fichier :** `GitLabService.java`, lignes 565–628

#### Description

La méthode enchaîne 5 opérations distinctes **sans mécanisme de rollback** :

```
Étape 1 : Créer META-INF/<nom>.mf.json sur le disque local
Étape 2 : git add + git commit (manifest)
Étape 3 : Modifier zapp.yaml via updateHlq()
Étape 4 : git add + git commit (zapp.yaml)
Étape 5 : updateApplication() → pushUpdatedApplications() → API GitLab (applications.json)
```

Si le réseau coupe entre les étapes 2 et 5, ou si `updateApplication` lève une exception :
- Le manifest et `zapp.yaml` sont commités **localement** avec le nouveau numéro
- `applications.json` sur GitLab conserve l'**ancien** numéro
- La prochaine évolution sur cette application lira l'ancien numéro et créera un doublon de numéro

#### Comment démontrer le bug

```java
// Sous-classer GitLabService pour injecter une panne réseau à l'étape 5
class GitLabServiceAvecPanne extends GitLabService {
    @Override
    void updateApplication(Application app) throws Exception {
        throw new RuntimeException("Panne réseau simulée");
    }
}

@Test
public void testInconsistanceApresEchecReseau() throws Exception {
    GitLabService service = new GitLabServiceAvecPanne();
    service.setProject(mockProject("da01"));

    int numeroBefore = service.getApplicationByAppCode("da01").getNextArtifactNumber();

    try {
        service.writeBranchManifest(project, "feature_test", "feature");
        fail("Doit lever une exception");
    } catch (RuntimeException e) {
        // Exception attendue
    }

    // Le manifest a été écrit et commité localement malgré l'échec
    File manifestFile = new File(getLocalPath(project) + "/META-INF/da01_000043.mf.json");
    assertTrue("Manifest présent localement malgré l'échec", manifestFile.exists());

    // applications.json n'a PAS été mis à jour
    int numeroAfter = service.getApplicationByAppCode("da01").getNextArtifactNumber();
    assertEquals("Numéro inchangé dans applications.json", numeroBefore, numeroAfter);

    // → Le prochain appel attribuera à nouveau le même numéro : COLLISION
}
```

#### Scénario réel de reproduction

1. Démarrer une évolution sur `da01`
2. Pendant que le plugin écrit le manifest (étape 2), désactiver le réseau
3. Rétablir le réseau
4. Démarrer une deuxième évolution sur `da01`
5. Constater que les deux `.mf.json` ont le même `manifest_number`

---

### M4 — `commitChanges(Project, String)` avale silencieusement les erreurs Git

**Fichier :** `GitLabService.java`, lignes 380–386

#### Description

La surcharge à un paramètre de `commitChanges` attrape toutes les exceptions et se contente d'un `printStackTrace`, sans rethrow. L'appelant croit que le commit a réussi et continue les opérations suivantes (push, création de branche) sur un état non commité.

```java
@Override
public void commitChanges(Project project, String message) throws IOException, GitAPIException {
    try {
        commitChanges(project, ".", message);
    } catch (GitAPIException | IOException | GitLabApiException e) {
        e.printStackTrace();   // stderr uniquement — personne ne lit ça
        // Pas de rethrow → l'appelant ne sait pas que le commit a échoué
    }
}
```

Cette surcharge est appelée par `switcherBranche`, `updateNewEvolution` et `manageBranchByBranch`.

#### Comment démontrer le bug

```bash
# 1. Verrouiller manuellement l'index Git du dépôt
touch <workspace>/da01/.git/index.lock

# 2. Déclencher "Participer à une évolution" (Ctrl+2) sur da01
#    → commitChanges est appelé avant la bascule de branche
#    → JGit lève LockFailedException
#    → Exception attrapée et imprimée sur stderr
#    → L'opération continue comme si le commit avait réussi
#    → La bascule de branche s'effectue sur un dépôt dirty
#    → L'utilisateur voit "connexion à l'évolution réussie" — mensongèrement

# Vérifier ensuite :
cd <workspace>/da01 && git log --oneline -3
# → Le commit attendu n'est pas présent
```

```java
@Test
public void testCommitEchoueNePropagePasException() throws Exception {
    // Simuler un dépôt verrouillé via un mock de Git
    Git mockGit = mock(Git.class);
    AddCommand mockAdd = mock(AddCommand.class);
    when(mockGit.add()).thenReturn(mockAdd);
    when(mockAdd.addFilepattern(any())).thenThrow(new LockFailedException(new File(".git/index")));

    GitLabService service = spyWithMockGit(mockGit);

    // Ne lève PAS d'exception — bug confirmé
    assertDoesNotThrow(() -> service.commitChanges(project, "message test"));
    // L'appelant n'a aucun moyen de détecter l'échec
}
```

---

### M5 — `switcherBranche` commite automatiquement sans consentement utilisateur

**Fichier :** `GitLabService.java`, lignes 440–451

#### Description

Si le dépôt local n'est pas propre au moment de la bascule de branche, la méthode **commite automatiquement tout le contenu non commité** avec un message générique, sans demander à l'utilisateur.

```java
public void switcherBranche(Project projet, String branchName) {
    ...
    if (!git.status().call().isClean()) {
        // Commit de TOUT ce qui est en cours — sans confirmation utilisateur
        commitChanges(projet,
            String.format("🎯 Validation des changements sur la branche %s avant bascule...",
                currentBranch, branchName));
    }
```

#### Conséquences

- Des fichiers temporaires, du code de debug ou des modifications partielles peuvent être commités et potentiellement poussés vers GitLab
- L'historique Git est pollué avec des commits non intentionnels
- L'utilisateur perd le contrôle de ce qui entre dans son historique

#### Comment démontrer le bug

```bash
# 1. Démarrer une évolution sur da01, branche feature_evol_a

# 2. Créer des fichiers temporaires involontaires
echo "BREAKPOINT TEMP" > <workspace>/da01/src/DEBUGFILE.cbl
echo "TODO: supprimer avant commit" >> <workspace>/da01/src/MONPROG.cbl

# 3. Déclencher une action qui appelle switcherBranche
#    (ex: "Consulter les sources" d'une autre appli, ou "Mettre à jour les copybooks")

# 4. Vérifier l'historique Git
cd <workspace>/da01 && git log --oneline -3
# → abc1234 🎯 Validation des changements sur la branche feature_evol_a avant bascule...
# DEBUGFILE.cbl et la ligne "TODO" sont maintenant dans l'historique Git
```

---

## Erreurs MINEURES

### m1 — `TextProgressMonitor` double-initialisé dans le constructeur

**Fichier :** `GitLabService.java`, lignes 141 et 144

```java
monitor = new TextProgressMonitor(new PrintWriter(System.out)); // ligne 141
projects = new ArrayList<Project>();
branchsByProject = new ArrayList<Branch>();
monitor = new TextProgressMonitor(new PrintWriter(System.out)); // ligne 144 — premier objet perdu
```

Le premier `TextProgressMonitor` est créé puis immédiatement abandonné. Impact : fuite d'objet mineure et lisibilité du code dégradée.

---

### m2 — `updateHlq` retourne silencieusement en cas d'erreur

**Fichier :** `GitLabService.java`, lignes 637–694

Toutes les conditions d'erreur (paramètres nuls, fichier absent, non lisible, non modifiable) produisent uniquement un `System.out.println` suivi d'un `return` :

```java
if (!Files.exists(yamlPath)) {
    System.out.println("Le fichier YAML n'existe pas : " + yamlPath);
    return; // ← retour silencieux
}
```

L'appelant `writeBranchManifest` ne sait pas que le HLQ n'a pas été mis à jour, et commite quand même un `zapp.yaml` inchangé avec un message indiquant qu'il a été modifié.

---

### m3 — Remplacement du HLQ par recherche de chaîne fixe fragile

**Fichier :** `GitLabService.java`, ligne 687

```java
String updatedContent = content.replace("F000000", "F" + newValue);
```

- Remplace uniquement la première occurrence de la chaîne littérale `F000000`
- Si le fichier `zapp.yaml` a déjà été modifié lors d'une évolution précédente (ex : contient `F000024`), le remplacement ne fait rien et le numéro n'est pas mis à jour
- Aucune erreur n'est levée : le fichier est réécrit identique à lui-même, commité, et personne ne le sait

---

### m4 — `startNewEvolution` : corps vide (TODO) dans l'interface publique

**Fichier :** `GitLabService.java`, lignes 866–873

```java
@Override
public void startNewEvolution(Project project, String evolution) throws Exception {
    // TODO
}

@Override
public void startNewEvolution(Project project, String evolution, ProgressMonitor monitor) throws Exception {
    // TODO
}
```

Ces deux méthodes font partie de l'interface `IGitLabService`. Le code opérationnel passe par `GitServiceLauncher` directement, contournant l'interface. Ces méthodes sont des dead code trompeurs : appeler `gitLabService.startNewEvolution(...)` depuis un futur test ou une évolution du code ne fait rien sans avertissement.

---

### m5 — Stratégies de logging incohérentes

Coexistence de quatre mécanismes sans règle commune :

| Mécanisme | Utilisé pour |
|---|---|
| `LOGGER.info/warn/error` (SLF4J) | Certaines méthodes de `GitLabService` |
| `System.out.println` | Validations dans `updateHlq`, messages de debug dans clone |
| `System.err.println` | Erreurs dans `cloneProject`, `GestionCopysUtils` |
| `e.printStackTrace()` | Exceptions attrapées partout |

En production, seul le logger SLF4J est orientable vers un appender configuré. Les `System.out/err` et `printStackTrace` ne peuvent pas être filtrés, centralisés ou désactivés.

---

## Améliorations

### A1 — `AppProperties` entièrement statique : testabilité nulle

Toute la configuration est chargée dans un bloc `static {}` au chargement de la classe. Il est impossible d'injecter une configuration de test sans modifier les vrais fichiers `.properties` embarqués dans le plugin. Toute classe qui dépend de `AppProperties` (directement ou indirectement) ne peut pas être testée unitairement de manière isolée.

**Solution :** introduire une interface `IAppConfig` injectée via le constructeur des services.

---

### A2 — `GitLabService` est un God Object

Une seule classe de ~1800 lignes gère :
- L'API GitLab REST (gitlab4j)
- Les opérations JGit locales (clone, commit, push, pull, checkout)
- La sérialisation/désérialisation du manifest JSON
- La mise à jour du fichier YAML (`zapp.yaml`)
- La gestion du référentiel d'applications (`applications.json`)
- Le téléchargement des copybooks

Le README mentionne lui-même que la fusion de `GitLabService` et `GitService` est un chantier en cours, mais le sens devrait être inverse : **séparer davantage** en services spécialisés (ex: `ManifestService`, `CopybookService`, `EvolutionService`).

---

### A3 — Validation du token GitLab commentée

**Fichier :** `GitLabService.java`, lignes 131–137

```java
// Ce bloc est commenté :
// boolean validGitLabToken = EclipsePluginHelper.isValidGitLabToken(userToken);
// if (!validGitLabToken) {
//     throw new InvalidTokenException("Aucun Token GitLab trouvé ou Token invalide.");
// }
```

Sans cette validation, un token expiré ou invalide provoque une `GitLabApiException` lors de la première opération réseau, avec un message d'erreur technique peu compréhensible pour l'utilisateur. La validation précoce permettrait d'afficher un message clair dès le démarrage du plugin.

---

### A4 — Absence de stratégie de retry réseau

Ni `JenkinsJobService` ni `GitLabService` n'implémentent de retry sur les opérations réseau. Une coupure de 2 secondes pendant un clone (parfois plusieurs minutes) fait échouer l'opération complète et laisse le dépôt local dans un état partiel. Une stratégie de retry exponentiel sur les appels HTTP Jenkins et les opérations JGit améliorerait significativement la robustesse sur des réseaux d'entreprise instables.
