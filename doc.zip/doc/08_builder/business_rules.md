# Fonction 8 — Builder

**Raccourci clavier :** `Ctrl+0`
**Menu :** zDevOps > Builder

---

## Contexte et objectif

Le **build** est l'étape de **compilation et d'assemblage** des sources COBOL et des autres composants déclarés dans le manifest. Cette fonction déclenche le pipeline Jenkins correspondant sur l'environnement cible (toolchain courante), en passant le nom du manifest comme paramètre.

### Quand l'utiliser ?
- Après avoir modifié des sources et mis à jour le manifest (composants + copybooks).
- Pour vérifier que le code compile correctement.
- Comme étape préalable au déploiement.

---

## Concepts clés

### Pipeline Jenkins de build
Un job Jenkins pré-configuré, identifié dans la configuration par la clé `jenkins.pipeline.build`. Ce pipeline reçoit en paramètre le nom du manifest de l'évolution et effectue la compilation de tous les composants listés dans ce manifest.

### Nom du manifest
C'est le nom du fichier `.mf.json` présent dans `META-INF/` du projet, **sans l'extension**. Exemple : si le fichier est `da01_correction_bug_42.mf.json`, le paramètre envoyé à Jenkins est `da01_correction_bug_42`.

### Toolchain
L'environnement cible déterminé par le fichier `zdevops.ini` du workspace. Il conditionne quelle instance Jenkins est appelée (dev, rec, frm, prd) et quel pipeline est exécuté.

### Token Jenkins
Identifiant personnel permettant au plugin de déclencher des jobs Jenkins au nom de l'utilisateur. Obligatoire pour toute interaction avec Jenkins.

---

## Prérequis

- Un projet doit être sélectionné dans l'explorateur IDz.
- Le projet doit contenir un fichier manifest unique dans `META-INF/`.
- Le token Jenkins doit être configuré (fonction 14). Si absent, la boîte de saisie du token s'affiche automatiquement.

---

## Règles métier détaillées

### RG-01 : Vérification du projet courant
Le plugin identifie le projet actif (via la sélection dans l'explorateur ou le fichier ouvert dans l'éditeur). Si aucun projet n'est identifié, un avertissement est affiché et l'action est annulée.

### RG-02 : Vérification et demande du token Jenkins
Avant de déclencher le build, le plugin vérifie que le token Jenkins est stocké dans le stockage sécurisé Eclipse. Si le token est absent ou vide :
1. La boîte de dialogue "Jenkins Token" s'ouvre automatiquement.
2. L'utilisateur doit saisir son identifiant Jenkins et son token.
3. Si l'utilisateur annule, un message l'invite à configurer son token et le build est annulé.

### RG-03 : Lecture du manifest courant
Le plugin lit le nom du fichier manifest présent dans `META-INF/` du projet actif. Ce nom (sans `.mf.json`) est le paramètre envoyé au pipeline Jenkins.

### RG-04 : Déclenchement du pipeline Jenkins
Le plugin appelle l'**API REST Jenkins** (HTTP Basic Auth avec `username:token` encodé en Base64) pour déclencher le job de build avec :
- **Nom du job :** `BuildAndPush` (configuré dans les properties du toolchain sous la clé `jenkins.pipeline.build`)
- **Paramètre :** `NomManifest` = nom du manifest courant (sans `.mf.json`)

L'appel HTTP est : `POST <jenkins_url>/job/BuildAndPush/buildWithParameters?NomManifest=<nom>`

Jenkins répond HTTP 201 avec une URL de file d'attente dans le header `Location`.

### RG-05 : Suivi de la progression (polling)
Le plugin surveille l'exécution en trois phases :
1. **Attente de démarrage** : polling de la file d'attente Jenkins (`queue/item/<id>/api/json`) toutes les 2 secondes, jusqu'à ce que le champ `executable.url` soit présent (max 30 tentatives = 60 secondes).
2. **Surveillance du build** : polling de `<build_url>/api/json` toutes les 2 secondes, jusqu'à ce que le champ `building` passe à `false`.
3. **Résultat** : succès ou échec affiché à l'utilisateur.

### RG-06 : Vue Jenkins Blue Ocean
Dès que le build démarre, la vue **Jenkins Browser** intégrée dans IDz s'ouvre automatiquement sur l'interface **Blue Ocean** du pipeline :
`<jenkins_base>/blue/organizations/jenkins/BuildAndPush/detail/BuildAndPush/<num>/pipeline/`

Cela permet de suivre les logs sans quitter l'IDE.

### Infrastructure Jenkins (FabCI)
Le pipeline `BuildAndPush` tourne sur l'infrastructure Jenkins interne **FabCI** (Fabrique CI/CD). L'URL dépend du toolchain actif :

| Toolchain | URL Jenkins |
|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca` |

---

## Ce que fait Jenkins côté mainframe (pipeline `BuildAndPush`)

Le plugin envoie uniquement le `NomManifest`. Voici l'intégralité de ce que Jenkins exécute :

### Stage 1 — Init Environnement
- Lecture du fichier manifest depuis GitLab (branche `feature_<nom>`)
- Extraction de l'`application_code`, `manifest_name`, `component_type`, `content`
- Initialisation des variables d'environnement (chemins USS, HLQ, Artifactory, SonarQube)
- Vérification que l'application est référencée dans `applications.json`

### Stage 2 — Prepare Build
- Préparation du workspace de build sur z/OS USS : `$USS_BUILD_WORKSPACE/<NomManifest>`
- Clone ou mise à jour du dépôt de l'application sur USS depuis GitLab

### Stage 3 — Compile & Link-Edit (DBB/zAppBuild sur z/OS)
Pour chaque composant listé dans le `content` du manifest, zAppBuild détermine le compilateur à utiliser selon le type de fichier :
- `.cbl` / `.cob` → compilateur COBOL + link-edit → produit `LOD` (BATCH) ou `LOT` (TP)
  - Si SQL DB2 embarqué : pré-compilation → produit `DBR` (DBRM)
  - Produit aussi `BGB` (debug BATCH) ou `BGT` (debug TP)
- `.pli` → compilateur PL/I
- `.asm` → assembleur
- `.rexx` → REXX
- `.bms` → BMS CICS → produit `MAP` + `MSK`

Chaque compilation produit un **listing** archivé dans le workspace Jenkins.

**Si la compilation échoue :** le build s'arrête, les stages qualité et packaging sont sautés, mais les listings sont toujours archivés pour diagnostiquer l'erreur.

### Stage 4 — Archive Listings (toujours exécuté)
Les listings de compilation sont archivés comme artefacts Jenkins, même en cas d'échec de compilation.

### Stage 5 — Quality Analysis (SonarQube)
- Envoi des sources et métriques vers SonarQube (`lcl.code.quality.cagip.group.gca`)
- Projet SonarQube identifié par `application_code` (namespace `com.lcl.dev`)

### Stage 6 — Quality Validation
- Interrogation de l'API SonarQube pour lire le statut de la quality gate
- Si quality gate `KO` → build `UNSTABLE` (l'artefact est quand même produit)

### Stage 7 — Package & Push Artifactory
- Création d'un fichier `.tar` contenant tous les modules compilés
- Création du **descripteur** `.desc.json` avec :
  - `buildNumber` : numéro du build Jenkins
  - `tag` : tag Git posé sur la branche
  - `feed` : `scratch` (artefact non encore validé)
  - `manifest` : copie du manifest
  - `components` : liste des objets compilés par type
- Push du `.tar` vers Artifactory feed **scratch** : `lcl-cdz-app-prod-generic-scratch-intranet/lcl/<groupe>/<app>/`
- Push du `.desc.json` vers Artifactory : `lcl-cdz-app-prod-generic-scratch-intranet/lcl/descriptors/<groupe>/<app>/`
- Tag Git sur la branche : `<manifest_name>_<build_number>`

### Stage 8 — Finalize
- Affichage du bilan : durée totale, résultat, URL Artifactory

---

## Résultats possibles

| Résultat Jenkins | Signification |
|---|---|
| `SUCCESS` | Compilation OK, quality gate OK, artefact dans Artifactory scratch |
| `UNSTABLE` | Compilation OK, quality gate KO — artefact produit mais non qualifié |
| `FAILURE` | Erreur de compilation — aucun artefact produit |

---

## Séquence complète

```
1. L'utilisateur sélectionne son projet dans l'explorateur IDz
2. Appuie sur Ctrl+0
3. Le plugin vérifie la présence du token Jenkins
   → Si absent : boîte de saisie du token
4. Le plugin lit le nom du manifest : "da01_correction_bug_42"
5. Appel API Jenkins :
   POST /job/<pipeline_build>/buildWithParameters
   Paramètre : NomManifest=da01_correction_bug_42
6. Suivi du job jusqu'à la fin
7. Résultat affiché (SUCCESS / FAILURE)
```

---

## Paramètre envoyé à Jenkins

| Nom du paramètre | Valeur | Exemple |
|---|---|---|
| `NomManifest` | Nom du fichier manifest sans extension | `da01_correction_bug_42` |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Aucun projet sélectionné | "Veuillez sélectionner un projet dans l'explorateur" |
| Token Jenkins absent et non saisi | "Merci de générer et renseigner votre token Jenkins" |
| Échec du déclenchement ou de l'exécution | "ERREUR : echec de l'exécution du build" |
| Token invalide (stockage sécurisé) | Message depuis le stockage Equinox |
