# Fonction 12 — Clean Unitaire

**Accès :** Clic droit sur un fichier dans l'explorateur IDz > Clean Unitaire
**Visible :** uniquement sur les fichiers (pas les répertoires)

---

## Contexte et objectif

Le **Clean Unitaire** permet de **retirer un composant** de l'environnement de test unitaire (`TU`), c'est-à-dire d'annuler l'effet d'un Promote Unitaire précédent. Cette opération nettoie l'environnement cible en retirant le composant qui y avait été promu.

### Quand l'utiliser ?
- Après un Promote Unitaire, si on souhaite annuler la promotion (ex. : le composant a un bug, on veut revenir à l'état précédent).
- Pour nettoyer l'environnement TU entre deux séries de tests.
- Quand un composant ne doit plus être en environnement de test.

---

## Relation avec Promote Unitaire

Clean Unitaire et Promote Unitaire sont les **deux faces de la même médaille**. Ils partagent exactement le même code (`DeployHandler`), la même logique de validation et la même construction JSON. La seule différence est le **nom du pipeline Jenkins** déclenché :

| Fonction | Pipeline Jenkins |
|---|---|
| Promote Unitaire | `PromoteUnitaire` |
| Clean Unitaire | `CleanUnitaire` |

---

## Règles métier

**Toutes les règles du Promote Unitaire s'appliquent de manière identique :**

### RG-01 : Visibilité de la commande
La commande n'apparaît que sur un fichier dans l'explorateur (pas sur les dossiers).

### RG-02 : Répertoires autorisés
Identique au Promote Unitaire : `asm`, `ast`, `cli`, `mps`, `msk`, `par`, `poe`, `skl`, `spn`, `src`, `srp`, `srt`, `srx`.

### RG-03 : Lecture du manifest
Le plugin lit le manifest unique dans `META-INF/` du projet.

### RG-04 : Construction de la commande JSON
JSON identique au Promote Unitaire :

```json
{
  "appName": "da01",
  "version": "20250401-001",
  "site": "<DEPLOY_SITE_NAME>",
  "couloir": "STDA",
  "environment": "TU",
  "componentType": ["LOD", "BGB", "DBR"],
  "component": "MONPROG"
}
```

### RG-05 : Pipeline déclenché
- **Nom du job :** `CleanUnitaire` (valeur fixe dans le code)
- **Paramètre :** `commande` = chaîne JSON

L'appel HTTP est : `POST <jenkins_url>/job/CleanUnitaire/buildWithParameters?commande=<json_encodé>`

### RG-06 : Suivi et infrastructure
Même mécanique de polling que les autres pipelines. La vue Blue Ocean s'ouvre dans IDz.

Infrastructure FabCI — URL selon le toolchain :

| Toolchain | URL Jenkins |
|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca` |

### RG-07 : Token Jenkins
Si absent, la boîte de saisie s'affiche automatiquement.

---

## Différence unique avec Promote Unitaire

| Critère | Promote Unitaire | Clean Unitaire |
|---|---|---|
| Pipeline déclenché | `PromoteUnitaire` | `CleanUnitaire` |
| Effet sur l'environnement TU | Ajoute / met à jour le composant | Retire le composant |
| Message d'erreur de répertoire | "...candidat à un Promote Unitaire" | "...candidat à un Clean Unitaire" |
| Tout le reste | **Identique** | **Identique** |

---

## Ce que fait Jenkins côté mainframe (pipeline `CleanUnitaire`)

### Stage 1 — Construction du JCL
Pour chaque type dans `componentType` :

1. **Résolution des PDS** via `getPDS()` (même logique que PromoteUnitaire)
2. **Génération de l'étape de suppression** (`jclClean`) : supprime le membre du PDS cible TU
3. **Si le type est `LOT`** (programme TP) : ajout d'une étape de PHASEIN CICS (`phasinCICS`) pour décharger le module du moniteur transactionnel

### Stage 2 — Exécution du JCL
- Soumission via `promote.sh`, récupération du numéro de JOB et du code retour
- Nettoyage du workspace USS (`deleteDir()`) après exécution

### Stage 3 — Résultat du Clean

| Code retour | Statut build | Signification |
|---|---|---|
| `0` | SUCCESS | Nettoyage réussi, composant supprimé |
| `8` | UNSTABLE | Composant déjà absent du PDS (ignoré — pas d'erreur fonctionnelle) |
| `>8` | FAILURE | Erreur lors de la suppression |

---

## Séquence complète

```
1. L'utilisateur fait clic droit sur MONPROG.cbl dans src/
2. Sélectionne "Clean Unitaire"
3. Vérification du répertoire (autorisé + premier niveau)
4. Lecture du manifest
5. Construction du JSON
6. Vérification du token Jenkins
7. Appel Jenkins : POST /job/CleanUnitaire/buildWithParameters
   Paramètre : commande={"appName":"da01","version":"...","couloir":"STDA",
   "environment":"TU","componentType":["LOD","BGB","DBR"],"component":"MONPROG"}
8. Suivi jusqu'à la fin
```

---

## Erreurs possibles

Identiques au Promote Unitaire, avec le message adapté :

| Situation | Message affiché |
|---|---|
| Fichier dans un répertoire non autorisé | "Le fichier XXX ne peut être candidat à un Clean Unitaire" |
| Aucun manifest ou plusieurs | Avertissement ou erreur |
| Token Jenkins absent | Boîte de saisie du token |
