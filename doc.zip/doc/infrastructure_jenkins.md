# Infrastructure Jenkins — FabCI

Ce document récapitule tout ce qui concerne l'intégration Jenkins du plugin zDevOps : pipelines déclenchés, infrastructure, protocole de communication, et ce que le plugin fait ou ne fait pas.

---

## Principe général

**Le plugin IDz ne contient aucune logique de compilation, déploiement ou audit.**

Tout le traitement métier (compilation COBOL, assemblage, déploiement, audit qualité, promote/clean unitaire) est **entièrement délégué à des pipelines Jenkins**. Le plugin se contente de :
1. Préparer les paramètres (nom du manifest ou JSON de composant).
2. Déclencher le pipeline Jenkins via l'API REST.
3. Surveiller la progression du job.
4. Afficher les logs via la vue Blue Ocean intégrée dans IDz.

---

## Pipelines Jenkins déclenchés

| Fonction IDz | Nom du pipeline Jenkins | Paramètre envoyé | Clé de config |
|---|---|---|---|
| **Builder** (Ctrl+0) | `BuildAndPush` | `NomManifest` = nom du manifest | `jenkins.pipeline.build` |
| **Déployer** (Ctrl+B) | `ProxyCD` | `NomManifest` = nom du manifest | `jenkins.pipeline.deploy` |
| **Audit** (Ctrl+6) | `auditEtQualite` | `NomManifest` = nom du manifest | `jenkins.pipeline.audit.qualite` |
| **Promote Unitaire** (clic droit) | `PromoteUnitaire` | `commande` = JSON composant | `jenkins.pipeline.promote.unitaire` |
| **Clean Unitaire** (clic droit) | `CleanUnitaire` | `commande` = JSON composant | *(valeur fixe dans le code)* |

### Paramètre `NomManifest`
Nom du fichier manifest sans l'extension `.mf.json`. Exemple : si le fichier est `da01_correction_bug_42.mf.json`, le paramètre vaut `da01_correction_bug_42`.

### Paramètre `commande` (Promote / Clean Unitaire)
Objet JSON décrivant le composant à traiter :
```json
{
  "appName": "da01",
  "version": "20250401-001",
  "site": "DEV",
  "couloir": "STDA",
  "environment": "TU",
  "componentType": ["LOD", "BGB", "DBR"],
  "component": "MONPROG"
}
```

Correspondances des champs :
| Champ JSON | Source |
|---|---|
| `appName` | `application_code` dans le manifest |
| `version` | `manifest_number` dans le manifest |
| `site` | Propriété `deploy.site.name` du toolchain |
| `couloir` | Déduit de `application_type` : `STD`→`STDA`, `CRF`→`CRFA`, sinon valeur brute |
| `environment` | Toujours `TU` (valeur fixe) |
| `componentType` | Dépend du répertoire : `src`→`[LOD,BGB,DBR]`, `srt`→`[LOT,BGT,DBR]`, sinon `[<DIR_MAJ>]` |
| `component` | Nom du fichier sans extension, en majuscules |

---

## Infrastructure Jenkins — FabCI

L'infrastructure Jenkins interne s'appelle **FabCI** (Fabrique CI/CD LCL). Il existe une instance par environnement :

| Toolchain (`zdevops.ini`) | URL Jenkins (API) | URL Blue Ocean (navigateur) |
|---|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca/api/json` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca/api/json` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca/api/json` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca/api/json` | `https://fabci-prd.ci.lcl.group.gca` |

La toolchain est sélectionnée via le fichier `zdevops.ini` dans la racine du workspace Eclipse, ligne :
```
zdevops.toolchain=dev
```

---

## Protocole de communication avec Jenkins (API REST)

Le plugin utilise le **client HTTP Java 11** (`java.net.http.HttpClient`) avec l'authentification **HTTP Basic Auth**.

### Authentification
```
Authorization: Basic <Base64("<login_windows>@id.fr.cly:<token_jenkins>")>
```
- Le login est déduit automatiquement du compte Windows (`System.getProperty("user.name")`).
- Le token est stocké dans le coffre-fort sécurisé Eclipse (Equinox Secure Storage).

### Séquence d'appel en 3 étapes

**Étape 1 — Déclenchement du job**
```
POST <jenkins_url>/job/<pipeline>/buildWithParameters?<param>=<valeur>
→ HTTP 201 + header Location: <jenkins_url>/queue/item/<id>/
```

**Étape 2 — Attente du démarrage**
Polling toutes les 2 secondes, maximum 30 tentatives (60 secondes) :
```
GET <queue_url>/api/json
→ Attendre que le champ "executable.url" soit présent
→ Récupérer l'URL du build : <jenkins_url>/job/<pipeline>/<num>/
```

**Étape 3 — Surveillance du build**
Polling toutes les 2 secondes jusqu'à la fin :
```
GET <build_url>/api/json
→ Vérifier que le champ "building" == false
```

### Ouverture de la vue Blue Ocean
Dès le démarrage du build, la vue **Jenkins Browser** dans IDz s'ouvre automatiquement sur l'URL Blue Ocean :
```
<jenkins_base>/blue/organizations/jenkins/<pipeline>/detail/<pipeline>/<num>/pipeline/
```

> Pour le pipeline `ProxyCD` (déploiement), la vue est affichée en **mode maximisé** automatiquement.

---

## Configuration par toolchain (fichiers `.properties`)

Les noms des pipelines et URLs sont configurés dans les fichiers embarqués dans le plugin :

```
plugin/src/fr/lcl/zdevops/idz/plugin/config/
├── dev.properties
├── rec.properties
├── frm.properties
└── prd.properties
```

Extrait d'un fichier de configuration :
```properties
jenkins.url.base=https://fabci-prd.ci.lcl.group.gca/api/json
jenkins.pipeline.build=BuildAndPush
jenkins.pipeline.deploy=ProxyCD
jenkins.pipeline.audit.qualite=auditEtQualite
jenkins.pipeline.promote.unitaire=PromoteUnitaire
deploy.site.name=DEV
```

> `jenkins.pipeline.promote.unitaire` est présent dans les properties mais le handler `CleanUnitaire` utilise la valeur `"CleanUnitaire"` codée en dur dans le code Java (pas dans les properties).

---

## Détail des pipelines — stages et codes retour

### Pipeline `BuildAndPush`

| Stage | Rôle |
|---|---|
| Start | Lecture du manifest depuis GitLab, initialisation des variables |
| Init Env | Configuration de l'environnement USS (toolchain, chemins, HLQ) |
| Prepare Build | Préparation du workspace de build sur USS |
| Compile & Link | Clone du dépôt sur USS + exécution de DBB/zAppBuild pour chaque composant |
| Archive Listings | Sauvegarde des listings de compilation (même en cas d'échec) |
| Quality Analysis | Envoi des sources vers SonarQube |
| Quality Validation | Vérification de la quality gate SonarQube |
| Package | Création du `.tar` + descripteur + push vers Artifactory scratch |
| Finalize | Bilan du build, durée |

Si la compilation échoue, les stages qualité et packaging sont ignorés. Les listings sont toujours archivés.

### Pipeline `auditEtQualite`

| Stage | Rôle |
|---|---|
| Début Pipeline | Initialisation |
| Init Env Vars | Lecture du manifest + téléchargement du descripteur depuis Artifactory + vérification existence dans applications.json |
| Audit | Clone du dépôt + appel `audit()` (conformité components/master, copybooks, dépendances) |
| Validation Quality Gate | Interrogation API SonarQube — échoue si quality gate KO |

**Prérequis :** le descripteur (`desc.json`) doit exister dans Artifactory — c'est-à-dire qu'un build `BuildAndPush` réussi doit avoir été effectué au préalable.

### Pipeline `PromoteUnitaire`

| Stage | Rôle |
|---|---|
| Start Pipeline | Parsing JSON, déduction extension, `config()`, init workspace USS, validation composant |
| Construction JCL | Résolution PDS (origin.params.json + promote.params.json), génération JCL pour chaque componentType (copy + BIND/MSK/PHASEIN/SPN selon type) |
| Exécution JCL | Soumission du JCL via `promote.sh`, récupération code retour et numéro JOB |
| Résultat | Analyse du code retour (0=OK, 1=écrasé, <5=avertissement, ≥5=erreur) |

**Codes retour du JCL PromoteUnitaire :**
- `JCLERR` → composant non compilé (PDS source vide)
- `0` → succès
- `1` → composant écrasé (déjà présent)
- `2–4` → certains composants absents (warning, ignorable si pas DB2)
- `5–8` → composants non déployés (FAILURE)
- `>8` → erreur grave (FAILURE)

### Pipeline `CleanUnitaire`

| Stage | Rôle |
|---|---|
| Start Pipeline | Parsing JSON, config, init workspace |
| Construction JCL | Génération de l'étape de suppression pour chaque type ; si LOT : ajout PHASEIN CICS |
| Exécution JCL | Soumission + récupération code retour ; nettoyage du workspace USS |
| Résultat | 0=OK, 8=composant déjà absent (warning), >8=erreur |

### Pipeline `ProxyCD`

| Stage | Rôle |
|---|---|
| Init vars | Initialisation du workspace, récupération du descripteur Artifactory, résolution du site, détermination de l'`action` |
| Traitements `<action>` | Dispatch vers `doAfterMep`, `doAfterRollback`, `doAfterMepApproved`, etc. selon le paramètre `action` |
| Notification Teams | Envoi d'une notification Teams (template HTML) quel que soit le résultat |
| Fin Pipeline | Nettoyage du workspace |

Les actions `doAfterMep` et `doAfterRollback` ont un traitement spécial en site `DEVD` : si des sites ont déjà été installés, l'action est requalifiée en `doAfterCascade` / `doAfterRollbackCascade`.

---

## Ce que le plugin ne fait PAS

- Il ne compile pas de code COBOL.
- Il ne déploie pas de fichiers sur les serveurs mainframe.
- Il n'effectue pas d'analyse de qualité.
- Il ne gère pas les résultats des pipelines (succès/échec du point de vue métier) — il se contente d'afficher les logs Jenkins.
- Il ne relance pas automatiquement un pipeline en échec.

Tout cela est à la charge des **pipelines Jenkins FabCI**.
