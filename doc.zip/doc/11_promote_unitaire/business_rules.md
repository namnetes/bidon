# Fonction 11 — Promote Unitaire

**Accès :** Clic droit sur un fichier dans l'explorateur IDz > Promote Unitaire
**Visible :** uniquement sur les fichiers (pas les répertoires)

---

## Contexte et objectif

Le **Promote Unitaire** permet de **promouvoir un seul composant** (un seul programme COBOL ou fichier source) vers l'environnement de test unitaire (`TU`), sans passer par un build complet de l'évolution. C'est une opération ciblée et rapide pour tester un composant isolément.

### Quand l'utiliser ?
- Pour tester rapidement la compilation d'un seul programme après une modification.
- Pour effectuer un test unitaire sur un composant précis sans impacter les autres.
- Comme alternative plus rapide au build complet quand seul un composant a changé.

---

## Concepts clés

### Promote vs Build
- **Builder (Ctrl+0)** : traite **tous** les composants du manifest via le pipeline de build.
- **Promote Unitaire** : traite **un seul** composant sélectionné via un pipeline dédié (`PromoteUnitaire`).

### Environnement cible
Le promote unitaire cible toujours l'environnement **TU** (Test Unitaire), quel que soit le toolchain configuré. C'est une convention fixe dans le code.

### Couloir (type d'application)
Le couloir identifie le circuit de promotion du composant :
- Application de type `STD` → couloir `STDA`
- Application de type `CRF` → couloir `CRFA`
- Tout autre type → le type lui-même est utilisé comme couloir

### Types de composant envoyés selon le répertoire
Certains répertoires correspondent à plusieurs types de composants Jenkins. La correspondance est :

| Répertoire du fichier | Types envoyés (`componentType`) |
|---|---|
| `src` | `[LOD, BGB, DBR]` |
| `srt` | `[LOT, BGT, DBR]` |
| Tout autre répertoire | `[<NOM_REPERTOIRE_EN_MAJUSCULES>]` |

Exemples : un fichier dans `asm` → `["ASM"]`, un fichier dans `skl` → `["SKL"]`.

### Répertoires autorisés
Seuls les fichiers présents dans ces répertoires sont éligibles au Promote Unitaire :
`asm`, `ast`, `cli`, `mps`, `msk`, `par`, `poe`, `skl`, `spn`, `src`, `srp`, `srt`, `srx`

Si le fichier est dans un autre répertoire (ex. `META-INF`, `dex_read_only`, `cpy`), le promote est refusé.

---

## Prérequis

- Un **fichier** (pas un dossier) doit être sélectionné dans l'explorateur IDz.
- Ce fichier doit être dans l'un des répertoires autorisés.
- Ce répertoire doit être un **répertoire de premier niveau** du projet (pas un sous-répertoire).
- Le projet doit contenir un manifest unique dans `META-INF/`.
- Le token Jenkins doit être configuré.

---

## Règles métier détaillées

### RG-01 : Visibilité de la commande
La commande "Promote Unitaire" n'apparaît dans le menu contextuel que si la sélection est un **fichier** (instance de `IFile`). Elle n'est pas visible sur les répertoires ou les projets.

### RG-02 : Vérification du répertoire
Le répertoire parent du fichier sélectionné est comparé à la liste des répertoires autorisés. De plus, ce répertoire doit exister en tant que **répertoire de premier niveau** dans le projet (pas imbriqué à un niveau plus profond). Si l'une de ces conditions n'est pas remplie, un message d'erreur est affiché et l'opération est annulée.

### RG-03 : Lecture du manifest
Le plugin lit le manifest unique dans `META-INF/` du projet auquel appartient le fichier. Ce manifest fournit :
- `application_code` → `appName` dans la commande Jenkins
- `manifest_number` → `version`
- `application_type` → calcul du `couloir`

Si le manifest est absent ou non unique, un message d'erreur est affiché.

### RG-04 : Construction de la commande JSON
Le plugin construit un objet JSON envoyé à Jenkins comme paramètre `commande` :

```json
{
  "appName": "da01",
  "version": "20250401-001",
  "site": "<DEPLOY_SITE_NAME>",
  "couloir": "STDA",
  "environment": "TU",
  "componentType": ["LOD", "BGB", "DBR"],
  "component": "MONPROG"
}
```

- `appName` : code application lu depuis le manifest
- `version` : numéro de manifest (ex. date + séquence)
- `site` : valeur de `deploy.site.name` dans la configuration du toolchain
- `couloir` : déduit du type d'application (`STD` → `STDA`, `CRF` → `CRFA`, sinon valeur brute)
- `environment` : toujours `TU` (Test Unitaire), valeur fixe
- `componentType` : tableau des types selon le répertoire du fichier
- `component` : nom du fichier **sans extension**, en majuscules

### RG-05 : Vérification et demande du token Jenkins
Si le token Jenkins est absent, la boîte de saisie s'ouvre automatiquement.

### RG-06 : Déclenchement du pipeline Jenkins
- **Nom du job :** `PromoteUnitaire` (valeur fixe dans le code, correspondant à la clé `jenkins.pipeline.promote.unitaire`)
- **Paramètre :** `commande` = chaîne JSON formatée

L'appel HTTP est : `POST <jenkins_url>/job/PromoteUnitaire/buildWithParameters?commande=<json_encodé>`

### RG-07 : Suivi de la progression (polling)
Même mécanique que les autres pipelines : polling de la file d'attente, puis polling du build jusqu'à sa fin. La vue Blue Ocean s'ouvre dans IDz.

### Infrastructure Jenkins (FabCI)
Le pipeline `PromoteUnitaire` tourne sur FabCI. L'URL dépend du toolchain :

| Toolchain | URL Jenkins |
|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca` |

---

## Exemple complet

Fichier sélectionné : `src/MONPROG.cbl` du projet `da01`
Manifest : `da01_correction_bug_42.mf.json`
Type d'application : `STD`
Numéro de manifest : `20250401-001`
Site : `SITE_PRINCIPAL`

JSON envoyé à Jenkins :
```json
{
  "appName": "da01",
  "version": "20250401-001",
  "site": "SITE_PRINCIPAL",
  "couloir": "STDA",
  "environment": "TU",
  "componentType": ["LOD", "BGB", "DBR"],
  "component": "MONPROG"
}
```

---

## Ce que fait Jenkins côté mainframe (pipeline `PromoteUnitaire`)

Le plugin se contente d'envoyer le JSON à Jenkins. Voici ce que Jenkins exécute :

### Stage 1 — Start Pipeline
- Parsing du JSON `commande`
- Affichage du type et du composant à déployer
- Déduction de l'extension du fichier (`.src` pour LOD, `.srt` pour LOT, sinon le type)
- Appel à `config()` pour initialiser les variables d'environnement
- Initialisation du workspace USS : `$USS_PROMOTE_PATH_WORKSPACE/<appName><version>`
- Validation du composant (`controlComponent`) : le composant doit exister dans les PDS d'origine

### Stage 2 — Construction du JCL
Génération dynamique d'un JCL de déploiement. Pour chaque type dans `componentType` :

1. **Résolution des PDS** via `getPDS()` : détermine les PDS source (`pdsIn`) et cible (`pdsOut`) à partir des fichiers de paramétrage `origin.params.json` et `promote.params.json`
2. **Vérification préalable** (`jclCheck`) : étape qui détecte si le composant est déjà présent dans le PDS cible (code retour 1 si écrasement)
3. **Action selon le type :**
   - `DBR` → étape BIND DB2 (`bindDB2Unitaire`) : lie le DBRM au plan DB2 cible
   - `MSK` → étape d'exécution du programme MSK (`executeMsk`) : traitement des masques BMS
   - `LOT` → étape de copie + PHASEIN CICS (`phasinCICS`) : copie du LOT puis rechargement dans le(s) CICS cible(s)
   - `SPN` → étape SPN (`executeSPNUnitaire`) : exécution du programme spanning
   - Tout autre type → étape de copie simple (`copyUnitaire`)

Le JCL construit est sauvegardé dans le workspace USS sous le nom `Z<APPNAME_MAJ><VERSION_COURTE>.jcl`.

### Stage 3 — Exécution du JCL
- Soumission du JCL via le script `promote.sh` sur USS
- Récupération du résultat : `message,code_retour,numéro_job`

### Stage 4 — Résultat du Promote

| Code retour | Statut build | Signification |
|---|---|---|
| `JCLERR` | FAILURE | JCL en erreur — le composant n'a pas été compilé au préalable |
| `0` | SUCCESS | Déploiement réussi |
| `1` | UNSTABLE | Au moins un composant écrasé (déjà présent, remplacé) |
| `2` à `4` | UNSTABLE | Certains composants absents du PDS source (ignorable si pas DB2) |
| `5` à `8` | FAILURE | Composants non déployés |
| `>8` | FAILURE | Erreur grave lors du déploiement |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Fichier dans un répertoire non autorisé | "Le fichier XXX ne peut être candidat à un Promote Unitaire" |
| Répertoire non présent au premier niveau du projet | Même message |
| Aucun manifest ou plusieurs manifests | Avertissement ou erreur de manifest |
| Token Jenkins absent | Boîte de saisie du token |
| Aucun projet sélectionné | "Veuillez sélectionner un projet dans l'explorateur" |
