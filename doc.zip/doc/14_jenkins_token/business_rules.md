# Fonction 14 — Jenkins Token

**Raccourci clavier :** `Ctrl+K`
**Menu :** zDevOps > Jenkins Token

---

## Contexte et objectif

Pour que le plugin puisse déclencher des jobs Jenkins (build, déploiement, audit, promote unitaire, clean unitaire), il a besoin d'un **token d'accès personnel Jenkins**. Cette fonction permet à l'utilisateur de **saisir et sauvegarder** son identifiant et son token Jenkins de manière sécurisée.

### Quand l'utiliser ?
- À la première utilisation du plugin sur un poste.
- Quand le token Jenkins expire et doit être renouvelé.
- Quand on change de toolchain et que le token doit être mis à jour pour ce nouvel environnement.

---

## Concepts clés

### Token d'API Jenkins (API Token)
Un token personnel Jenkins est généré depuis l'interface Jenkins (`Mon compte > Configure > API Token > Add new Token`). Il permet au plugin de s'authentifier auprès de l'API Jenkins pour déclencher des jobs, sans utiliser de mot de passe.

### Token par toolchain
Contrairement au token GitLab (qui est unique), le **token Jenkins est stocké séparément pour chaque toolchain** (dev, rec, frm, prd). En effet, chaque environnement peut avoir sa propre instance Jenkins avec des droits distincts. C'est la toolchain sélectionnée dans `zdevops.ini` qui détermine quel token est utilisé.

### Authentification Basic Auth
L'API Jenkins utilise l'authentification HTTP Basic Auth. Le plugin construit les credentials de la manière suivante :
```
Base64("<username>@id.fr.cly:<token>")
```
Le `username` est automatiquement déduit du login système Windows (`System.getProperty("user.name")`). L'utilisateur n'a qu'à fournir le token.

### Stockage sécurisé Eclipse
Comme pour le token GitLab, le token Jenkins est **chiffré dans le coffre-fort Equinox** d'Eclipse. Il n'est jamais stocké en clair.

---

## Règles métier détaillées

### RG-01 : Boîte de dialogue de saisie
La boîte `JenkinsAuthenticateDialog` demande à l'utilisateur de saisir :
- Son **mot de passe** Jenkins (si nécessaire selon la configuration).
- Son **token d'API** Jenkins.

### RG-02 : Validation de la saisie
Les deux champs (mot de passe et token) doivent être non vides pour que la sauvegarde soit effectuée. Si l'un est vide, la sauvegarde est ignorée.

### RG-03 : Stockage sécurisé
Le token est stocké via `EclipsePluginHelper.storeJenkinsTokenSecurely()`. L'association toolchain → token est gérée par le mécanisme de stockage.

### RG-04 : Déclenchement automatique de la boîte
La boîte de saisie du token Jenkins s'ouvre **automatiquement** (sans que l'utilisateur ait à appuyer sur `Ctrl+K`) si le token est absent lors d'une tentative de :
- Builder (Ctrl+0)
- Déployer (Ctrl+B)
- Audit (Ctrl+6)
- Promote Unitaire (clic droit)
- Clean Unitaire (clic droit)

C'est un filet de sécurité pour guider l'utilisateur dès la première utilisation.

### RG-05 : Construction des credentials Jenkins
La méthode `getJenkinsUserCredentials()` dans `AppProperties` construit les credentials :
```java
Base64.encode("<user.name>@id.fr.cly:<token>")
```
Ces credentials sont ensuite utilisés dans le header HTTP `Authorization: Basic <credentials>` pour tous les appels à l'API Jenkins.

### RG-06 : Pas de validation automatique
Le plugin ne vérifie pas la validité du token au moment de la saisie. La validité est vérifiée lors du premier appel à Jenkins. Un token invalide génère une erreur HTTP 401 ou 403.

---

## Comment générer un token API Jenkins ?

1. Se connecter à l'instance Jenkins du toolchain.
2. Cliquer sur son nom d'utilisateur (en haut à droite).
3. Aller dans **Configuration** (ou **Configure**).
4. Section **API Token** : cliquer sur **"Add new Token"**.
5. Nommer le token (ex. : `idz-plugin`).
6. Cliquer sur **"Generate"**.
7. Copier le token affiché (il ne sera montré qu'une seule fois).
8. Le coller dans la boîte de dialogue Jenkins Token du plugin.

---

## Différences entre GitLab Token et Jenkins Token

| Critère | GitLab Token | Jenkins Token |
|---|---|---|
| Raccourci | Ctrl+E | Ctrl+K |
| Portée | Partagé entre tous les toolchains | Spécifique à chaque toolchain |
| Utilisation | API GitLab + opérations JGit | API Jenkins (déclenchement de jobs) |
| Authentification | Token seul | Basic Auth (username:token encodé Base64) |
| Username | Déduit automatiquement du login système | Déduit automatiquement du login système |
| Stockage | Coffre-fort Equinox | Coffre-fort Equinox |

---

## Séquence complète

```
1. L'utilisateur appuie sur Ctrl+K (ou la boîte s'ouvre automatiquement)
2. La boîte de dialogue s'ouvre
3. L'utilisateur saisit son mot de passe et son token Jenkins
4. Clique sur OK
5. Le token est stocké dans le stockage sécurisé Eclipse
6. Les appels API Jenkins sont désormais authentifiés pour le toolchain courant
```

---

## Erreurs possibles

| Situation | Comportement |
|---|---|
| Token ou mot de passe vide | Le stockage n'est pas mis à jour |
| L'utilisateur clique sur Annuler | Message d'avertissement, opération Jenkins annulée |
| Token invalide (Jenkins renvoie 401/403) | Erreur lors du déclenchement du job Jenkins |
| Erreur d'accès au stockage sécurisé | `StorageException` affichée à l'utilisateur |
