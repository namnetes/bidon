# Fonction 10 — Audit

**Raccourci clavier :** `Ctrl+6`
**Menu :** zDevOps > Audit

---

## Contexte et objectif

L'**audit qualité** est une analyse automatisée du code source de l'évolution. Cette fonction déclenche le pipeline Jenkins d'audit qualité (`jenkins.pipeline.audit.qualite`) en lui transmettant le nom du manifest de l'évolution courante. Le pipeline effectue des contrôles (normes de codage, qualité, métriques) et produit un rapport.

### Quand l'utiliser ?
- Avant de soumettre une évolution à la recette, pour détecter des anomalies de code.
- Dans le cadre d'une démarche d'amélioration continue de la qualité.
- Quand l'équipe qualité l'exige en porte d'entrée du processus de livraison.

---

## Concepts clés

### Pipeline d'audit qualité
Job Jenkins identifié par la clé `jenkins.pipeline.audit.qualite`. Il analyse les sources de l'évolution et produit un rapport de qualité.

### Différence Audit / Build / Déploiement

| Fonction | Pipeline | Objectif |
|---|---|---|
| Builder (Ctrl+0) | `jenkins.pipeline.build` | Compiler les sources |
| Déployer (Ctrl+B) | `jenkins.pipeline.deploy` | Installer dans un environnement |
| Audit (Ctrl+6) | `jenkins.pipeline.audit.qualite` | Analyser la qualité du code |

---

## Prérequis

- Un projet doit être sélectionné dans l'explorateur IDz.
- Le projet doit contenir un manifest unique dans `META-INF/`.
- Le token Jenkins doit être configuré.

---

## Règles métier détaillées

### RG-01 : Vérification du projet courant
Le projet actif est identifié via la sélection dans l'explorateur ou le fichier ouvert dans l'éditeur. Si aucun projet, avertissement et annulation.

### RG-02 : Vérification et demande du token Jenkins
Si le token Jenkins est absent du stockage sécurisé, la boîte de saisie s'affiche automatiquement avant de procéder.

### RG-03 : Lecture du manifest courant
Le nom du manifest présent dans `META-INF/` du projet actif est lu (sans `.mf.json`).

### RG-04 : Déclenchement du pipeline d'audit
Appel API REST Jenkins :
- **Nom du job :** `auditEtQualite` (configuré sous la clé `jenkins.pipeline.audit.qualite`)
- **Paramètre :** `NomManifest` = nom du manifest courant

L'appel HTTP est : `POST <jenkins_url>/job/auditEtQualite/buildWithParameters?NomManifest=<nom>`

### RG-05 : Suivi de la progression (polling)
Même mécanique que le Builder et le Déployer :
1. Polling de la file d'attente Jenkins toutes les 2 secondes jusqu'au démarrage.
2. Polling de `<build_url>/api/json` jusqu'à ce que `building = false`.
3. La vue **Jenkins Blue Ocean** s'ouvre automatiquement dans IDz.

### Infrastructure Jenkins (FabCI)
Le pipeline `auditEtQualite` tourne sur FabCI. L'URL dépend du toolchain :

| Toolchain | URL Jenkins |
|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca` |

---

## Ce que fait Jenkins côté mainframe (pipeline `auditEtQualite`)

### Prérequis côté Jenkins
Le pipeline nécessite que l'artefact ait été buildé au moins une fois : il lit le **descripteur `.desc.json`** dans Artifactory pour connaître le tag Git et les composants compilés. Sans descripteur, le pipeline échoue avec un message explicite.

### Stage 1 — Début Pipeline / Init Env Vars
- Lecture du manifest depuis les paramètres Jenkins (`NomManifest`)
- Déduction de `APP_NAME` et `APP_BRANCH` depuis le nom du manifest
- Téléchargement du fichier `applications.json` depuis GitLab pour valider l'application
- Construction de l'URL du descripteur dans Artifactory scratch
- Téléchargement et parsing du descripteur

### Stage 2 — Audit
Le pipeline clone le dépôt de l'application sur le serveur Jenkins (pas sur z/OS), puis exécute la fonction `audit()` de la shared library Groovy. Cette fonction réalise :

1. **Conformité avec `master`** : vérifie que les commits de l'évolution sont basés sur la dernière version de `master` (protection contre les divergences)
2. **Analyse des copybooks** : détecte les instructions `COPY` dans les sources COBOL et vérifie que les copybooks référencés correspondent à des versions attendues
3. **Résolution des dépendances** : charge les branches des évolutions déclarées comme dépendances dans le manifest
4. **Vérification des copybooks dépendants** : s'assure que les copybooks des dépendances n'ont pas été modifiés depuis leur déclaration (évite les surprises lors du build)

### Stage 3 — Validation Quality Gate
- Interrogation directe de l'API SonarQube pour lire le statut de la quality gate du projet
- URL : `https://lcl.code.quality.cagip.group.gca/sonarqube`
- Si quality gate `ERROR` ou `WARN` → le stage échoue et le pipeline est en `FAILURE`
- Si quality gate `OK` → validation réussie

### Résultats possibles

| Résultat | Signification |
|---|---|
| `SUCCESS` | Conformité OK + quality gate passée |
| `FAILURE` | Non-conformité avec master, copybooks modifiés, ou quality gate KO |

---

## Séquence complète

```
1. L'utilisateur sélectionne son projet dans l'explorateur IDz
2. Appuie sur Ctrl+6
3. Vérification du token Jenkins
4. Lecture du manifest : "da01_correction_bug_42"
5. Appel API Jenkins :
   POST /job/<pipeline_audit_qualite>/buildWithParameters
   Paramètre : NomManifest=da01_correction_bug_42
6. Suivi du job jusqu'à la fin
7. Résultat : rapport d'audit disponible via Jenkins Browser
```

---

## Paramètre envoyé à Jenkins

| Nom du paramètre | Valeur |
|---|---|
| `NomManifest` | Nom du manifest sans extension |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Aucun projet sélectionné | "Veuillez sélectionner un projet dans l'explorateur" |
| Token Jenkins absent | Boîte de saisie du token |
| Échec de l'exécution du pipeline | "ERREUR : echec de l'exécution de l'audit" |
