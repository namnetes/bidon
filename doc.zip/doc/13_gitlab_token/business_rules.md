# Fonction 13 — GitLab Token

**Raccourci clavier :** `Ctrl+E`
**Menu :** zDevOps > GitLab Token

---

## Contexte et objectif

Pour que le plugin puisse communiquer avec GitLab (créer des branches, cloner des dépôts, lire les manifests, etc.), il a besoin d'un **token d'accès personnel GitLab**. Cette fonction permet à l'utilisateur de **saisir et sauvegarder** ce token de manière sécurisée dans l'IDE.

### Quand l'utiliser ?
- À la première utilisation du plugin sur un poste.
- Quand le token GitLab expire et doit être renouvelé.
- Quand l'utilisateur change de compte GitLab.

---

## Concepts clés

### Token d'accès personnel GitLab (Personal Access Token)
Un token d'accès personnel est un identifiant généré depuis l'interface GitLab (`User Settings > Access Tokens`). Il permet au plugin de s'authentifier auprès de l'API GitLab sans utiliser de mot de passe. Il peut avoir des droits limités (lecture seule, lecture/écriture) et une date d'expiration.

### Stockage sécurisé Eclipse (Equinox Secure Storage)
Le token n'est **jamais stocké en clair** dans un fichier texte. Il est chiffré dans le **coffre-fort sécurisé d'Eclipse** (Equinox Security Storage), un mécanisme standard d'Eclipse qui protège les données sensibles. L'accès est lié au compte utilisateur du système d'exploitation.

### Token partagé entre tous les toolchains
Contrairement au token Jenkins (qui est par toolchain), le **token GitLab est unique** et partagé pour tous les environnements (dev, rec, frm, prd). Cela est possible car le serveur GitLab est le même quelle que soit la toolchain.

### Synchronisation avec EGit
Après sauvegarde du token, le plugin configure automatiquement le `CredentialsProvider` JGit utilisé pour les opérations Git (`clone`, `push`, `pull`, `fetch`). Le nom d'utilisateur est le login système (`System.getProperty("user.name")`), et le mot de passe est le token GitLab.

---

## Règles métier détaillées

### RG-01 : Boîte de dialogue de saisie
La boîte de dialogue `GitlabAuthenticateDialog` demande à l'utilisateur de saisir :
- Son token d'accès personnel GitLab.
- Éventuellement son mot de passe (si requis pour certaines opérations Git).

### RG-02 : Validation de la saisie
- Le token ne doit pas être vide.
- Si l'utilisateur annule ou ne saisit rien, aucune modification n'est effectuée.

### RG-03 : Stockage sécurisé
Le token est stocké dans le stockage sécurisé Eclipse via `EclipsePluginHelper.storeGitLabTokenSecurely()`. Il est chiffré automatiquement par Equinox.

### RG-04 : Utilisation du token
Le token est utilisé dans deux contextes :
1. **API GitLab (gitlab4j)** : pour les appels REST (liste des branches, lecture des manifests, création de branches, etc.).
2. **Opérations JGit** : pour les opérations `clone`, `push`, `pull`, `fetch` sur les dépôts Git.

### RG-05 : Pas de validation automatique
Le plugin **ne vérifie pas** si le token est valide au moment de sa saisie. La validité est vérifiée lors de la première utilisation (accès à l'API GitLab ou opération JGit). Si le token est invalide, une erreur d'authentification est renvoyée lors de l'opération.

### RG-06 : Récupération du token au démarrage
Au démarrage du plugin (lors de l'activation de l'`Activator`), le token est récupéré depuis le stockage sécurisé et le `CredentialsProvider` JGit est initialisé. Si aucun token n'est stocké, le provider reste `null` et les opérations Git nécessitant une authentification échoueront.

---

## Comment générer un token GitLab ?

1. Se connecter à l'interface GitLab.
2. Aller dans : **User Settings > Access Tokens** (ou **Préférences > Jetons d'accès**).
3. Créer un nouveau token avec les droits :
   - `read_repository` (lecture des dépôts)
   - `write_repository` (écriture / push)
   - `api` (accès à l'API REST)
4. Copier le token généré (il ne sera affiché qu'une seule fois).
5. Le coller dans la boîte de dialogue `GitLab Token` du plugin.

---

## Séquence complète

```
1. L'utilisateur appuie sur Ctrl+E
2. La boîte de dialogue s'ouvre
3. L'utilisateur saisit son token GitLab
4. Clique sur OK
5. Le token est stocké dans le stockage sécurisé Eclipse
6. Le CredentialsProvider JGit est mis à jour
7. Les opérations GitLab et Git sont désormais authentifiées
```

---

## Erreurs possibles

| Situation | Comportement |
|---|---|
| Token vide à la validation | Le stockage n'est pas mis à jour |
| Token invalide (vérifié lors d'une opération) | Erreur `GitLabAuthenticationException` ou `InvalidTokenException` |
| Erreur d'accès au stockage sécurisé | `StorageException` affichée à l'utilisateur |
