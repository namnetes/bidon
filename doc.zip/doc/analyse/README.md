# Analyse critique du système zDevOps

Ce répertoire contient l'analyse critique et indépendante de la plateforme zDevOps — bugs confirmés, questions architecturales, risques de sécurité et risques processus.

> Ces documents sont le résultat d'un questionnement approfondi sur un **SI bancaire critique**. La sévérité des observations est évaluée en tenant compte du contexte : une plateforme CI/CD qui touche au code mainframe de production LCL.

---

## Documents

| Fichier | Contenu |
|---|---|
| [bugs_averes.md](bugs_averes.md) | Bugs confirmés avec preuves et corrections (M1–M5, m1–m5) |
| [questions_architecture.md](questions_architecture.md) | Choix architecturaux discutables, questions ouvertes, dette technique |
| [risques_securite.md](risques_securite.md) | Risques de sécurité identifiés dans le plugin et les pipelines |
| [risques_processus.md](risques_processus.md) | Risques dans le processus CI/CD mainframe (non-qualités de la chaîne) |

---

## Synthèse des sévérités

### Bugs avérés

| ID | Fichier | Gravité | Résumé |
|---|---|---|---|
| M1 | `GitLabService.java` | 🔴 Critique | Race condition non atomique sur `applications.json` — doublons de numéros d'artefact |
| M2 | `Activator.java` | 🔴 Critique | `changeListener` en variable locale → fuite mémoire, listener jamais retiré |
| M3 | `GitLabService.java` | 🔴 Critique | `writeBranchManifest` non atomique — état incohérent garanti en cas d'échec réseau |
| M4 | `GitLabService.java` | 🔴 Critique | `commitChanges` avale silencieusement toutes les erreurs Git |
| M5 | `GitLabService.java` | 🔴 Critique | `switcherBranche` commite sans consentement utilisateur |
| m1 | `GitLabService.java` | 🟡 Mineur | `TextProgressMonitor` double-initialisé |
| m2 | `GitLabService.java` | 🟡 Mineur | `updateHlq` retours silencieux en cas d'erreur |
| m3 | `GitLabService.java` | 🟡 Mineur | Remplacement `F000000` fragile — cassé dès la 2ème évolution |
| m4 | `GitLabService.java` | 🟡 Mineur | `startNewEvolution` corps vide (TODO) dans l'interface publique |
| m5 | Partout | 🟡 Mineur | Logging incohérent (4 mécanismes coexistants) |

### Questions architecture

| ID | Gravité | Résumé |
|---|---|---|
| A1 | 🟠 Majeur | `AppProperties` entièrement statique — testabilité nulle |
| A2 | 🟠 Majeur | `GitLabService` God Object (~1800 lignes, 6 responsabilités) |
| A3 | 🟡 Mineur | Validation token GitLab commentée |
| A4 | 🟡 Mineur | Pas de stratégie de retry réseau |
| A5 | 🟠 Majeur | Fragment OSGi vide — rôle non documenté |
| A6 | 🟠 Majeur | `storeGitLabTokenSecurely()` commentée — stockage GitLab dépend exclusivement d'EGit |
| A7 | 🔴 Critique | `GITLAB_API` statique périmée si token changé en session |
| A8 | 🟡 Mineur | Nœud de stockage GitLab codé en dur — non lu depuis les properties |
| A9 | 🟠 Majeur | Typo `dependancies` fossilisée dans le schéma JSON |
| A10 | 🟠 Majeur | Pas de versioning du schéma manifest |
| A11 | 🔴 Critique | Polling Jenkins sans timeout global |
| A12 | 🔴 Critique | Blue Ocean officiellement déprécié (fin de vie 2025–2026) — dépendance non déclarée |
| A13 | 🟠 Majeur | `HttpClient` Java 11 sans timeout configuré |
| A14 | 🟠 Majeur | Jenkins en déclin structurel de marché — risque stratégique à horizon 3–5 ans |

### Risques sécurité

| ID | Gravité | Résumé |
|---|---|---|
| S1 | 🔴 Critique | Auto-commit M5 peut exposer du code sensible/debug en production Git |
| S2 | 🟠 Majeur | Domaine `@id.fr.cly` codé en dur — rupture si domaine change |
| S3 | 🟠 Majeur | Token GitLab partagé tous toolchains — surface d'exposition maximale |
| S4 | 🟡 Mineur | Validation GitLab token commentée — pas de feedback anticipé |
| S7 | 🔴 Critique | Mot de passe Windows AD injecté en clair dans JavaScript (`JsLink.auth()`) |
| S8 | 🟠 Majeur | Sélecteurs CSS Blue Ocean (`Header-topNav`, `.stop-button`) — fragilité si Blue Ocean retiré |

### Risques processus

| ID | Gravité | Résumé |
|---|---|---|
| P1 | 🔴 Critique | Pas de timeout sur les callbacks ProxyCI — déploiement peut rester indéterminé |
| P2 | 🔴 Critique | `this."${actionSelected}"()` dans proxyci — injection de code potentielle |
| P3 | 🟠 Majeur | `updateHlq` — `zapp.yaml` non mis à jour dès la 2ème évolution |
| P4 | 🟠 Majeur | Pas de vérification préalable build avant Audit ou Promote |
| P5 | 🟡 Mineur | `deleteDir()` dans CleanUnitaire exécuté même en cas d'erreur grave |
| P6 | 🟡 Mineur | Règle cascade DEVD implicite et fragilité sur état intermédiaire |
| P10 | 🟠 Majeur | Aucune vérification de synchro locale/distante avant opérations manifest et build |
