# Risques de sécurité — Plugin zDevOps IDz

Ce document identifie les risques de sécurité dans le plugin IDz et les pipelines Jenkins FabCI, dans le contexte d'un **SI bancaire critique** soumis aux exigences de traçabilité et de contrôle des accès.

---

## S1 — Auto-commit non consenti (issu de M5) — risque critique pour un SI bancaire

**Fichier :** `GitLabService.java` — `switcherBranche()`

### Description

La fonction `switcherBranche()` commite automatiquement **tout le contenu non commité** du dépôt local avant de changer de branche, sans demander l'accord du développeur.

### Risques de sécurité spécifiques à LCL

1. **Code de debug ou de contournement** : un développeur qui laisse des `DISPLAY "DEBUGVAL=", WS-VARIABLE` ou des contournements temporaires de contrôles dans ses sources peut les voir commités et potentiellement déployés en production.

2. **Données sensibles hardcodées pour les tests** : si un développeur a temporairement codé en dur un numéro de compte, un code secret ou des paramètres de connexion pour tester, ces données peuvent se retrouver dans l'historique Git — visible à tout porteur du dépôt.

3. **Violation du principe des quatre yeux** : un commit non intentionnel bypasse les contrôles habituels de revue de code (merge request, approbation). Le code entre en production sans validation humaine explicite.

4. **Traçabilité** : le message de commit est un emoji générique (`"🎯 Validation des changements sur la branche ..."`) et ne correspond à aucune évolution, ticket ou intention réelle. L'audit trail Git devient pollué et inexploitable.

### Évaluation

Pour un SI bancaire soumis à des audits PCI-DSS, SOX ou aux exigences ACPR, un commit automatique non consenti dans un dépôt qui alimente la production constitue une non-conformité sérieuse.

---

## S2 — Domaine `@id.fr.cly` codé en dur dans les credentials Jenkins

**Fichier :** `AppProperties.java`, ligne 191

```java
public String getJenkinsUserUsername() {
    return String.format("%s@id.fr.cly", System.getProperty("user.name"));
}
```

### Risques

1. **Si le domaine Active Directory change** (migration, fusion d'entités, changement de naming convention), tous les tokens Jenkins deviennent invalides sans message d'erreur clair. Les développeurs devront régénérer leurs tokens avec le nouveau domaine.

2. **Utilisateurs avec un format de login différent** : les comptes de service ou les comptes prestataires peuvent ne pas suivre le format `<login>@id.fr.cly`. Ces utilisateurs ne pourront pas utiliser le plugin.

3. **Même problème pour le username EGit** : `storeGitLabTokenForEGit()` utilise `Base64("<login>@id.fr.cly")` comme valeur du champ `user`. Si EGit attend un format différent, l'authentification JGit échoue silencieusement.

### Recommandation

Externaliser ce suffixe dans les properties :
```properties
jenkins.user.domain=@id.fr.cly
```

---

## S3 — Token GitLab partagé entre tous les toolchains

**Fichier :** `EclipsePluginHelper.java` — `retrieveGitLabTokenSecurely()`

### Description

Le token GitLab est stocké dans un nœud Secure Storage commun à tous les toolchains (`/GIT/https:\2f\2fscm.saas.cagip.group.gca:443`). Un même token accède donc aux groupes GitLab `dev`, `rec`, `frm` ET `prd`.

### Risques

1. **Surface d'exposition maximale** : un token GitLab volé (phishing, fichier de log, screen capture) donne accès à tous les dépôts de production en lecture ET en écriture.

2. **Rotation des tokens** : un token doit avoir une durée de vie limitée. Si le token de développement et le token de production sont le même, la fréquence de rotation doit satisfaire la politique la plus restrictive (celle de production) pour toutes les toolchains — ce qui peut être contraignant.

3. **Moindre privilège non respecté** : un développeur qui n'a accès qu'à `dev` en écriture devrait avoir un token avec des droits limités. Un token unique pour tous les environnements ne permet pas ce contrôle fin.

### Question

Est-ce que le serveur GitLab est le même pour `dev` et `prd` ? Si oui, les droits d'accès sont-ils gérés au niveau des groupes GitLab (un groupe par toolchain) ? Si le même token a des droits Developer sur `dev` et Reporter sur `prd`, le risque est limité côté GitLab mais pas côté plugin (qui ne vérifie pas les droits avant d'écrire).

---

## S4 — Validation token GitLab commentée : détection tardive des tokens invalides

**Fichier :** `EclipsePluginHelper.java`, méthode `isValidGitLabToken()` — implémentée mais non appelée

### Description

La méthode de validation est disponible mais son appel est commenté au démarrage du plugin. Le token n'est validé qu'à la première opération GitLab — qui peut être plusieurs minutes après le démarrage d'IDz.

### Risque

Un développeur avec un token expiré ou révoqué peut travailler normalement dans IDz jusqu'à ce qu'il tente une opération réseau. S'il réalise que son token est invalide au moment de créer une évolution (après avoir rempli le formulaire), il perd son travail de saisie.

Plus grave : si la validation échoue en milieu d'une opération (ex: après le clone local mais avant le push), le dépôt local peut être dans un état partiel incohérent (voir M3).

---

## S5 — Injection potentielle dans `proxyci.jenkinsfile`

**Fichier :** `fabrique_ci/proxyci.jenkinsfile`, lignes 126–128

```groovy
stage("Traitements ${actionSelected}") {
    this."${actionSelected}"(descriptorsJSON, descriptorsUrl, returnDate)
}
```

### Description

Le pipeline ProxyCI exécute dynamiquement la méthode Groovy dont le nom est fourni dans le paramètre `action` (reçu du service CD CAGIP). Si ce paramètre est contrôlé par un attaquant, il peut exécuter n'importe quelle méthode dans le scope du pipeline.

### Scénario d'attaque

Si le service CD CAGIP était compromis ou si la communication entre FabCI et le service CD n'est pas protégée (ex: pas de signature des callbacks), un attaquant pourrait envoyer un callback avec `action=cleanWs` (supprime le workspace), `action=sh` (exécute un shell), ou toute autre méthode Groovy accessible dans le contexte Jenkins.

### Évaluation

Ce risque dépend de la sécurisation du canal de communication entre FabCI et le service CD CAGIP. S'il est protégé par TLS mutuel ou une validation d'origine, le risque est faible. S'il s'agit d'un simple HTTP(S) sans validation de contenu, c'est une surface d'attaque réelle.

### Correction

Valider `actionSelected` contre une liste blanche explicite avant l'appel dynamique :

```groovy
def allowedActions = ['doAfterMep', 'doAfterCascade', 'doAfterMepApproved',
                      'doAfterMepRejected', 'doAfterMepCanceled', 'doAfterRollback',
                      'doAfterCancelRejected', 'doWhenExpired', 'doAfterFail']

if (!allowedActions.contains(actionSelected)) {
    error("Action non autorisée : ${actionSelected}")
}
this."${actionSelected}"(...)
```

---

## S6 — Pas de vérification des droits Developer avant opération d'écriture GitLab

**Fichier :** `EclipsePluginHelper.java` — méthode `hasWritenAccess()` implémentée mais non systématiquement appelée

### Description

La méthode `hasWritenAccess()` vérifie que l'utilisateur a le niveau Developer sur un projet GitLab. Mais elle n'est pas appelée systématiquement avant les opérations d'écriture (création de branche, push, modification de `applications.json`).

### Risque

Un utilisateur avec un rôle Reporter (lecture seule) dans GitLab peut tenter toutes les opérations d'écriture du plugin. Il recevra une erreur GitLab 403, mais le plugin peut laisser le dépôt local dans un état partiel avant d'atteindre l'opération réseau qui échoue.

---

## S7 — Mot de passe Windows Active Directory injecté en clair dans du JavaScript (critique)

**Fichier :** `JsLink.java`, méthode `auth()`, lignes 70–82

### Description

La vue Jenkins Browser (`JenkinsBrowserView`) charge une page Blue Ocean et, dès que la page est chargée, injecte automatiquement les identifiants de l'utilisateur dans le formulaire de connexion Jenkins. Le code injecté :

```javascript
document.querySelector('[name="j_username"]').value = 'prenom.nom@id.fr.cly';
document.querySelector('[name="j_password"]').value = 'MOT_DE_PASSE_WINDOWS_EN_CLAIR';
document.forms[0].submit();
```

Le mot de passe provient de `AppProperties.getUserPassword()` qui lit le mot de passe Windows (Active Directory) stocké dans le Secure Storage Eclipse.

### Risques

1. **Exposition du mot de passe AD en mémoire vive** : le mot de passe est instancié en tant que `String` Java dans `private static final String JENKINS_UI_PASSWORD = AppProperties.getUserPassword()`. Les `String` Java sont immuables et internées — ce mot de passe reste en mémoire JVM jusqu'au GC, potentiellement visible dans un heap dump.

2. **Exposition dans le contenu JavaScript** : le mot de passe est interpolé dans une `String.format(...)` comme n'importe quelle variable — tout outil de capture de trafic HTTP local (proxy Burp, Fiddler, Wireshark sur loopback) peut le lire si le SWT Browser communique en HTTP.

3. **Visibilité DevTools** : selon le SWT Browser backend utilisé (Chromium via CEF, WebKit, IE), les DevTools peuvent être accessibles et permettraient de voir les valeurs injectées dans les champs `j_username` et `j_password`.

4. **`JENKINS_UI_PASSWORD` est `static final`** : il est initialisé au chargement de la classe et reste en mémoire pour toute la durée de vie d'IDz. Un changement de mot de passe AD nécessite un redémarrage complet d'IDz.

5. **Surface d'attaque sur le formulaire Jenkins** : le formulaire de login Jenkins (`j_username` / `j_password`) correspond à l'authentification **formulaire web**, pas à l'API Token. Cela signifie que le **mot de passe AD réel** (pas un token révocable) est utilisé pour s'authentifier sur Jenkins via la vue browser — contrairement au token Jenkins utilisé pour l'API REST.

### Pourquoi c'est différent du token Jenkins

| Authentification | Valeur transmise | Révocable sans impact AD ? |
|---|---|---|
| API REST Jenkins (fonctions 8, 9, 10, 11, 12) | Token Jenkins (API Token) | Oui — le token peut être révoqué depuis Jenkins |
| Formulaire login Jenkins (Blue Ocean view) | **Mot de passe Windows AD** | Non — changer le token ne suffit pas |

### Recommandation immédiate

Remplacer l'authentification par formulaire par l'authentification par **cookie de session Jenkins** obtenu via l'API REST :

```java
// Obtenir un cookie de session Jenkins via l'API REST (Basic Auth avec API Token)
// puis injecter ce cookie dans le SWT Browser pour Blue Ocean
// → Le mot de passe AD n'est jamais exposé
```

Ou, plus simplement : ne pas utiliser l'authentification automatique dans la vue browser, et laisser l'utilisateur se connecter manuellement à Jenkins si nécessaire.

---

## S8 — Blue Ocean : dépendance à des sélecteurs CSS internes (fragilité)

**Fichier :** `JsLink.java`

### Description

Les sélecteurs CSS utilisés dans les scripts injectés sont des détails d'implémentation internes de Blue Ocean :

| Sélecteur | Fonction | Risque |
|---|---|---|
| `Header-topNav` | Masquer la barre de navigation Blue Ocean | Renommé ou supprimé si Blue Ocean est mis à jour ou retiré |
| `.stop-button` | Arrêter un build | Idem |
| `.replay-button` | Relancer un build | Idem |

Blue Ocean est officiellement en **maintenance-only** depuis Jenkins 2.387.x. La documentation Jenkins officielle recommande de migrer vers la vue Pipeline du contrôleur Jenkins classique.

### Conséquences si Blue Ocean est retiré de FabCI

1. Les URLs Blue Ocean construites dans `JenkinsJobService.toBlueOceanUrl()` renvoient HTTP 404
2. Le composant SWT Browser affiche une page d'erreur
3. `jsLink.hideTopNav()` et `jsLink.stop()` / `jsLink.replay()` ne fonctionnent plus
4. La vue Jenkins dans IDz devient inutilisable — le développeur ne peut plus suivre ses builds depuis l'IDE

### Question

Quelle est la version actuelle de Jenkins sur FabCI PRD ? Blue Ocean est-il activement maintenu et présent sur cette instance ?

---

## Synthèse des recommandations sécurité

| Priorité | Action |
|---|---|
| 🔴 Immédiate | **S7** — Supprimer l'injection du mot de passe AD dans JavaScript (`JsLink.auth()`) |
| 🔴 Immédiate | Corriger M5 (`switcherBranche`) — remplacer l'auto-commit par une confirmation explicite |
| 🔴 Immédiate | Valider la liste blanche des `action` dans `proxyci.jenkinsfile` |
| 🟠 Court terme | **S8** — Préparer un plan de migration depuis Blue Ocean (vérifier version Jenkins FabCI) |
| 🟠 Court terme | Séparer les tokens GitLab par toolchain (un token par environnement) |
| 🟠 Court terme | Externaliser le domaine Jenkins `@id.fr.cly` dans les properties |
| 🟡 Moyen terme | Réactiver la validation du token GitLab au démarrage du plugin |
| 🟡 Moyen terme | Externaliser l'URL GitLab dans le nœud Secure Storage (ne pas coder en dur) |
