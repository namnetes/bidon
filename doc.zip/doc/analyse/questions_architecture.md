# Questions d'architecture — Plugin zDevOps IDz

Ce document liste les choix architecturaux qui méritent une remise en question, les dettes techniques, et les zones d'ombre. Chaque question est formulée du point de vue d'un architecte indépendant qui analyse le système pour la première fois.

---

## A1 — `AppProperties` entièrement statique : testabilité nulle

**Fichier :** `AppProperties.java`

### Observation

Toute la configuration du plugin est initialisée dans un bloc `static {}` au chargement de la classe. Il est impossible de fournir une configuration différente sans modifier les vrais fichiers `.properties` embarqués dans le plugin.

### Conséquence

Toute classe qui dépend de `AppProperties` (directement ou via `EclipsePluginHelper`) ne peut pas être testée unitairement de façon isolée. Le seul moyen de tester est d'avoir un vrai workspace Eclipse avec un vrai `zdevops.ini` — ce qui n'est pas de l'unit testing.

### Question

Comment teste-t-on les méthodes de `GitLabService` ou `JenkinsJobService` aujourd'hui ? Existe-t-il des tests unitaires ? Si non, comment valide-t-on que les changements ne cassent pas le comportement existant ?

### Recommandation

Introduire une interface `IAppConfig` injectée via le constructeur :
```java
public GitLabService(IAppConfig config) { this.config = config; }
// En test : new GitLabService(new TestConfig("dev", "http://mock-jenkins"))
```

---

## A2 — `GitLabService` est un God Object

**Fichier :** `GitLabService.java` (~1800 lignes)

### Observation

Une seule classe gère :
1. API GitLab REST (gitlab4j)
2. Opérations JGit locales (clone, commit, push, pull, checkout)
3. Sérialisation/désérialisation du manifest JSON
4. Mise à jour du fichier YAML (`zapp.yaml`)
5. Gestion du référentiel d'applications (`applications.json`)
6. Téléchargement des copybooks

### Question

Le README mentionne que la "fusion de GitLabService et GitService est un chantier". Mais le sens correct serait d'**extraire** davantage, pas de fusionner. Qui arbitre le refactoring ? Existe-t-il une feuille de route pour découper cette classe ?

### Recommandation

Découper en services spécialisés selon le principe de responsabilité unique :
- `EvolutionService` : créer/rejoindre des branches
- `ManifestService` : lire/écrire les manifests
- `CopybookService` : gérer les copybooks
- `ApplicationRegistryService` : gérer `applications.json`
- `GitLocalService` : opérations JGit (clone, commit, push)
- `GitLabRemoteService` : appels API REST GitLab

---

## A3 — Validation du token GitLab commentée

**Fichier :** `GitLabService.java`, lignes 131–137  
**Fichier :** `EclipsePluginHelper.java`, lignes 151–162

### Observation

La méthode `isValidGitLabToken()` est implémentée dans `EclipsePluginHelper` mais le bloc de validation au démarrage est commenté dans `GitLabService`.

### Question

Pourquoi est-ce commenté ? Est-ce une performance (un appel API supplémentaire au démarrage) ? Ou un bug non corrigé ? Le comportement actuel est que l'utilisateur découvre que son token est invalide seulement lors de la première opération GitLab, avec une erreur technique peu compréhensible.

---

## A4 — Pas de stratégie de retry réseau

**Fichiers :** `JenkinsJobService.java`, `GitLabService.java`

### Observation

Aucune opération réseau ne réessaie automatiquement en cas d'erreur transitoire. Un timeout réseau de 1 seconde pendant un clone (qui peut durer plusieurs minutes) échoue définitivement et laisse potentiellement le dépôt local dans un état partiel.

### Question

Dans un environnement d'entreprise avec des réseaux VPN et des proxies, les coupures transitoires de quelques secondes sont fréquentes. Combien d'échecs de build ou de clone sont dus à ces instabilités réseau ?

---

## A5 — Fragment OSGi vide : rôle non documenté

**Fichier :** `fragment/META-INF/MANIFEST.MF`

### Observation

Le fragment OSGi déclare `Fragment-Host: fr.lcl.zdevops.idz.plugin;bundle-version="2.0.1"` mais ne contient **aucun code source**, aucune ressource, aucun `Export-Package`, aucun `Require-Bundle`. Il n'a que le `MANIFEST.MF`.

Un fragment OSGi est utile pour :
- Injecter des ressources dans le bundle hôte (NLS, images)
- Fournir des implémentations spécifiques à une plateforme

### Question

À quoi sert ce fragment ? S'il est vide, il ajoute de la complexité au build (module Maven supplémentaire, feature.xml, site.xml) sans apporter de valeur. Est-ce un placeholder pour une future use ? Si oui, est-ce documenté quelque part ?

---

## A6 — `storeGitLabTokenSecurely()` commentée : dépendance implicite à EGit

**Fichier :** `EclipsePluginHelper.java`, lignes 237–252

### Observation

La méthode `storeGitLabTokenSecurely(String token)` est entièrement **commentée**. Seule `storeGitLabTokenForEGit(String token)` est disponible, qui stocke le token dans le nœud Secure Storage d'EGit (`/GIT/https:\2f\2fscm.saas.cagip.group.gca:443`).

### Questions

1. **Couplage implicite avec EGit** : si EGit n'est pas installé dans IDz, le nœud de stockage n'existe pas. Le token GitLab ne peut alors pas être stocké. Ce couplage est-il volontaire ?
2. **Que se passe-t-il si l'URL du serveur GitLab change ?** Le nœud est `https:\2f\2fscm.saas.cagip.group.gca:443` en dur. Si le serveur migre vers une nouvelle URL, tous les utilisateurs doivent re-saisir leur token.
3. **Pourquoi `storeGitLabTokenSecurely` est commentée ?** Est-ce que l'ancienne méthode utilisait un nœud différent ? Y a-t-il une migration de format en cours ?

---

## A7 — `GITLAB_API` statique périmée si token changé en session

**Fichier :** `EclipsePluginHelper.java`, lignes 81–91

### Observation

```java
static {
    GITLAB_BASE_URL = AppProperties.GITLAB_BASE_URL;
    String tokenSecurely = retrieveGitLabTokenSecurely();
    GITLAB_API = new GitLabApi(GITLAB_BASE_URL, tokenSecurely);  // Initialisé une seule fois
}
```

`GITLAB_API` est initialisé au chargement de la classe avec le token du moment. Si l'utilisateur change son token via `Ctrl+E`, cette instance **n'est pas mise à jour**.

Par ailleurs, `GitLabService` crée ses propres instances `GitLabApi` internes. Il peut donc y avoir deux instances simultanées avec des tokens différents.

### Question

Quel est le mécanisme pour s'assurer que le changement de token via `Ctrl+E` est pris en compte immédiatement par toutes les parties du code ? Faut-il redémarrer IDz ? L'utilisateur en est-il informé ?

---

## A8 — Nœud Secure Storage GitLab codé en dur

**Fichier :** `EclipsePluginHelper.java`, ligne 263

```java
String host = "scm.saas.cagip.group.gca";
String port = "443";
String path = "https:\\2f\\2f" + host + ":" + port;
ISecurePreferences gitNode = securePreferences.node("/GIT/" + path);
```

L'URL du serveur GitLab n'est pas lue depuis `AppProperties.GITLAB_BASE_URL`. Elle est codée en dur dans la méthode de stockage/récupération du token.

### Question

Si le serveur GitLab migre (changement de domaine, changement de port), tous les tokens existants deviennent irrécupérables (la clé de stockage ne correspond plus). Les utilisateurs devront re-saisir leur token sans comprendre pourquoi. Ce risque est-il connu ?

---

## A9 — Typo `dependancies` fossilisée dans le schéma JSON

**Fichiers :** Tous les `.mf.json`, `ManifestModel.java`, `GitLabService.java`, `GestionCopysUtils.java`

### Observation

Le champ JSON est nommé `dependancies` (faute d'orthographe) au lieu de `dependencies`. Cette typo est présente :
- Dans le modèle Java (`ManifestModel.java`)
- Dans tous les traitements Groovy de `fabrique_ci`
- Dans tous les fichiers `.mf.json` déjà créés en production

### Question

Est-ce que corriger cette typo est planifié ? Si oui, quel est le plan de migration pour les manifests déjà en production dans GitLab et dans les descripteurs Artifactory ? Une migration automatique a-t-elle été envisagée ?

---

## A10 — Pas de versioning du schéma manifest

### Observation

Le fichier `.mf.json` n'a pas de champ `schema_version` ou `version`. Si le format évolue (ajout d'un champ obligatoire, changement de nom d'un champ), les anciens manifests deviennent incompatibles sans que le pipeline sache quelle version de schéma il manipule.

### Question

Comment les pipelines Jenkins `BuildAndPush` et `auditEtQualite` gèrent-ils des manifests créés avec une ancienne version du plugin ? Y a-t-il de la rétrocompatibilité ? Comment le saura-t-on si un jour le schéma change ?

---

## A11 — Polling Jenkins sans timeout global (critique)

**Fichier :** `JenkinsJobService.java`, méthode `triggerAndMonitorJob()`

### Observation

```java
while (isBuildRunning(buildUrl)) {
    if (monitor.isCanceled()) return Status.CANCEL_STATUS;
    Thread.sleep(2000);
    monitor.worked(1);  // IProgressMonitor.UNKNOWN → pas de barre de progression réelle
}
```

Cette boucle n'a **pas de limite d'itérations**. Un pipeline Jenkins suspendu en attente d'une saisie utilisateur (`input()` step dans Groovy), ou bloqué par un deadlock, fera tourner le Job Eclipse **indéfiniment**.

La seule façon de sortir est que l'utilisateur annule manuellement (`monitor.isCanceled()`), mais encore faut-il qu'il s'en rende compte et pense à le faire.

### Question

Quelle est la durée maximale acceptable d'un pipeline `BuildAndPush` ? Un timeout de, disons, 60 minutes ne devrait-il pas être une limite de sécurité ?

---

## A12 — Blue Ocean est officiellement déprécié : dépendance à un plugin en fin de vie

### Chronologie officielle de la dépréciation

| Date | Événement |
|---|---|
| Déc. 2022 | Blog Jenkins : ["The Future of Blue Ocean"](https://www.jenkins.io/blog/2022/12/22/blueocean-future/) — entrée en **"sustainment mode"** (maintenance limitée, zéro nouvelle fonctionnalité) |
| 2023 | Plus aucun développement actif ; seules les corrections de sécurité critiques sont traitées |
| 2024 | Le plugin reste installable mais la communauté le déconseille formellement pour les nouvelles installations |
| 2025–2026 | Discussions en cours dans la communauté Jenkins pour un retrait officiel du plugin de l'Update Center ; aucune date ferme annoncée mais la trajectoire est irréversible |

Blue Ocean n'est pas simplement "en fin de vie douce" : son mainteneur principal (CloudBees) a explicitement cessé d'investir dessus au profit de la nouvelle interface Jenkins UI redesignée.

### Observation

Le plugin construit l'URL Blue Ocean pour afficher les logs Jenkins :

```
<base>/blue/organizations/jenkins/<job>/detail/<job>/<num>/pipeline/
```

Si Blue Ocean est désinstallé ou désactivé lors d'une mise à jour de l'infrastructure FabCI, **cette URL retourne une 404 et le plugin IDz ne peut plus afficher les logs de build**.

Il n'existe aucun mécanisme de fallback dans le code : si la réponse HTTP n'est pas 200, le plugin échoue silencieusement ou affiche une erreur technique sans proposer l'URL classique (`/job/<job>/<num>/console`).

### Risque concret

La dépendance à Blue Ocean est une dépendance implicite non déclarée : elle n'apparaît ni dans le `pom.xml`, ni dans le `MANIFEST.MF`, ni dans les prérequis documentés du plugin. L'équipe FabCI peut désinstaller Blue Ocean sans savoir que cela casse le plugin IDz.

### Question

Quelle est la version Jenkins de FabCI ? Blue Ocean est-il encore installé ? Si une mise à jour Jenkins est planifiée en 2025–2026, quel est le plan de migration de l'affichage des logs ?

### Recommandation

Implémenter un fallback en deux étapes dans `JenkinsJobService` :
1. Tenter l'URL Blue Ocean — si réponse ≠ 200, basculer vers l'URL classique `/job/<job>/<num>/console`
2. À terme, migrer vers l'URL classique en standard (Blue Ocean n'apporte rien sur l'affichage des logs texte)

---

## A13 — `HttpClient` Java 11 sans timeout configuré

**Fichier :** `JenkinsJobService.java`, ligne 43

```java
private final HttpClient httpClient = HttpClient.newHttpClient();
```

`HttpClient.newHttpClient()` crée un client avec des timeouts infinis par défaut.

### Conséquence

Si le serveur Jenkins ne répond pas (surcharge, réseau coupé), le thread peut rester bloqué indéfiniment sur un `httpClient.send(...)` — sans que `monitor.isCanceled()` soit vérifié, puisque le thread est bloqué en attente.

### Recommandation

```java
private final HttpClient httpClient = HttpClient.newBuilder()
    .connectTimeout(Duration.ofSeconds(30))
    .build();
// Et pour chaque requête : .timeout(Duration.ofSeconds(30)) sur HttpRequest.Builder
```

---

## A14 — Jenkins : un outil en déclin structurel de marché

### Contexte

Jenkins est le moteur central de la fabrique CI (FabCI). Ce n'est pas un risque technique dans le code — c'est un risque de positionnement stratégique à horizon 3–5 ans.

### État du marché en 2025–2026

| Indicateur | Valeur |
|---|---|
| Part des organisations ayant migré ou migrant depuis Jenkins (ex-utilisateurs primaires 2022) | ~67 % |
| Évolution de la part de marché Jenkins | −8 % / an |
| Part de projets GitHub utilisant GitHub Actions | 68 % |
| Croissance de GitLab CI en entreprise | +34 % / an (2025) |
| CVE découverts dans les plugins Jenkins en 2025 | 127 |
| Plugins Jenkins non mis à jour depuis > 2 ans | ~30 % |

Sources : State of DevOps Report 2024, JetBrains Developer Ecosystem Survey 2024, Eficode "War of the CI servers" 2025.

### Raisons du déclin

1. **Modèle d'exploitation lourd** : Jenkins nécessite une infrastructure dédiée, une équipe ops, et une mise à jour régulière. GitHub Actions et GitLab CI sont entièrement gérés (SaaS).
2. **Plugins fragiles** : les mises à jour Jenkins cassent fréquemment des pipelines existants par incompatibilité inter-plugins. 30 % des plugins ne sont plus maintenus.
3. **Surface d'attaque importante** : 127 CVE en 2025 sur les plugins — un vecteur d'attaque de la supply chain pour toute organisation qui ne gère pas ses mises à jour rigoureusement.
4. **UX vieillissante** : l'interface Jenkinsfile (Groovy DSL) est perçue comme complexe face aux YAML déclaratifs de GitHub Actions / GitLab CI.
5. **CloudBees en retrait** : le principal sponsor commercial de Jenkins réduit son investissement open-source (abandon de Blue Ocean, focus sur sa plateforme propriétaire CloudBees CI).

### Cas particulier du mainframe

Jenkins reste pertinent dans les contextes on-premise isolés (pas d'accès Internet, contraintes réglementaires bancaires), ce qui est exactement le cas de FabCI. **C'est le seul scénario où Jenkins conserve une légitimité forte en 2026.**

Cependant, cela ne protège pas des risques suivants :
- La communauté Jenkins réduisant la qualité et la fréquence des releases
- Les plugins critiques (Artifactory, SonarQube, GitLab) cessant leur support Jenkins en priorité sur GitHub Actions / GitLab CI
- La difficulté croissante à recruter des profils Jenkins (compétences en déclin sur le marché)

### Questions

1. **Horizon de vie de FabCI** : quelle est la durée de vie prévue de l'architecture actuelle ? Si c'est > 5 ans, le risque Jenkins mérite une évaluation formelle.
2. **Alternatives étudiées** : a-t-on étudié GitLab CI natif (qui est déjà présent dans le SI via le GitLab de scm.saas.cagip.group.gca) comme alternative à terme ?
3. **Compatibilité DBB/zAppBuild** : le build USS (via `groovyz`) est-il couplé à Jenkins, ou pourrait-il être déclenché par un autre orchestrateur CI ?
4. **Dépendance au plugin IDz** : si Jenkins est un jour remplacé, le plugin IDz devrait être totalement reécrit (la couche `JenkinsJobService` est couplée à l'API Jenkins). C'est un coût de migration à anticiper.

### Recommandation

Ne pas agir immédiatement, mais **documenter cette dépendance comme risque stratégique T2** dans la feuille de route architecture. Si une revue d'architecture est prévue à 3 ans, le choix du moteur CI devrait en faire partie.
