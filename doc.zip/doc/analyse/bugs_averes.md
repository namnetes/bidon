# Bugs avérés — Plugin zDevOps IDz

**Version analysée :** 2.0.1-SNAPSHOT  
**Date :** 2026-05-08  
**Périmètre :** `plugin/src/fr/lcl/zdevops/idz/plugin/`

Ce document recense les bugs confirmés avec preuves dans le code source, leurs conséquences et les corrections proposées.

---

## M1 — Race condition sur `applications.json` (critique)

**Fichier :** `GitLabService.java` — `writeBranchManifest()` (l.565), `updateApplication()` (l.811), `pushUpdatedApplications()` (l.790)

### Description

Le numéro d'artefact (`next_artifact_number` dans `applications.json`) est incrémenté via un cycle Read → Modify → Write **non atomique et non transactionnel** :

```java
// updateApplication() — aucun verrou, aucune transaction GitLab
List<Application> applications = fetchApplications();     // 1. Lit depuis GitLab
application.setNextArtifactNumber(current + 1);           // 2. Incrémente en mémoire locale
pushUpdatedApplications(applications);                     // 3. Ré-écrit sur GitLab (écrase)
```

Si deux développeurs créent une évolution sur la **même application** simultanément (délai < quelques secondes), les deux liront `next_artifact_number = 42`, incrémenteront à `43`, et l'un écrasera silencieusement le commit de l'autre.

### Conséquences

- Deux branches `feature_` avec un `manifest_name` identique dans leur `.mf.json`
- Jenkins `BuildAndPush` reçoit deux fois `NomManifest=da01_000043` — les deux builds se piétinent dans Artifactory
- Corruption silencieuse de `applications.json` (un incrément perdu)

### Comment le reproduire

```python
# Simulation : deux lectures simultanées du même compteur
import threading, time

def lire_puis_incrementer():
    n = fetch_applications()["da01"]["next_artifact_number"]  # Lit 42
    time.sleep(0.5)   # Simule le temps de traitement entre lecture et écriture
    push_applications(n + 1)  # Écrit 43 — l'un des deux appels écrase l'autre

t1 = threading.Thread(target=lire_puis_incrementer)
t2 = threading.Thread(target=lire_puis_incrementer)
t1.start(); t2.start()
t1.join(); t2.join()
# Résultat : applications.json contient 43, alors qu'il devrait contenir 44
# Deux évolutions ont le même manifest_number
```

### Correction proposée

Utiliser l'API GitLab avec **commit conditionnel** (`last_commit_id`) pour un optimistic locking :

```java
// Récupérer le sha du commit courant du fichier
String lastCommitId = getFileLastCommitId(PARAMS_PROJECT_ID, "applications.json");

try {
    // L'API GitLab rejette la mise à jour si le fichier a changé entre-temps
    updateFileWithLastCommitId("applications.json", newContent, lastCommitId);
} catch (GitLabApiException e) {
    if (e.getHttpStatus() == 400) {
        // Conflit détecté : relancer depuis le début (retry)
        updateApplication(app);  // Rappel récursif avec backoff
    }
}
```

---

## M2 — `changeListener` jamais assigné au champ d'instance (critique)

**Fichier :** `Activator.java`, lignes 45 et 53

### Description

```java
// start() — BUG : variable LOCALE qui cache le champ d'instance
ManifestFileChangeListener changeListener = new ManifestFileChangeListener(); // LOCALE
ResourcesPlugin.getWorkspace().addResourceChangeListener(changeListener, IResourceChangeEvent.POST_CHANGE);

// stop() — this.changeListener est NULL → removeResourceChangeListener(null) ne fait rien
ResourcesPlugin.getWorkspace().removeResourceChangeListener(changeListener); // null !
```

La variable `changeListener` déclarée dans `start()` est locale, pas `this.changeListener`.

### Conséquences

- Le listener n'est **jamais retiré** à l'arrêt du plugin
- Fuite mémoire : l'objet `ManifestFileChangeListener` reste référencé par le workspace Eclipse
- Si le plugin est redémarré dans la même session IDz, un deuxième listener est ajouté — les deux écoutent en parallèle (comportements dupliqués)

### Correction

```java
// Dans start() — ligne 45, retirer la déclaration de type :
// AVANT (bug) :
ManifestFileChangeListener changeListener = new ManifestFileChangeListener();
// APRÈS (correct) :
changeListener = new ManifestFileChangeListener(); // this.changeListener est le champ d'instance
```

---

## M3 — `writeBranchManifest` non atomique (critique)

**Fichier :** `GitLabService.java`, lignes 565–628

### Description

La méthode enchaîne 5 opérations sans mécanisme de rollback :

```
Étape 1 : Créer META-INF/<nom>.mf.json sur le disque local
Étape 2 : git add + git commit (manifest)
Étape 3 : Modifier zapp.yaml via updateHlq()
Étape 4 : git add + git commit (zapp.yaml)
Étape 5 : updateApplication() → pushUpdatedApplications() → API GitLab (applications.json)
```

Une coupure réseau entre les étapes 2 et 5 laisse :
- Le manifest commité localement avec le numéro N
- `applications.json` sur GitLab avec toujours le numéro N-1
- La prochaine évolution créera un doublon de numéro

### Scénario de reproduction

1. Démarrer une évolution `da01`
2. Débrancher le câble réseau entre l'étape 2 (commit local) et l'étape 5 (push GitLab)
3. Reconnecter le réseau
4. Démarrer une deuxième évolution `da01`
5. Les deux `.mf.json` ont le même `manifest_number`

### Correction envisageable

Approche "saga compensatoire" : si l'étape 5 échoue, supprimer les commits locaux des étapes 2 et 4 via `git reset --hard HEAD~2`, puis relancer avec un nouveau numéro.

---

## M4 — `commitChanges` avale silencieusement les erreurs Git (critique)

**Fichier :** `GitLabService.java`, lignes 380–386

### Description

```java
@Override
public void commitChanges(Project project, String message) throws IOException, GitAPIException {
    try {
        commitChanges(project, ".", message);
    } catch (GitAPIException | IOException | GitLabApiException e) {
        e.printStackTrace();   // stderr seulement — personne ne lit ça en production
        // Pas de rethrow → l'appelant croit que le commit a réussi
    }
}
```

Cette surcharge est appelée par `switcherBranche`, `updateNewEvolution`, `manageBranchByBranch` — toutes des opérations critiques sur les branches.

### Conséquences

- Un échec de commit (ex: index verrouillé, espace disque plein, permission refusée) passe inaperçu
- Les opérations suivantes (push, création branche) s'exécutent sur un dépôt en état `dirty`
- L'utilisateur voit "opération réussie" alors que des modifications n'ont pas été commitées

### Comment déclencher le bug

```bash
# 1. Verrouiller l'index Git du dépôt
touch <workspace>/da01/.git/index.lock

# 2. Lancer "Participer à une évolution" (Ctrl+2) sur da01
# → commitChanges est appelé, JGit lève LockFailedException
# → Exception capturée et imprimée sur stderr
# → L'opération "continue" normalement depuis la perspective du plugin
# → L'utilisateur voit "Connexion à l'évolution réussie"
# → Mais ses modifications ne sont pas commitées
```

### Correction

```java
// Rethrow systématique — laisser propager l'exception à l'appelant
public void commitChanges(Project project, String message) throws IOException, GitAPIException {
    commitChanges(project, ".", message);  // Pas de try/catch ici
}
```

---

## M5 — `switcherBranche` commite automatiquement sans consentement (critique)

**Fichier :** `GitLabService.java`, lignes 440–451

### Description

```java
public void switcherBranche(Project projet, String branchName) {
    if (!git.status().call().isClean()) {
        // Commit silencieux de TOUT le contenu non commité
        commitChanges(projet,
            String.format("🎯 Validation des changements sur la branche %s avant bascule...",
                currentBranch, branchName));
    }
    // ...puis checkout sur branchName
}
```

### Conséquences pour un SI bancaire

1. Des fichiers de debug (`System.out.println`, breakpoints JCL, valeurs de test hardcodées) peuvent être commités et poussés vers GitLab — potentiellement en production
2. Des modifications partielles ou cassées peuvent être commitées
3. L'historique Git est pollué de commits automatiques sans intention du développeur
4. Si le push de ces commits automatiques déclenche ensuite un build Jenkins automatique, du code non testé peut partir en production

### Comment déclencher le bug

```bash
# 1. Créer une évolution sur da01, branche feature_evol_a
# 2. Créer volontairement des fichiers de test
echo "BREAKPOINT_DEBUG" > <workspace>/da01/src/TESTFILE.cbl
echo "TODO: SUPPRIMER" >> <workspace>/da01/src/MONPROG.cbl

# 3. Lancer "Consulter les sources" (Ctrl+9) sur da01
# → switcherBranche() est appelé pour passer sur master
# → git.status().call().isClean() retourne false
# → commitChanges est appelé automatiquement
# → TESTFILE.cbl et la ligne "TODO: SUPPRIMER" sont maintenant dans Git
```

### Correction

Remplacer le commit automatique par une **confirmation explicite** de l'utilisateur :

```java
if (!git.status().call().isClean()) {
    boolean confirmed = EclipsePluginHelper.showMessageBox(shell, "question",
        "Modifications en cours",
        "Des modifications non commitées existent sur la branche " + currentBranch +
        ".\nVoulez-vous les commiter avant de changer de branche ?\n" +
        "(Refuser annulera l'opération)");
    if (!confirmed) {
        throw new PipelineException("Opération annulée : modifications non commitées présentes");
    }
    commitChanges(projet, "Sauvegarde avant bascule de branche");
}
```

---

## Erreurs mineures

### m1 — `TextProgressMonitor` double-initialisé

**Fichier :** `GitLabService.java`, lignes 141 et 144

```java
monitor = new TextProgressMonitor(new PrintWriter(System.out)); // ligne 141 — créé
projects = new ArrayList<Project>();
branchsByProject = new ArrayList<Branch>();
monitor = new TextProgressMonitor(new PrintWriter(System.out)); // ligne 144 — recrée, l'objet précédent est perdu
```

Impact : fuite d'un `PrintWriter` non fermé. Correction : supprimer la ligne 141.

---

### m2 — `updateHlq` retourne silencieusement en cas d'erreur

**Fichier :** `GitLabService.java`, lignes 637–694

Toutes les erreurs (fichier absent, paramètres nuls, non lisible) font un `System.out.println + return`. L'appelant commite ensuite un `zapp.yaml` inchangé avec un message indiquant qu'il a été modifié. Voir aussi [P3 dans risques_processus](risques_processus.md).

---

### m3 — Remplacement HLQ fragile par chaîne littérale

**Fichier :** `GitLabService.java`, ligne 687

```java
String updatedContent = content.replace("F000000", "F" + newValue);
```

- Fonctionne uniquement si le `zapp.yaml` contient exactement `F000000`
- Dès la première évolution créée avec succès, le fichier contient `F000001` (ou la valeur suivante), et toutes les évolutions ultérieures ne mettront plus jamais à jour ce champ
- Aucune erreur levée — le fichier est réécrit identique à lui-même et commité

---

### m4 — `startNewEvolution` : méthodes vides dans l'interface publique

**Fichier :** `GitLabService.java`, lignes 866–873

```java
@Override
public void startNewEvolution(Project project, String evolution) throws Exception {
    // TODO — corps vide
}
```

Ces méthodes font partie de `IGitLabService`. Le code réel passe par `GitServiceLauncher` directement, contournant l'interface. Ces TODO sont du dead code trompeur.

---

### m5 — Quatre mécanismes de logging coexistants

| Mécanisme | Où utilisé |
|---|---|
| `LOGGER.info/warn/error` (SLF4J) | Certaines méthodes de `GitLabService`, `JenkinsJobService` |
| `System.out.println` | `updateHlq`, `AppProperties`, `EclipsePluginHelper` |
| `System.err.println` | `cloneProject`, `GestionCopysUtils` |
| `e.printStackTrace()` | Exceptions capturées partout |

En production, seul SLF4J peut être configuré et filtré. Les `System.out/err` et `printStackTrace` ne peuvent pas être désactivés, centralisés ou monitorés.
