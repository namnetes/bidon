# Risques processus — CI/CD zDevOps Mainframe

Ce document analyse les risques dans la **chaîne CI/CD elle-même** : les processus qui peuvent laisser le système dans un état indéterminé, les manques de contrôles, et les zones où la robustesse pour un SI bancaire critique n'est pas satisfaisante.

---

## P1 — Pas de timeout sur les callbacks ProxyCI (critique)

**Fichier :** `fabrique_ci/proxyci.jenkinsfile`

### Description

Le pipeline `ProxyCD` déclenche une demande de déploiement vers le service CD CAGIP, puis attend un callback via `proxyci.jenkinsfile`. Il n'existe aucun mécanisme de timeout : si le callback n'arrive jamais (panne du service CD, réseau, crash), le déploiement reste **indéfiniment en état inconnu**.

### Conséquences

1. Le descripteur de l'évolution n'est jamais mis à jour (ni SUCCESS ni FAILURE)
2. Aucune notification d'expiration n'est envoyée (sauf si `doWhenExpired` est déclenché par un autre mécanisme — lequel ?)
3. L'artefact reste en état `scratch` dans Artifactory
4. Le développeur ne sait pas si son déploiement est en attente, en cours, ou perdu

### Questions ouvertes

- **Qui déclenche `doWhenExpired` ?** Le service CD CAGIP ? Un timer Jenkins ? Après combien de temps ?
- **Quel est le SLA du service CD CAGIP ?** En cas de non-réponse sous X minutes, le déploiement doit-il être automatiquement annulé ?
- **Y a-t-il une supervision de l'état des callbacks en attente ?**

---

## P2 — `updateHlq` : le `zapp.yaml` est effectivement cassé dès la 2ème évolution (critique)

**Fichier :** `GitLabService.java`, ligne 687  
**En lien avec :** m3 dans [bugs_averes.md](bugs_averes.md)

### Description

```java
String updatedContent = content.replace("F000000", "F" + newValue);
```

La première fois qu'une évolution est créée sur une application, `zapp.yaml` contient `F000000` → il est mis à jour vers `F000001` (ou le numéro d'artefact). **Dès la deuxième évolution**, le fichier ne contient plus `F000000` mais `F000001` (ou la valeur précédente), donc `content.replace("F000000", ...)` ne remplace **rien**. Le fichier est réécrit identique, commité, et personne ne le sait.

### Question critique

Quelle est la valeur réelle de `zapp.yaml` dans les dépôts en production aujourd'hui ? Contient-il le bon numéro de build ? Ou est-il figé à la valeur du premier build depuis l'introduction de cette fonctionnalité ?

**Vérification immédiate recommandée :**
```bash
# Dans un dépôt da01 en production
cat <workspace>/da01/META-INF/zapp.yaml | grep "F0"
# Si la valeur n'est pas F000000, alors updateHlq ne fonctionne plus
# depuis combien de temps ?
```

### Impact

Si `zapp.yaml` pilote le comportement de compilation côté DBB (ex: pour la gestion du HLQ de l'espace de travail USS), des builds incorrects ont peut-être eu lieu silencieusement.

---

## P3 — Aucune vérification préalable avant Audit ou Promote

**Fonctions concernées :** Audit (Ctrl+6), Promote Unitaire (clic droit)

### Audit sans build préalable

Le pipeline `auditEtQualite` nécessite que le descripteur `.desc.json` existe dans Artifactory. Si le développeur déclenche un Audit sans avoir buildé, Jenkins échoue avec un message explicite (`"LE FICHIER DESC.JSON EST INTROUVABLE"`), mais le plugin ne le vérifie pas à l'avance.

**Conséquence :** le développeur déclenche un pipeline Jenkins qui tourne quelques minutes avant d'échouer avec un message d'erreur. Cela consomme des ressources Jenkins inutilement et donne une mauvaise expérience.

### Promote Unitaire sans build préalable

Si le développeur déclenche un Promote Unitaire sans avoir compilé préalablement, Jenkins génère un JCL, le soumet, et le JCL tombe en `JCLERR` car le PDS source est vide. Le code retour est traité comme un FAILURE, mais avec un message générique.

**Recommandation :** le plugin devrait vérifier l'existence du descripteur dans Artifactory avant de déclencher un Audit ou un Promote Unitaire. L'API Artifactory permet une requête HEAD pour vérifier l'existence sans télécharger le fichier.

---

## P4 — `CleanUnitaire` détruit le workspace même en cas d'erreur grave

**Fichier :** `fabrique_ci/cleanUnitaire.jenkinsfile`, stage "Exécution JCL"

### Description

```groovy
dir(WORKSPACE){
    // ...soumission JCL...
    jsonSortieObject.code_retour = result[1]
    deleteDir()  // ← Toujours exécuté, même si code_retour > 8
}
```

`deleteDir()` est appelé dans le même bloc que la soumission JCL, sans condition sur le code retour. Si le JCL échoue avec un code retour critique (> 8), le workspace USS est tout de même supprimé, emportant les logs intermédiaires nécessaires au diagnostic.

### Conséquence

En cas d'erreur grave lors d'un Clean Unitaire, les logs de diagnostic (listings JCL, spool) sont détruits avant que l'équipe support puisse les consulter.

### Correction

```groovy
dir(WORKSPACE) {
    // ...soumission JCL...
    def int_retour = jsonSortieObject.code_retour.toInteger()
    if (int_retour <= 8) {
        deleteDir()  // Nettoyage seulement si OK ou avertissement
    }
    // En cas d'erreur grave, laisser le workspace pour investigation
}
```

---

## P5 — Cascade DEVD : règle implicite sur état intermédiaire du descripteur

**Fichier :** `fabrique_ci/proxyci.jenkinsfile`, lignes 96–113

### Description

```groovy
if (actionSelected == "doAfterMep" && PROXY_CI_SITE == 'DEVD') {
    descriptorsJSON.deployments.installs.each { site, key ->
        if ((key.State.toString() == "install_completed") || 
            (key.State.toString() == "install_failed")) {
            actionSelected = 'doAfterCascade'
        }
    }
}
```

La requalification `doAfterMep` → `doAfterCascade` sur DEVD est déclenchée si **au moins un site** dans le descripteur est en `install_completed` ou `install_failed`. Cela suppose que le descripteur reflète toujours fidèlement l'état réel des déploiements.

### Question

Que se passe-t-il si le descripteur est dans un état **incohérent** (ex: l'étape 5 de M3 a échoué avant de mettre à jour le descripteur) ? La règle de cascade pourrait se déclencher sur de mauvaises prémisses, ou ne pas se déclencher alors qu'elle le devrait.

---

## P6 — L'audit analyse un build potentiellement obsolète

**Fichier :** `fabrique_ci/audit.jenkinsfile`

### Description

Le pipeline `auditEtQualite` lit le **descripteur Artifactory** pour obtenir le tag Git à analyser. Si le développeur a modifié ses sources depuis le dernier build, l'audit porte sur une version différente du code source que celle actuellement dans le dépôt Git.

### Scénario

1. Développeur builde l'évolution `da01_evol_001` → artefact en scratch, tag `da01_evol_001_42`
2. Développeur modifie un programme COBOL (nouvelle logique métier)
3. Développeur déclenche l'Audit **sans rebuilder**
4. L'audit analyse la version du code du build 42 (step 1), pas la version actuelle (step 2)
5. L'audit passe avec SUCCESS
6. Le développeur déploie → la version en production correspond au build 42 (sans les modifications de l'étape 2)

**Ce bug ne peut pas se produire en pratique si le développeur suit bien le flux** (build → audit → deploy). Mais il n'est pas techniquement empêché, et pour un SI critique, les garde-fous techniques devraient compenser les erreurs humaines.

---

## P7 — `applications.json` : un référentiel de compteur dans Git

**Fichier :** `GitLabService.java` — `writeBranchManifest()`

### Description

Le fichier `applications.json` remplit deux rôles incompatibles :
1. **Référentiel de configuration** : liste des applications autorisées (stable)
2. **Séquenceur de numéros** : compteur `next_artifact_number` incrémenté à chaque évolution (volatile)

Git n'est pas adapté aux données mutables à haute fréquence. Chaque création d'évolution génère un commit sur `applications.json` en production, ce qui :
- Polue l'historique Git du repo `app.params`
- Crée des conflits de merge si deux développeurs travaillent simultanément (voir M1)
- Empêche une gestion de version saine de la configuration applicative

### Recommandation

Externaliser la séquence de numéros dans un service dédié :
- Une table PostgreSQL ou MySQL avec `SELECT nextval()` (atomique par nature)
- Un service HTTP léger sur l'infrastructure CAGIP
- Au minimum : utiliser les GitLab API Locks ou un fichier "sentinel" pour garantir l'atomicité

---

## P8 — Pas de vérification que master est en avance sur feature avant le build

### Description

Le pipeline `BuildAndPush` compile les sources de la branche `feature_XXX` telle qu'elle existe au moment du build. Si `master` a été mis à jour (par intégration d'une autre évolution) depuis que le développeur a créé sa branche, la compilation porte sur un code qui ne tient pas compte des dernières intégrations.

### Risque

Des conflits qui existeraient si la branche était mergée sur master ne sont pas détectés jusqu'au merge. Dans un projet mainframe où les programmes COBOL peuvent partager des copybooks, une modification d'un copybook dans une évolution intégrée peut casser la compilation d'une autre évolution.

### Question

L'audit (`auditEtQualite`) vérifie-t-il que la branche est "en avance sur master" ou seulement la conformité au sens de l'état des commits ? La fonction `audit()` dans `fabrique_ci/vars/audit.groovy` mérite une analyse détaillée à ce sujet.

---

## P9 — Manque de traçabilité des actions manuelles dans le workflow

### Description

Le workflow de déploiement inclut des étapes d'approbation (`doAfterMepApproved`) et de rejet (`doAfterMepRejected`). Ces actions sont déclenchées par le service CD CAGIP avec un `user_id`.

### Question

- Où est stockée la trace de "qui a approuvé quoi et quand" ?
- Les logs Kafka/ELISA capturent-ils cette information ?
- Est-ce que cette traçabilité est suffisante pour répondre aux exigences d'audit bancaire (ACPR, auditeurs internes) ?
- En cas d'incident de production lié à un déploiement, peut-on retracer précisément la chaîne décisionnelle ?

---

## P10 — Aucune vérification de synchronisation locale/distante avant les opérations manifest et build (majeur)

**Fonctions concernées :** Gérer les composants du manifest (Ctrl+5), Gérer les dépendances (Ctrl+7), MAJ copybooks (Ctrl+4), Builder (Ctrl+0), Audit (Ctrl+6), Déployer (Ctrl+B), Promote Unitaire, Clean Unitaire

### Description

Les fonctions d'évolution (Ctrl+1, Ctrl+2, Ctrl+8) gèrent explicitement la synchronisation avec GitLab : elles proposent soit un reclonage complet, soit un `git pull` avant toute opération. En revanche, **toutes les fonctions qui s'exécutent après l'ouverture d'un projet dans IDz opèrent sur l'état local du dépôt sans jamais vérifier qu'il est à jour par rapport au distant**.

Un développeur qui reprend une évolution en cours après une interruption (lendemain, passage sur un autre poste, retour de congé) n'est pas alerté si des commits ont été poussés sur la même branche `feature_XXX` par un collègue entre-temps.

### Scénario concret

```
1. Développeur A crée feature_evol_001 sur da01
2. Développeur A modifie MONPROG.cbl et ferme IDz en fin de journée
3. Développeur B (Ctrl+2) participe à feature_evol_001 et pousse 3 commits de correction
4. Le lendemain, Développeur A rouvre IDz :
   - Son dépôt local est en retard de 3 commits sur GitLab
   - Il déclenche Ctrl+5 (Gérer composants) → le manifest est réécrit depuis son état local obsolète
   - Il déclenche Ctrl+0 (Builder) → Jenkins compile DA01 avec des sources périmées
   - En cas de conflit, les corrections de B sont silencieusement écrasées au prochain push
```

### Conséquences

1. **Conflit de travail non détecté** : les modifications d'un collègue peuvent être écrasées lors d'un prochain push sans que le développeur en soit averti
2. **Build sur code obsolète** : Jenkins compile une version du code qui ne reflète pas l'état réel de l'évolution en cours (risque similaire à P6, mais sur la branche feature elle-même)
3. **Manifest incohérent** : si un collègue a modifié le manifest (ajout/suppression de composants) et poussé ses changements, la réécriture locale du manifest via Ctrl+5 écrase ces modifications
4. **Effet silencieux** : aucune erreur n'est levée, aucun avertissement n'est affiché — la situation est invisible pour le développeur

### Distinction avec P8

P8 porte sur l'absence de vérification que `master` est en avance sur la branche `feature` (détection de conflits d'intégration). P10 porte sur l'absence de vérification que la branche `feature` locale est à jour par rapport à la **même branche `feature`** sur GitLab (perte de travail collaboratif).

### Recommandation

Avant tout déclenchement d'une opération sur un projet ouvert (fonctions Ctrl+4, Ctrl+5, Ctrl+7, Ctrl+0, Ctrl+B, Ctrl+6, Promote, Clean), le plugin devrait :

1. Effectuer un `git fetch` silencieux
2. Comparer `HEAD` local au `origin/feature_XXX` distant
3. Si le distant est en avance, afficher un avertissement :

```
⚠️ Votre dépôt local est en retard de N commit(s) sur GitLab.
   Dernière synchronisation : <date>.
   Voulez-vous mettre à jour avant de continuer ? [Mettre à jour] [Continuer sans mettre à jour] [Annuler]
```

Le `git fetch` doit être non-bloquant et effectué en arrière-plan, en précachant le résultat pour éviter un appel réseau sur chaque frappe.

---

## Tableau de priorisation des risques processus

| ID | Sévérité | Effort correction | Priorité recommandée |
|---|---|---|---|
| P1 — Pas de timeout callback ProxyCI | 🔴 Critique | Moyen | ⚡ Immédiat |
| P2 — `zapp.yaml` cassé (updateHlq) | 🔴 Critique | Faible | ⚡ Immédiat — vérifier l'état actuel en prod |
| P7 — applications.json comme compteur | 🔴 Critique | Élevé | 🗓 Planifier refactoring |
| P3 — Pas de vérif préalable (audit/promote) | 🟠 Majeur | Faible | 🔧 Court terme |
| P4 — deleteDir en cas d'erreur grave | 🟠 Majeur | Faible | 🔧 Court terme |
| P10 — Aucune vérif synchro locale/distante | 🟠 Majeur | Faible | 🔧 Court terme |
| P5 — Cascade DEVD fragile | 🟠 Majeur | Moyen | 🗓 Planifier |
| P6 — Audit sur build obsolète | 🟡 Mineur | Moyen | 🗓 Planifier |
| P8 — Pas de vérif avance sur master | 🟡 Mineur | Élevé | 📋 Backlog |
| P9 — Traçabilité approbations | 🟡 Mineur | Moyen | 📋 Backlog |
