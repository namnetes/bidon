# Fonction 6 — Gérer les composants du manifest

**Raccourci clavier :** `Ctrl+5`
**Menu :** zDevOps > Gérer les composants du manifest

---

## Contexte et objectif

Le **manifest** est le fichier `<code>_<evolution>.mf.json` situé dans `META-INF/` du projet. Il décrit l'évolution : quels fichiers sources doivent être buildés, quel est le type d'application, etc.

Cette fonction permet de **sélectionner ou désélectionner les fichiers sources** (programmes COBOL, copybooks, etc.) qui doivent être inclus dans le manifest de l'évolution courante. C'est l'étape indispensable avant un build : si un fichier n'est pas dans le manifest, il ne sera pas compilé lors du build Jenkins.

### Quand l'utiliser ?
- Après avoir créé une évolution, pour déclarer les fichiers modifiés.
- Quand on ajoute un nouveau programme à une application.
- Quand on retire un programme de l'évolution (on le décoche).
- À tout moment pour ajuster la liste des composants à builder.

---

## Concepts clés

### Types de composants selon le type d'application

Le type d'application (BATCH ou TP) détermine quels répertoires sont visibles dans l'arbre de sélection :

**BATCH** — répertoires affichés :
| Répertoire | Contenu |
|---|---|
| `asm` | Fichiers assembleur |
| `par` | Paramètres |
| `skl` | Squelettes JCL |
| `src` | Sources COBOL principaux |
| `srx` | Sources COBOL étendus |
| `cli` | Clients CICS |
| `srp` | Sous-routines |
| `cpy` | Copybooks internes |
| `dcl` | Déclarations |
| `in2` | Includes de niveau 2 |

**TP (Transactionnel CICS)** — répertoires affichés :
| Répertoire | Contenu |
|---|---|
| `ast` | Assets CICS |
| `mps` | Maps CICS |
| `msk` | Masques d'écran |
| `poe` | Procédures opérationnelles |
| `spn` | Sources de spanning |
| `srt` | Sorties |
| `cpy` | Copybooks internes |
| `dcl` | Déclarations |
| `in2` | Includes de niveau 2 |

Seuls les répertoires **réellement présents** dans le projet local sont affichés.

### Arbre hiérarchique
L'interface affiche un arbre à deux niveaux :
- **Nœud parent** = nom du répertoire (ex : `src`)
- **Nœud enfant** = nom d'un fichier présent dans ce répertoire

Les fichiers commençant par `.` ou finissant par `.md` sont exclus.

---

## Prérequis

- Un projet doit être sélectionné dans l'explorateur IDz (ou un fichier du projet doit être ouvert).
- Le projet doit contenir un fichier manifest unique dans `META-INF/`.
- L'évolution doit avoir été démarrée (la branche `feature_` doit exister).

---

## Règles métier détaillées

### RG-01 : Lecture du manifest au démarrage
À l'ouverture de la boîte de dialogue, le plugin :
1. Identifie le projet actif.
2. Lit le fichier `.mf.json` dans `META-INF/`.
3. Affiche en **lecture seule** les métadonnées de l'évolution : code application, objet du projet, nom de l'évolution, type de composant, type d'application, description.

Ces champs sont purement informatifs et ne peuvent pas être modifiés ici.

### RG-02 : Pré-sélection des fichiers déjà dans le manifest
Les fichiers déjà déclarés dans le manifest (`content`) sont **pré-cochés** dans l'arbre à l'ouverture. L'utilisateur voit immédiatement l'état actuel de sa sélection.

### RG-03 : Sélection et désélection
L'utilisateur **coche** les fichiers à inclure dans le build et **décoche** ceux à exclure. Chaque action met à jour en temps réel une zone de résumé en bas de la boîte de dialogue qui affiche, par répertoire, la liste des fichiers sélectionnés.

### RG-04 : Filtre de recherche
Un champ de filtre texte permet de chercher un fichier par son nom (recherche insensible à la casse, correspondance partielle). Quand on filtre, les fichiers déjà cochés **restent cochés** même s'ils ne correspondent pas au filtre : la sélection n'est pas perdue lors du filtrage.

Le bouton "Reset" à côté du filtre vide le champ de recherche et rétablit l'affichage complet.

### RG-05 : Sauvegarde dans le manifest
Quand l'utilisateur clique sur **"Valider"** :
1. Le fichier manifest est **réécrit sur le disque** avec la nouvelle liste de fichiers sélectionnés, organisée par répertoire dans la section `content`.
2. Le projet IDz est rafraîchi pour prendre en compte le nouveau fichier.

**La sauvegarde écrase le manifest existant.** Si la boîte est fermée via "Quitter" sans valider, aucune modification n'est appliquée.

### RG-06 : Structure du `content` dans le manifest
Après validation, la section `content` du manifest contient, pour chaque répertoire, la liste des fichiers sélectionnés :

```json
"content": {
  "src": ["MONPROG.cbl", "AUTREPROG.cbl"],
  "cpy": ["MACOPIE.cpy"],
  "asm": [],
  "skl": ["MONJCL.skl"]
}
```

Les répertoires sans fichier sélectionné ont une liste vide `[]`.

### RG-07 : Unicité du manifest
Si le répertoire `META-INF/` contient zéro ou plusieurs fichiers `.mf.json`, la boîte de dialogue ne peut pas s'ouvrir et un message d'erreur est affiché. Un projet doit avoir exactement **un seul manifest**.

---

## Interface graphique

La boîte de dialogue (991 × 831 pixels) est divisée en deux zones principales :

**Zone gauche — Métadonnées (lecture seule)**
- Code de l'application
- Objet du projet
- Nom de l'évolution
- Type de composant (BATCH / TP)
- Type de l'application
- Description

**Zone droite — Sélection des composants**
- Champ de filtre + bouton Reset
- Arbre hiérarchique à cases à cocher (répertoire → fichiers)

**Zone basse — Résumé par répertoire**
- Pour chaque répertoire, affichage des noms de fichiers cochés.

---

## Exemple

```
Projet : da01, évolution : correction_bug_42
Type : BATCH

Arbre affiché :
├── [✓] src
│    ├── [✓] MONPROG.cbl
│    └── [ ] AUTREPROG.cbl
├── [✓] cpy
│    └── [✓] MACOPIE.cpy
└── [ ] skl
     └── [ ] MONJCL.skl

Résumé :
src   = [MONPROG.cbl]
cpy   = [MACOPIE.cpy]
```

Après validation, le manifest contiendra `src: [MONPROG.cbl]` et `cpy: [MACOPIE.cpy]`.

---

## Erreurs possibles

| Situation | Comportement |
|---|---|
| Aucun projet sélectionné | Impossible d'ouvrir la boîte de dialogue |
| Aucun manifest dans META-INF/ | Avertissement, la boîte ne s'ouvre pas |
| Plusieurs manifests dans META-INF/ | Erreur, la boîte ne s'ouvre pas |
| Erreur lors de l'écriture du manifest | Message d'avertissement "Echec de la mise à jour du fichier manifest" |
