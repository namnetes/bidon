# Spécification fonctionnelle et technique — API `POST /evolutions`
# Fonction : Démarrer une évolution

> **Double vocation de ce document**
>
> 1. **Documentation fonctionnelle** — permet à un développeur de comprendre exactement ce que l'API doit faire, pourquoi, et comment.
> 2. **Prompt d'implémentation** — ce document constitue l'intégralité de la demande adressée à un agent IA chargé de produire le code. Il est auto-suffisant : l'agent n'a pas besoin de contexte supplémentaire pour implémenter la fonctionnalité.

---

## 1. Contexte métier

Dans le processus de développement mainframe LCL, toute modification du code source d'une application doit se faire dans le cadre d'une **évolution**. Une évolution est une unité de travail isolée, matérialisée par une **branche Git** dédiée (`feature_<nom>`) dans le dépôt GitLab de l'application concernée.

Cette API reproduit la logique de la fonction **Ctrl+1 — Démarrer une évolution** du plugin Eclipse IDz zDevOps, sous la forme d'un endpoint REST FastAPI. Elle :

1. Valide les paramètres de l'évolution
2. Vérifie l'existence de l'application dans GitLab et dans le référentiel autorisé (`applications.json`)
3. Clone ou met à jour le dépôt local de l'application
4. Crée la branche `feature_<nom>` depuis `master`
5. Initialise le fichier manifest `.mf.json` dans `META-INF/`
6. Commite et pousse la branche vers GitLab

### Vocabulaire clé

| Terme | Définition |
|---|---|
| **Code application** | Identifiant de 4 caractères (`daXX` ou `dyXX`) correspondant au nom du dépôt GitLab |
| **Évolution** | Branche Git `feature_<nom>` + fichier manifest associé |
| **Manifest** | Fichier JSON `META-INF/<code>_<nom>.mf.json` décrivant l'évolution |
| **Toolchain** | Environnement cible : `dev`, `rec`, `frm` ou `prd` — détermine les URLs GitLab et Jenkins |
| **applications.json** | Fichier de référence hébergé dans GitLab listant toutes les applications autorisées |
| **BATCH** | Application de traitement différé (code commençant par `da`) |
| **TP** | Application transactionnelle CICS (code commençant par `dy`) |

---

## 2. Stack technique obligatoire

| Composant | Version | Usage |
|---|---|---|
| Python | ≥ 3.12 | Langage |
| FastAPI | ≥ 0.115 | Framework HTTP |
| Pydantic | v2 (≥ 2.7) | Validation des modèles |
| python-gitlab | ≥ 4.9 | Appels API REST GitLab |
| gitpython | ≥ 3.1 | Opérations Git locales (clone, checkout, commit, push) |
| httpx | ≥ 0.27 | Client HTTP async (si appels externes additionnels) |
| uv | ≥ 0.4 | Gestionnaire de paquets — jamais `pip` ni `poetry` |

**Fichier `pyproject.toml` attendu :**

```toml
[project]
name = "zdevops-api"
version = "0.1.0"
requires-python = ">=3.12"
dependencies = [
    "fastapi>=0.115",
    "uvicorn[standard]>=0.30",
    "python-gitlab>=4.9",
    "gitpython>=3.1",
    "pydantic>=2.7",
    "pydantic-settings>=2.3",
    "httpx>=0.27",
]

[tool.ruff]
line-length = 88

[tool.ruff.lint]
select = ["E", "F", "I"]
```

**Lancement :**
```bash
uv run uvicorn zdevops_api.main:app --reload
```

---

## 3. Configuration — Variables d'environnement

Toute la configuration est lue depuis les variables d'environnement via `pydantic-settings`. Aucune valeur codée en dur dans le code.

| Variable | Type | Obligatoire | Description |
|---|---|---|---|
| `GITLAB_URL` | `str` | Oui | URL de base du serveur GitLab (ex : `https://scm.saas.cagip.group.gca`) |
| `GITLAB_TOKEN` | `str` | Oui | Token d'accès personnel GitLab (scope : `api`) |
| `GITLAB_GROUP` | `str` | Oui | Namespace/groupe GitLab contenant les dépôts applicatifs (ex : `fr.lcl.zdevops.dev`) |
| `GITLAB_PARAMS_PROJECT_ID` | `int` | Oui | ID du projet GitLab hébergeant `applications.json` (projet `app.params`) |
| `WORKSPACE_BASE_PATH` | `str` | Oui | Chemin absolu du répertoire local où les dépôts sont clonés (ex : `/home/dev/workspace`) |
| `TOOLCHAIN` | `str` | Oui | Environnement actif : `dev`, `rec`, `frm` ou `prd` |
| `GIT_USER_NAME` | `str` | Oui | Nom à utiliser dans les commits Git créés par l'API |
| `GIT_USER_EMAIL` | `str` | Oui | Email à utiliser dans les commits Git créés par l'API |

**Exemple `.env` (développement local) :**
```dotenv
GITLAB_URL=https://scm.saas.cagip.group.gca
GITLAB_TOKEN=glpat-xxxxxxxxxxxxxxxxxxxx
GITLAB_GROUP=fr.lcl.zdevops.dev
GITLAB_PARAMS_PROJECT_ID=1042
WORKSPACE_BASE_PATH=/home/dev/workspace
TOOLCHAIN=dev
GIT_USER_NAME=Jean Dupont
GIT_USER_EMAIL=jean.dupont@lcl.fr
```

**Classe de configuration :**

```python
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    gitlab_url: str
    gitlab_token: str
    gitlab_group: str
    gitlab_params_project_id: int
    workspace_base_path: str
    toolchain: str
    git_user_name: str
    git_user_email: str

    model_config = {"env_file": ".env", "case_sensitive": False}
```

---

## 4. Modèles de données

### 4.1 Énumérations

```python
from enum import Enum

class ComponentType(str, Enum):
    BATCH = "BATCH"
    TP = "TP"

class ExistingRepoStrategy(str, Enum):
    DELETE_AND_RECREATE = "DELETE_AND_RECREATE"
    UPDATE = "UPDATE"
```

### 4.2 Corps de la requête — `CreateEvolutionRequest`

```python
from pydantic import BaseModel, Field, field_validator
import re

class CreateEvolutionRequest(BaseModel):
    app_code: str = Field(
        ...,
        description="Code application : 4 caractères commençant par 'da' ou 'dy'",
        examples=["da01", "dyab"]
    )
    evolution_name: str = Field(
        ...,
        description="Nom de l'évolution (sans préfixe 'feature_')",
        examples=["correction_calcul_tva"]
    )
    description: str = Field(
        ...,
        min_length=1,
        description="Description libre de l'évolution"
    )
    component_type: ComponentType = Field(
        ...,
        description="Type de composant : BATCH ou TP"
    )
    existing_repo_strategy: ExistingRepoStrategy = Field(
        default=ExistingRepoStrategy.UPDATE,
        description=(
            "Comportement si le dépôt est déjà cloné localement. "
            "DELETE_AND_RECREATE : supprime et reclone. "
            "UPDATE : commit en cours + pull master + nouvelle branche."
        )
    )
```

### 4.3 Corps de la réponse — `CreateEvolutionResponse`

```python
class CreateEvolutionResponse(BaseModel):
    branch_name: str = Field(
        description="Nom complet de la branche créée (ex: 'feature_correction_calcul_tva')"
    )
    manifest_path: str = Field(
        description="Chemin relatif du manifest dans le dépôt (ex: 'META-INF/da01_correction_calcul_tva.mf.json')"
    )
    local_repo_path: str = Field(
        description="Chemin absolu du dépôt cloné sur le serveur"
    )
    manifest_name: str = Field(
        description="Valeur du champ manifest_name (ex: 'da01_000042_correction_calcul_tva')"
    )
    artifact_number: int = Field(
        description="Numéro d'artefact assigné à cette évolution"
    )
```

### 4.4 Modèle du manifest — `ManifestModel`

Structure exacte du fichier `META-INF/<code>_<nom>.mf.json` à créer sur disque :

```python
class ManifestContent(BaseModel):
    model_config = {"extra": "allow"}

class ManifestModel(BaseModel):
    entity: str = "LCL"
    application_code: str
    application_type: str          # "STD" pour da*, "CRF" pour dy*
    component_type: ComponentType
    description: str
    manifest_name: str             # "<code>_<artifact_number_padded>_<evolution_name>"
    content: dict[str, list[str]] = Field(default_factory=dict)
    dependancies: list[str] = Field(default_factory=list)  # Orthographe intentionnelle — ne pas corriger
```

> **Important :** le champ est `dependancies` (avec une faute d'orthographe) et non `dependencies`. Cette casse est volontaire et fossilisée dans le schéma de production. Ne pas "corriger" ce nom de champ.

### 4.5 Modèle d'erreur — `ErrorResponse`

```python
class ErrorResponse(BaseModel):
    code: str = Field(description="Code d'erreur machine (ex: 'APP_NOT_FOUND')")
    message: str = Field(description="Message lisible par l'utilisateur")
    detail: str | None = None
```

---

## 5. Endpoint principal

```
POST /api/v1/evolutions
Content-Type: application/json
```

**Réponse succès :** `201 Created` avec un corps `CreateEvolutionResponse`

**Timeout conseillé côté client :** 120 secondes (le clone peut être long sur un grand dépôt)

---

## 6. Règles de gestion

Les règles ci-dessous sont appliquées **dans l'ordre indiqué**. Toute règle échouée interrompt le traitement et retourne immédiatement une réponse d'erreur.

---

### RG-01 — Validation du format du code application

**Condition :** avant tout appel réseau.

Le champ `app_code` doit satisfaire le pattern `^d[ay][a-z0-9]{2}$` :
- Exactement 4 caractères
- Commence par `da` (application BATCH) ou `dy` (application TP)
- Les 2 derniers caractères sont alphanumériques minuscules

**Si invalide →**
```json
HTTP 422 Unprocessable Entity
{
  "code": "INVALID_APP_CODE_FORMAT",
  "message": "Le code application doit commencer par 'da' ou 'dy' et contenir exactement 4 caractères alphanumériques",
  "detail": "Valeur reçue : '<valeur_saisie>'"
}
```

**Déduction du `application_type` :**
- `app_code` commence par `da` → `application_type = "STD"`
- `app_code` commence par `dy` → `application_type = "CRF"`

---

### RG-02 — Validation du format du nom d'évolution

**Condition :** avant tout appel réseau, après RG-01.

Le champ `evolution_name` doit satisfaire les contraintes suivantes :
- Pattern : `^[a-zA-Z0-9_]+$` (alphanumériques + tiret bas uniquement)
- Ne contient pas d'espace
- Ne commence pas par `feature` (le préfixe est ajouté automatiquement par l'API)
- Longueur comprise entre 1 et 100 caractères

**Si invalide (espace) →**
```json
HTTP 422 Unprocessable Entity
{
  "code": "INVALID_EVOLUTION_NAME_SPACES",
  "message": "Le nom de l'évolution ne doit pas contenir d'espace"
}
```

**Si invalide (caractères interdits) →**
```json
HTTP 422 Unprocessable Entity
{
  "code": "INVALID_EVOLUTION_NAME_CHARS",
  "message": "Seuls les caractères alphanumériques et '_' sont autorisés dans le nom de l'évolution"
}
```

**Si commence par `feature` →**
```json
HTTP 422 Unprocessable Entity
{
  "code": "INVALID_EVOLUTION_NAME_PREFIX",
  "message": "Le nom de l'évolution ne doit pas commencer par 'feature' (le préfixe est ajouté automatiquement)"
}
```

La branche complète à créer est : `feature_<evolution_name>`.

---

### RG-03 — Vérification de l'existence du dépôt dans GitLab

**Appel GitLab :** `GET /api/v4/projects/<group>%2F<app_code>`

Vérifier que le projet `<GITLAB_GROUP>/<app_code>` existe dans GitLab.

**Si le projet n'existe pas (404) →**
```json
HTTP 404 Not Found
{
  "code": "APP_NOT_FOUND_IN_GITLAB",
  "message": "L'application 'da01' n'existe pas dans GitLab"
}
```

**Si erreur réseau ou token invalide →**
```json
HTTP 502 Bad Gateway
{
  "code": "GITLAB_UNREACHABLE",
  "message": "Impossible de contacter GitLab",
  "detail": "<message d'exception>"
}
```

---

### RG-04 — Chargement des branches existantes et vérification d'unicité

**Appel GitLab :** `GET /api/v4/projects/<project_id>/repository/branches`

Récupérer toutes les branches du dépôt. Vérifier que la branche `feature_<evolution_name>` **n'existe pas déjà**.

**Si la branche existe déjà →**
```json
HTTP 409 Conflict
{
  "code": "EVOLUTION_ALREADY_EXISTS",
  "message": "L'évolution 'feature_correction_calcul_tva' existe déjà dans le dépôt distant"
}
```

---

### RG-05 — Vérification dans `applications.json`

**Appel GitLab :** `GET /api/v4/projects/<GITLAB_PARAMS_PROJECT_ID>/repository/files/applications.json/raw?ref=master`

Le fichier `applications.json` est hébergé dans le projet GitLab identifié par `GITLAB_PARAMS_PROJECT_ID`. C'est un projet distinct des dépôts applicatifs.

**Structure attendue du fichier :**
```json
{
  "da01": {
    "next_artifact_number": 42,
    "description": "Application de paie"
  },
  "dyab": {
    "next_artifact_number": 7,
    "description": "Application CICS de consultation"
  }
}
```

Vérifier que `app_code` est une clé présente dans ce JSON.

**Si absent →**
```json
HTTP 404 Not Found
{
  "code": "APP_NOT_IN_REGISTRY",
  "message": "Le code application 'da01' n'est pas référencé dans le fichier de référence applications.json"
}
```

**Numéro d'artefact :** lire la valeur `next_artifact_number` pour l'application. Ce numéro sera incrémenté et mis à jour dans `applications.json` après création réussie de l'évolution (voir RG-09).

---

### RG-06 — Détermination de l'état du dépôt local

Le dépôt local est attendu à `<WORKSPACE_BASE_PATH>/<app_code>/`.

**Deux cas possibles :**

**Cas A — Dépôt absent :** le répertoire n'existe pas ou n'est pas un dépôt Git valide.
→ Appliquer **RG-07** (clone depuis `master`).

**Cas B — Dépôt présent :** le répertoire existe et contient un dépôt Git valide.
→ Brancher selon `existing_repo_strategy` :
  - `DELETE_AND_RECREATE` → appliquer **RG-08a**
  - `UPDATE` → appliquer **RG-08b**

Un répertoire est considéré comme un dépôt Git valide si `os.path.exists(os.path.join(path, ".git"))` est vrai.

---

### RG-07 — Clone depuis GitLab (dépôt absent — cas nominal)

Séquence d'opérations dans l'ordre :

1. Construire l'URL de clone : `<GITLAB_URL>/<GITLAB_GROUP>/<app_code>.git`
   - Injecter le token dans l'URL pour l'authentification : `https://oauth2:<GITLAB_TOKEN>@<host>/<path>.git`
2. Cloner le dépôt dans `<WORKSPACE_BASE_PATH>/<app_code>/` sur la branche `master`
   - Utiliser `git.Repo.clone_from(url, local_path, branch="master")`
3. Configurer les informations de l'auteur Git dans le dépôt local :
   ```
   git config user.name "<GIT_USER_NAME>"
   git config user.email "<GIT_USER_EMAIL>"
   ```
4. Installer les hooks de protection de `master` (voir RG-07-HOOKS ci-dessous)
5. Créer la branche locale `feature_<evolution_name>` depuis `master`
6. Effectuer le checkout sur cette branche
7. Écrire le fichier manifest (voir RG-09)
8. Commiter le manifest (voir RG-10)
9. Pousser la branche vers GitLab (voir RG-11)

**Si le clone échoue →**
```json
HTTP 500 Internal Server Error
{
  "code": "CLONE_FAILED",
  "message": "Échec du clone du dépôt 'da01'",
  "detail": "<message d'exception>"
}
```

#### RG-07-HOOKS — Hooks de protection de `master`

Créer le fichier `<local_path>/.git/hooks/pre-commit` avec ce contenu :

```bash
#!/bin/bash
set -euo pipefail
branch=$(git rev-parse --abbrev-ref HEAD)
if [ "$branch" = "master" ]; then
  echo "ERREUR : les commits directs sur master sont interdits."
  echo "Créez une branche feature_ pour vos modifications."
  exit 1
fi
```

Rendre ce fichier exécutable (`chmod +x`).

---

### RG-08a — Stratégie DELETE_AND_RECREATE (dépôt existant)

1. Supprimer physiquement le répertoire `<WORKSPACE_BASE_PATH>/<app_code>/` et tout son contenu (`shutil.rmtree`)
2. Appliquer entièrement **RG-07** comme si le dépôt était absent

---

### RG-08b — Stratégie UPDATE (dépôt existant)

Séquence d'opérations dans l'ordre :

1. Ouvrir le dépôt local existant (`git.Repo(local_path)`)
2. Vérifier l'état du dépôt (`repo.is_dirty(untracked_files=True)`) :
   - Si des modifications non commitées existent → les commiter automatiquement :
     ```
     repo.git.add(A=True)
     repo.index.commit("Sauvegarde automatique avant création de l'évolution feature_<nom>")
     ```
3. Basculer sur `master` :
   ```
   repo.git.checkout("master")
   ```
4. Mettre à jour `master` depuis GitLab :
   ```
   repo.remotes.origin.pull("master")
   ```
5. Créer la branche locale `feature_<evolution_name>` depuis `master` :
   ```
   repo.create_head("feature_<evolution_name>")
   ```
6. Effectuer le checkout sur la nouvelle branche
7. Configurer les informations de l'auteur Git si elles ne le sont pas déjà
8. Écrire le fichier manifest (voir RG-09)
9. Commiter le manifest (voir RG-10)
10. Pousser la branche vers GitLab (voir RG-11)

**Si le pull échoue (conflits, réseau) →**
```json
HTTP 500 Internal Server Error
{
  "code": "PULL_FAILED",
  "message": "Impossible de mettre à jour la branche master depuis GitLab",
  "detail": "<message d'exception>"
}
```

---

### RG-09 — Écriture du fichier manifest

Le manifest est écrit dans le dépôt local **après** le checkout sur la branche `feature_<evolution_name>`.

**Emplacement :** `<WORKSPACE_BASE_PATH>/<app_code>/META-INF/<app_code>_<evolution_name>.mf.json`

Créer le répertoire `META-INF/` s'il n'existe pas.

**Contenu du manifest :**

```json
{
  "entity": "LCL",
  "application_code": "<app_code>",
  "application_type": "<STD ou CRF>",
  "component_type": "<BATCH ou TP>",
  "description": "<description encodée>",
  "manifest_name": "<app_code>_<artifact_number_padded>_<evolution_name>",
  "content": {},
  "dependancies": []
}
```

**Calcul du `manifest_name` :**
- `artifact_number_padded` = numéro d'artefact lu dans `applications.json` (RG-05), formaté sur 6 chiffres avec zéro à gauche : `str(artifact_number).zfill(6)`
- Exemple : application `da01`, numéro `42`, évolution `correction_calcul_tva` → `manifest_name = "da01_000042_correction_calcul_tva"`

**Encodage :** le fichier est écrit en UTF-8 avec `json.dumps(..., ensure_ascii=False, indent=2)`.

---

### RG-10 — Commit initial du manifest

```python
repo.git.add(A=True)
repo.index.commit(
    f"feat: initialisation de l'évolution {branch_name}",
    author=git.Actor(settings.git_user_name, settings.git_user_email),
    committer=git.Actor(settings.git_user_name, settings.git_user_email),
)
```

**Si le commit échoue →** lever l'exception (ne pas l'avaler silencieusement). Retourner :
```json
HTTP 500 Internal Server Error
{
  "code": "COMMIT_FAILED",
  "message": "Échec du commit initial du manifest",
  "detail": "<message d'exception>"
}
```

---

### RG-11 — Push de la branche vers GitLab

```python
repo.remotes.origin.push(
    refspec=f"refs/heads/{branch_name}:refs/heads/{branch_name}"
)
```

Vérifier que le push a réussi (tester le `PushInfo.flags` : absence de `ERROR` ou `REJECTED`).

**Si le push échoue →**
```json
HTTP 500 Internal Server Error
{
  "code": "PUSH_FAILED",
  "message": "Impossible de pousser la branche 'feature_correction_calcul_tva' vers GitLab",
  "detail": "<message d'exception>"
}
```

---

### RG-12 — Mise à jour de `applications.json`

**Après** un push réussi, incrémenter le `next_artifact_number` de l'application dans `applications.json` et pousser le fichier mis à jour sur GitLab.

**Appel GitLab :** `PUT /api/v4/projects/<GITLAB_PARAMS_PROJECT_ID>/repository/files/applications.json`

```python
import base64, json

# Lire la valeur actuelle du fichier (déjà lue en RG-05 — réutiliser)
applications[app_code]["next_artifact_number"] += 1
new_content = json.dumps(applications, ensure_ascii=False, indent=2)

gl.projects.get(settings.gitlab_params_project_id).files.update(
    "applications.json",
    {
        "branch": "master",
        "content": new_content,
        "commit_message": f"chore: increment artifact number for {app_code} (evolution {branch_name})",
        "encoding": "text",
    }
)
```

> **Note architecturale :** cette opération n'est pas atomique (risque de race condition documenté en M1/P7 dans l'analyse existante). Dans le contexte de cette implémentation, ce comportement est conservé à l'identique avec l'existant Java. Une future amélioration pourrait utiliser le `last_commit_id` de GitLab pour un optimistic locking.

**Si la mise à jour échoue →** loguer l'erreur en `WARNING` mais **ne pas faire échouer la réponse HTTP** (la branche et le manifest ont été créés avec succès — l'incrémentation du compteur est secondaire). Inclure un champ `warnings` dans la réponse :

```json
{
  "branch_name": "feature_correction_calcul_tva",
  "...": "...",
  "warnings": ["Le compteur d'artefact n'a pas pu être mis à jour dans applications.json : <detail>"]
}
```

---

## 7. Structure de réponse complète

### 7.1 Succès (201 Created)

```json
{
  "branch_name": "feature_correction_calcul_tva",
  "manifest_path": "META-INF/da01_correction_calcul_tva.mf.json",
  "local_repo_path": "/home/dev/workspace/da01",
  "manifest_name": "da01_000042_correction_calcul_tva",
  "artifact_number": 42,
  "warnings": []
}
```

### 7.2 Tableau des codes d'erreur

| Code HTTP | Code machine | Situation |
|---|---|---|
| 422 | `INVALID_APP_CODE_FORMAT` | Format app_code invalide |
| 422 | `INVALID_EVOLUTION_NAME_SPACES` | Espaces dans le nom |
| 422 | `INVALID_EVOLUTION_NAME_CHARS` | Caractères interdits |
| 422 | `INVALID_EVOLUTION_NAME_PREFIX` | Nom commence par `feature` |
| 404 | `APP_NOT_FOUND_IN_GITLAB` | Dépôt absent de GitLab |
| 404 | `APP_NOT_IN_REGISTRY` | Code absent de `applications.json` |
| 409 | `EVOLUTION_ALREADY_EXISTS` | Branche déjà existante |
| 500 | `CLONE_FAILED` | Échec du clone Git |
| 500 | `PULL_FAILED` | Échec du pull sur master |
| 500 | `COMMIT_FAILED` | Échec du commit initial |
| 500 | `PUSH_FAILED` | Échec du push vers GitLab |
| 502 | `GITLAB_UNREACHABLE` | GitLab injoignable |

---

## 8. Architecture du code

### 8.1 Structure de fichiers attendue

```
zdevops_api/
├── main.py                     ← Application FastAPI, inclusion du router
├── config.py                   ← Classe Settings (pydantic-settings)
├── models/
│   ├── __init__.py
│   ├── evolution.py            ← CreateEvolutionRequest, CreateEvolutionResponse
│   └── manifest.py             ← ManifestModel
├── routers/
│   ├── __init__.py
│   └── evolutions.py           ← Route POST /api/v1/evolutions
├── services/
│   ├── __init__.py
│   ├── gitlab_service.py       ← Toutes les interactions API GitLab
│   └── git_service.py          ← Toutes les opérations Git locales (gitpython)
└── exceptions.py               ← Exceptions métier typées + exception handlers FastAPI
```

### 8.2 Séparation des responsabilités

**`gitlab_service.py`** expose :
- `get_project(app_code: str) -> gl.projects.Project` — RG-03
- `list_branches(project_id: int) -> list[str]` — RG-04
- `get_applications_json() -> dict` — RG-05
- `update_applications_json(applications: dict, app_code: str, branch_name: str) -> None` — RG-12

**`git_service.py`** expose :
- `clone_repo(app_code: str, clone_url: str, local_path: str) -> git.Repo` — RG-07
- `install_master_hook(local_path: str) -> None` — RG-07-HOOKS
- `create_and_checkout_branch(repo: git.Repo, branch_name: str) -> None`
- `commit_and_push(repo: git.Repo, branch_name: str, commit_message: str) -> None` — RG-10 + RG-11
- `update_existing_repo(repo: git.Repo, branch_name: str) -> None` — RG-08b

**`routers/evolutions.py`** orchestre l'ensemble dans l'ordre RG-01 → RG-12.

### 8.3 Gestion des exceptions

Définir des exceptions métier dans `exceptions.py` :

```python
class ZDevOpsError(Exception):
    def __init__(self, code: str, message: str, detail: str | None = None):
        self.code = code
        self.message = message
        self.detail = detail

class AppNotFoundError(ZDevOpsError): ...
class EvolutionAlreadyExistsError(ZDevOpsError): ...
class CloneFailedError(ZDevOpsError): ...
# etc.
```

Enregistrer un exception handler global dans `main.py` :

```python
@app.exception_handler(ZDevOpsError)
async def zdevops_exception_handler(request, exc: ZDevOpsError):
    status_map = {
        "INVALID_APP_CODE_FORMAT": 422,
        "APP_NOT_FOUND_IN_GITLAB": 404,
        "EVOLUTION_ALREADY_EXISTS": 409,
        "CLONE_FAILED": 500,
        "GITLAB_UNREACHABLE": 502,
        # ...
    }
    return JSONResponse(
        status_code=status_map.get(exc.code, 500),
        content=ErrorResponse(code=exc.code, message=exc.message, detail=exc.detail).model_dump()
    )
```

---

## 9. Algorithme complet de l'endpoint (pseudo-code)

```
POST /api/v1/evolutions
    ├── [RG-01] Valider app_code (format regex) → 422 si invalide
    ├── [RG-02] Valider evolution_name (format, pas d'espace, pas de préfixe) → 422 si invalide
    ├── [RG-03] Appel GitLab : vérifier existence du projet app_code → 404 / 502 si erreur
    ├── [RG-04] Appel GitLab : lister les branches → 409 si feature_<nom> existe déjà
    ├── [RG-05] Appel GitLab : lire applications.json → 404 si app_code absent
    │           Lire artifact_number
    ├── [RG-06] Vérifier l'état du dépôt local (<WORKSPACE_BASE_PATH>/<app_code>/)
    │    ├── Absent → [RG-07] clone depuis master
    │    ├── Présent + DELETE_AND_RECREATE → [RG-08a] supprimer + [RG-07]
    │    └── Présent + UPDATE → [RG-08b] commit + pull master + checkout branche
    ├── [RG-07-HOOKS] Installer le hook pre-commit de protection de master
    ├── [RG-09] Écrire META-INF/<code>_<nom>.mf.json avec manifest_name calculé
    ├── [RG-10] git add + git commit "feat: initialisation de l'évolution..."
    ├── [RG-11] git push origin feature_<nom>
    ├── [RG-12] Mettre à jour next_artifact_number dans applications.json via API GitLab
    └── Retourner 201 + CreateEvolutionResponse
```

---

## 10. Exemples de requêtes/réponses

### 10.1 Création nominale (dépôt absent)

**Requête :**
```bash
curl -X POST http://localhost:8000/api/v1/evolutions \
  -H "Content-Type: application/json" \
  -d '{
    "app_code": "da01",
    "evolution_name": "correction_calcul_tva",
    "description": "Correction du calcul de la TVA sur les opérations de crédit",
    "component_type": "BATCH"
  }'
```

**Réponse (201) :**
```json
{
  "branch_name": "feature_correction_calcul_tva",
  "manifest_path": "META-INF/da01_correction_calcul_tva.mf.json",
  "local_repo_path": "/home/dev/workspace/da01",
  "manifest_name": "da01_000042_correction_calcul_tva",
  "artifact_number": 42,
  "warnings": []
}
```

### 10.2 Dépôt déjà présent, stratégie UPDATE

**Requête :**
```bash
curl -X POST http://localhost:8000/api/v1/evolutions \
  -H "Content-Type: application/json" \
  -d '{
    "app_code": "da01",
    "evolution_name": "nouvelle_fonctionnalite",
    "description": "Ajout du traitement des remboursements anticipés",
    "component_type": "BATCH",
    "existing_repo_strategy": "UPDATE"
  }'
```

### 10.3 Code application invalide

**Requête :**
```bash
curl -X POST http://localhost:8000/api/v1/evolutions \
  -H "Content-Type: application/json" \
  -d '{"app_code": "abcd", "evolution_name": "test", "description": "test", "component_type": "BATCH"}'
```

**Réponse (422) :**
```json
{
  "code": "INVALID_APP_CODE_FORMAT",
  "message": "Le code application doit commencer par 'da' ou 'dy' et contenir exactement 4 caractères alphanumériques",
  "detail": "Valeur reçue : 'abcd'"
}
```

### 10.4 Évolution déjà existante

**Réponse (409) :**
```json
{
  "code": "EVOLUTION_ALREADY_EXISTS",
  "message": "L'évolution 'feature_correction_calcul_tva' existe déjà dans le dépôt distant",
  "detail": null
}
```

---

## 11. Tests attendus

Le code livré doit inclure une suite de tests dans `tests/` utilisant `pytest` (via `uv run pytest`).

### 11.1 Tests unitaires (sans appel réseau réel)

Utiliser `unittest.mock` ou `pytest-mock` pour mocker `gitlab` et `git.Repo`.

| Test | Scénario |
|---|---|
| `test_invalid_app_code_format` | Codes `abcd`, `da`, `da001`, `da0!` → 422 |
| `test_valid_app_code_da` | `da01` → application_type = "STD" |
| `test_valid_app_code_dy` | `dy99` → application_type = "CRF" |
| `test_evolution_name_with_space` | `"ma correction"` → 422 INVALID_EVOLUTION_NAME_SPACES |
| `test_evolution_name_with_prefix` | `"feature_test"` → 422 INVALID_EVOLUTION_NAME_PREFIX |
| `test_evolution_name_special_chars` | `"test-ok"` → 422 INVALID_EVOLUTION_NAME_CHARS |
| `test_app_not_found_in_gitlab` | GitLab retourne 404 → 404 APP_NOT_FOUND_IN_GITLAB |
| `test_branch_already_exists` | Branche présente dans la liste → 409 EVOLUTION_ALREADY_EXISTS |
| `test_app_not_in_registry` | Code absent de applications.json → 404 APP_NOT_IN_REGISTRY |
| `test_manifest_content` | Vérifier le contenu exact du manifest écrit sur disque |
| `test_manifest_name_padding` | artifact_number=5 → `da01_000005_nom` |
| `test_hook_created` | Vérifier l'existence et le contenu du hook pre-commit |

### 11.2 Tests d'intégration (optionnels, avec GitLab de test)

Utiliser une instance GitLab de test (ex : GitLab CE en Docker) pour valider le flux complet end-to-end.

---

## 12. Contraintes non-fonctionnelles

| Contrainte | Exigence |
|---|---|
| **Durée max** | L'endpoint peut prendre jusqu'à 120 secondes (clone réseau) — ne pas utiliser de timeout côté serveur inférieur à cette valeur |
| **Concurrence** | Ne pas protéger contre les accès concurrents (cohérence avec l'implémentation Java existante) |
| **Logging** | Utiliser `logging` Python standard (`logging.getLogger(__name__)`) — pas de `print()`. Niveau INFO pour les opérations, DEBUG pour le détail Git, WARNING pour les erreurs non-bloquantes |
| **Sécurité** | Ne jamais loguer le token GitLab. Construire l'URL de clone avec le token (`oauth2:<token>@`) mais ne pas l'inclure dans les logs ni dans les réponses d'erreur |
| **Commentaires** | Aucun commentaire de code sauf si le WHY est non-évident (contrainte métier cachée, contournement d'un bug connu) |
| **Style** | Ruff, 88 caractères, type hints sur toutes les fonctions |
