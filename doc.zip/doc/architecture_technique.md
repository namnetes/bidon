# Architecture technique du plugin zDevOps IDz

Ce document est destiné aux **développeurs du plugin** qui souhaitent comprendre son fonctionnement interne, contribuer au code, ou diagnostiquer des problèmes.

---

## Vue d'ensemble

Le plugin zDevOps est un **plugin Eclipse RCP** (Rich Client Platform) écrit en Java 17. Il s'intègre dans IBM Developer for z/OS (IDz), qui est lui-même basé sur Eclipse.

### Ce que le plugin fait
- Opérations Git locales (JGit, sans subprocess)
- Appels API REST GitLab (gitlab4j-api)
- Appels API REST Jenkins (Java 11 HttpClient natif)
- Manipulation de fichiers JSON (manifests, descriptors)
- Gestion des credentials (Eclipse Equinox Secure Storage)
- UI Eclipse (SWT/JFace dialogs, handlers, views)

### Ce que le plugin ne fait PAS
Il ne compile rien, ne déploie rien, n'analyse rien. Tout le traitement métier mainframe est délégué aux pipelines Jenkins FabCI.

---

## Structure du projet Maven/Tycho

```
plugin_zdevops/
├── pom.xml                    ← POM parent (Tycho 4.0.8, Java 17)
├── plugin/                    ← Le bundle OSGi principal
│   ├── META-INF/MANIFEST.MF   ← Manifeste OSGi (Bundle-SymbolicName, dépendances)
│   ├── plugin.xml             ← Contributions Eclipse (menus, commandes, vues, raccourcis)
│   ├── pom.xml
│   └── src/
├── fragment/                  ← Fragment OSGi (surcharges de comportement)
│   ├── META-INF/MANIFEST.MF   ← Fragment-Host: bundle principal
│   └── pom.xml
├── feature/                   ← Feature Eclipse (regroupe plugin + fragment)
│   ├── feature.xml
│   └── pom.xml
└── site/                      ← P2 update site (pour l'installation dans IDz)
    ├── category.xml
    └── pom.xml
```

**Build :**
```bash
cd plugin_zdevops
mvn clean package -s settings.xml
```
Le site P2 résultant est dans `site/target/repository/`.

---

## Package Java — structure détaillée

```
fr.lcl.zdevops.idz.plugin/
├── Activator.java                ← Cycle de vie du plugin (start/stop)
├── config/
│   ├── ConfigLoader.java         ← Lecture des fichiers .properties par toolchain
│   ├── dev.properties            ← Config environnement DEV
│   ├── rec.properties            ← Config environnement REC
│   ├── frm.properties            ← Config environnement FRM
│   └── prd.properties            ← Config environnement PRD
├── exceptions/
│   ├── IdzPluginException.java   ← Exception de base du plugin
│   ├── GitLabAuthenticationException.java
│   ├── InvalidTokenException.java
│   └── PermissionDeniedException.java
├── services/
│   ├── IGitLabService.java       ← Interface Git+GitLab
│   ├── IGitService.java          ← Interface Git seul
│   ├── impl/
│   │   ├── GitLabService.java    ← IMPLÉMENTATION PRINCIPALE (~1800 lignes)
│   │   └── GitService.java       ← Alternative (moins utilisée)
│   └── JenkinsJobService.java    ← Intégration Jenkins (HTTP Client)
├── ui/
│   ├── dialogs/                  ← Boîtes de dialogue SWT
│   ├── handlers/                 ← Handlers Eclipse (actions menu/clavier)
│   ├── models/                   ← Modèles de données UI
│   ├── monitors/                 ← Opérations longues (Eclipse Jobs)
│   └── views/                   ← Vues Eclipse (JenkinsBrowserView)
└── utils/
    ├── AppProperties.java        ← Configuration statique (chargée au démarrage)
    ├── EclipsePluginHelper.java  ← Helpers Eclipse (secure storage, refresh…)
    ├── EclipseLogger.java        ← Wrapper de logging
    ├── GestionCopysUtils.java    ← Utilitaires copybooks
    ├── Messages.java             ← Constantes de messages
    ├── ProjectUtils.java         ← Utilitaires projet Eclipse
    └── ValidationUtils.java      ← Validation des entrées utilisateur
```

---

## Couche de configuration

### Démarrage : `AppProperties` (bloc static)

Au premier accès à `AppProperties`, un bloc `static {}` s'exécute :
1. Lit le workspace Eclipse via `Platform.getInstanceLocation()`
2. Ouvre `zdevops.ini` pour lire la toolchain (`dev`, `rec`, `frm`, `prd`)
3. Instancie `ConfigLoader(toolchain)` qui charge le fichier `.properties` embarqué correspondant
4. Initialise toutes les constantes statiques (`JENKINS_BASE_URL`, `GITLAB_API_URL`, etc.)
5. Récupère le token GitLab du stockage sécurisé et initialise le `CredentialsProvider` JGit

**Conséquence :** toute la configuration est immuable après le démarrage du plugin. Pour changer de toolchain, il faut modifier `zdevops.ini` et **redémarrer IDz**.

### Fichiers `.properties` par toolchain

Exemple (`prd.properties`) :
```properties
gitlab.base.url=https://scm.saas.cagip.group.gca
gitlab.api.url=https://scm.saas.cagip.group.gca/api/v4
jenkins.url.base=https://fabci-prd.ci.lcl.group.gca/api/json
gitlab.app.params.id=134997
gitlab.app.group.da.id=180713
gitlab.app.group.dy.id=180714
gitlab.app.copies.partagees.id=122767
jenkins.pipeline.build=BuildAndPush
jenkins.pipeline.deploy=ProxyCD
jenkins.pipeline.promote.unitaire=PromoteUnitaire
jenkins.pipeline.audit.qualite=auditEtQualite
deploy.site.name=DEV
toolchain.name=prd
```

---

## Couche service — `GitLabService` (le God Object)

`GitLabService` est la classe centrale (~1800 lignes). Elle regroupe toutes les responsabilités :

| Responsabilité | Méthodes clés |
|---|---|
| API GitLab (gitlab4j) | `fetchBranches()`, `getProjectByName()`, `createBranch()`, `fetchManifestFromGitLab()` |
| JGit local | `cloneProject()`, `commitChanges()`, `switcherBranche()`, `pushBranch()` |
| Manifest JSON | `writeBranchManifest()`, `updateManifestContent()`, `parseManifestFromFile()` |
| applications.json | `fetchApplications()`, `updateApplication()`, `pushUpdatedApplications()` |
| copybooks | `downloadCopybookFromGitLab()` (délégué à `GestionCopysUtils`) |
| zapp.yaml | `updateHlq()` (modification du HLQ dans le fichier YAML) |

> **Note architecturale :** le README reconnaît que la fusion de `GitLabService` et `GitService` est un chantier. La direction correcte serait de **séparer** cette classe en `EvolutionService`, `ManifestService`, `CopybookService`, etc. Voir [analyse des erreurs de conception](analyse_erreurs_conception.md) — A2.

### Opérations Git (JGit)

Toutes les opérations Git sont effectuées via la bibliothèque **JGit** (pure Java, aucun appel subprocess à `git`). Les opérations longues (clone, push) sont enveloppées dans des `IRunnableWithProgress` pour afficher une barre de progression.

```java
// Exemple de clone avec progression
Git.cloneRepository()
   .setURI(repoUrl)
   .setDirectory(localDir)
   .setCredentialsProvider(AppProperties.PROVIDER)  // token GitLab
   .setProgressMonitor(monitor)
   .call();
```

### Opérations GitLab (gitlab4j)

Les appels à l'API REST GitLab utilisent la bibliothèque `gitlab4j-api` :

```java
GitLabApi gitLabApi = new GitLabApi(AppProperties.GITLAB_BASE_URL, token);
List<Branch> branches = gitLabApi.getRepositoryApi().getBranches(projectId);
```

---

## Couche service — `JenkinsJobService`

Gère toutes les interactions avec Jenkins via l'API REST, en utilisant le `HttpClient` Java 11 (natif, pas de bibliothèque tierce).

### Authentification Jenkins

```java
String credentials = Base64.encode(
    username + "@id.fr.cly" + ":" + jenkinsToken
);
// Header : Authorization: Basic <credentials>
```

### Séquence d'appel (3 phases)

```
1. POST /job/<pipeline>/buildWithParameters?<param>=<valeur>
   → Réponse 201 + header Location: <queue_url>

2. GET <queue_url>/api/json  (polling toutes les 2s, max 30 tentatives)
   → Attendre que executable.url soit présent
   → Récupérer l'URL du build

3. GET <build_url>/api/json  (polling toutes les 2s)
   → Attendre que building == false
   → Ouvrir Blue Ocean dans la vue IDz
```

### Vue Blue Ocean

La méthode `openBrowserInView()` construit l'URL Blue Ocean :
```
<jenkins_base>/blue/organizations/jenkins/<jobName>/detail/<jobName>/<buildNum>/pipeline/
```
Et l'affiche dans `JenkinsBrowserView` (un composant SWT Browser intégré dans IDz).

---

## Couche UI — handlers et dialogs

### Handlers Eclipse

Chaque action du menu zDevOps correspond à un `Handler` (classe implémentant `IHandler`). Le handler :
1. Identifie le projet actif (`ProjectUtils.getCurrentProject()`)
2. Vérifie les prérequis (token, manifest)
3. Ouvre la dialog correspondante ou déclenche l'opération directement

| Handler | Fonction |
|---|---|
| `DemarrerEvolutionHandler` | Ctrl+1 |
| `ParticiperEvolutionHandler` | Ctrl+2 |
| `CreateEvolutionFromExistingHandler` | Ctrl+8 |
| `ConsulterLesSourcesHandler` | Ctrl+9 |
| `MajCopybooksHandler` | Ctrl+4 |
| `GestionComposantsHandler` | Ctrl+5 |
| `GestionDependancesHandler` | Ctrl+7 |
| `BuildAndPushHandler` | Ctrl+0 |
| `DeployHandler` | Ctrl+B (et aussi clic droit : Promote/Clean Unitaire) |
| `AuditHandler` | Ctrl+6 |
| `GitLabTokenHandler` | Ctrl+E |
| `JenkinsTokenHandler` | Ctrl+K |
| `ProxyCdHandler` | *(usage interne)* |

### Opérations longues (Eclipse Jobs)

Les opérations longues (clone, push) utilisent l'API Eclipse Jobs (`org.eclipse.core.runtime.jobs.Job`) pour ne pas bloquer le thread UI :

```java
Job job = new Job("Clonage du dépôt...") {
    @Override
    protected IStatus run(IProgressMonitor monitor) {
        // opération longue ici
        return Status.OK_STATUS;
    }
};
job.setUser(true);  // affiche une boîte de progression
job.schedule();
```

Les classes `*Operation.java` dans `monitors/` encapsulent ces opérations.

---

## Stockage sécurisé des credentials

Le plugin utilise l'**Equinox Secure Storage** d'Eclipse pour stocker les tokens. Les données sont chiffrées par le mécanisme de sécurité du système d'exploitation.

```java
// Stocker
EclipsePluginHelper.storeGitLabTokenSecurely(token);

// Lire
String token = EclipsePluginHelper.retrieveGitLabTokenSecurely();
```

**Clés de stockage :**
- Token GitLab : nœud partagé entre tous les toolchains
- Token Jenkins : nœud par toolchain (ex: `zdevops/prd/jenkins.token`)
- Mot de passe Windows : nœud partagé

---

## Plugin.xml — contributions Eclipse

Le fichier `plugin.xml` déclare toutes les extensions Eclipse :

```xml
<!-- Commandes -->
<extension point="org.eclipse.ui.commands">
  <command id="...DemarrerEvolution" name="Démarrer une évolution"/>
  ...
</extension>

<!-- Raccourcis clavier -->
<extension point="org.eclipse.ui.bindings">
  <key sequence="M1+1" commandId="...DemarrerEvolution" schemeId="...defaultKeyScheme"/>
  ...
</extension>

<!-- Menu zDevOps dans la barre de menus -->
<extension point="org.eclipse.ui.menus">
  <menuContribution locationURI="menu:org.eclipse.ui.main.menu">
    <menu label="zDevOps">
      <command commandId="...DemarrerEvolution"/>
      ...
    </menu>
  </menuContribution>
</extension>

<!-- Vue Jenkins Browser -->
<extension point="org.eclipse.ui.views">
  <view id="JenkinsBrowserView" class="...JenkinsBrowserView"/>
</extension>
```

---

## Listener de changement de manifest

`ManifestFileChangeListener` (implémente `IResourceChangeListener`) surveille les modifications des fichiers `.mf.json` dans le workspace. Il est enregistré au démarrage du plugin via `ResourcesPlugin.getWorkspace().addResourceChangeListener(...)`.

> **Bug connu (M2)** : le listener est créé dans une variable locale dans `Activator.start()`, pas dans le champ d'instance. Il ne peut donc jamais être retiré à l'arrêt du plugin (fuite mémoire). Voir [analyse des erreurs](analyse_erreurs_conception.md).

---

## Points d'attention pour les contributeurs

1. **`AppProperties` est entièrement statique** : impossible à tester unitairement sans modifier les vrais fichiers `.properties`. Solution long terme : introduire une interface `IAppConfig` injectable.

2. **`GitLabService` est un God Object** (~1800 lignes) : toute contribution devrait viser à en extraire des services spécialisés plutôt qu'à y ajouter du code.

3. **Pas de retry réseau** : ni les appels Jenkins ni les opérations JGit ne relancent automatiquement en cas d'erreur réseau transitoire.

4. **Logging incohérent** : mélange de SLF4J, `System.out`, `System.err` et `printStackTrace`. Privilégier exclusivement SLF4J (`LOGGER.info/warn/error`).

5. **Race condition sur `applications.json`** : voir [M1 dans l'analyse des erreurs](analyse_erreurs_conception.md). Le cycle Read→Modify→Write non atomique peut produire des doublons de numéros d'artefact lors de créations simultanées d'évolutions.
