# Fonction 9 — Déployer

**Raccourci clavier :** `Ctrl+B`
**Menu :** zDevOps > Déployer

---

## Contexte et objectif

Le **déploiement** correspond à la phase où les composants compilés sont **promus vers l'environnement cible** (recette, formation, production) en vue d'être testés ou mis en production. Cette fonction déclenche le pipeline Jenkins de déploiement (CD — Continuous Deployment) en passant le nom du manifest de l'évolution courante.

### Quand l'utiliser ?
- Après un build réussi, pour déployer les composants compilés vers l'environnement de recette.
- Pour valider les composants en conditions proches de la production.
- Dans le cadre d'une procédure de mise en production, pour pousser les composants vers l'environnement final.

---

## Concepts clés

### Pipeline Jenkins de déploiement (CD)
Job Jenkins pré-configuré, identifié par la clé `jenkins.pipeline.deploy` dans la configuration du toolchain. Il reçoit le nom du manifest et orchestre le déploiement de l'ensemble des composants de l'évolution vers la plateforme cible.

### Différence Build / Déploiement
- **Builder (Ctrl+0)** : compile les sources, produit des objets binaires (modules charge). Utilise le pipeline `jenkins.pipeline.build`.
- **Déployer (Ctrl+B)** : prend les objets produits par le build et les installe dans l'environnement cible. Utilise le pipeline `jenkins.pipeline.deploy`.

Ces deux étapes sont distinctes et indépendantes dans l'interface, mais dans la pratique un déploiement est précédé d'un build réussi.

### Toolchain
La toolchain détermine l'environnement cible du déploiement. Par exemple :
- `dev` → environnement de développement
- `rec` → recette
- `frm` → formation
- `prd` → production

---

## Prérequis

- Un projet doit être sélectionné dans l'explorateur IDz.
- Le projet doit avoir un manifest unique dans `META-INF/`.
- Le token Jenkins doit être configuré.
- Un build réussi doit avoir été effectué préalablement (vérification non faite par le plugin — responsabilité de l'utilisateur).

---

## Règles métier détaillées

### RG-01 : Vérification du projet courant
Identique à la fonction Builder : le projet actif est identifié via la sélection dans l'explorateur ou le fichier ouvert dans l'éditeur. Si aucun projet, avertissement et annulation.

### RG-02 : Vérification et demande du token Jenkins
Identique à la fonction Builder : si le token est absent, la boîte de saisie s'affiche automatiquement.

### RG-03 : Lecture du manifest courant
Le nom du manifest présent dans `META-INF/` est lu (sans `.mf.json`).

### RG-04 : Déclenchement du pipeline de déploiement
Appel API REST Jenkins avec :
- **Nom du job :** `ProxyCD` (configuré sous la clé `jenkins.pipeline.deploy`)
- **Paramètre :** `NomManifest` = nom du manifest courant

L'appel HTTP est : `POST <jenkins_url>/job/ProxyCD/buildWithParameters?NomManifest=<nom>`

### RG-05 : Suivi de la progression (polling)
Même mécanique que le Builder :
1. Polling de la file d'attente Jenkins toutes les 2 secondes jusqu'au démarrage du build.
2. Polling de `<build_url>/api/json` jusqu'à ce que `building = false`.
3. La vue **Jenkins Blue Ocean** s'ouvre automatiquement dans IDz sur le pipeline `ProxyCD`.

> Quand le job déclenché est `ProxyCD`, la vue Jenkins Browser est affichée en **mode maximisé** (comportement spécifique au déploiement, pour une meilleure lisibilité des logs).

### Infrastructure Jenkins (FabCI)
Le pipeline `ProxyCD` tourne sur FabCI. L'URL dépend du toolchain :

| Toolchain | URL Jenkins |
|---|---|
| `dev` | `https://fabci.ci.lcl.group.gca` |
| `rec` | `https://fabci-rct.ci.lcl.group.gca` |
| `frm` | `https://formation.ci.lcl.group.gca` |
| `prd` | `https://fabci-prd.ci.lcl.group.gca` |

---

## Ce que fait Jenkins côté mainframe (pipeline `ProxyCD`)

### Stage 1 — Init vars
- Récupération du descripteur `.desc.json` depuis Artifactory (feed scratch)
- Parsing du descripteur pour obtenir le `buildNumber`, le `feed`, les infos de déploiement
- Vérification que le site cible (`PROXY_CI_SITE`) est dans la liste des sites de déploiement autorisés
- Détermination de l'`action` à exécuter (paramètre `action` du callback CD)
  - Règle DEVD : si `doAfterMep` reçu sur le site DEVD et que des sites ont déjà une installation en cours → requalifié en `doAfterCascade`

### Stage 2 — Traitements `<action>` (dispatch)
Selon la valeur de `action`, le pipeline dispatche vers la fonction Groovy correspondante :

| Action | Signification | Ce que fait Jenkins |
|---|---|---|
| `doAfterMep` | Installation terminée sur un site | Mise à jour du descripteur, notification, cascade éventuelle |
| `doAfterCascade` | Installation en cascade | Déploiement sur les sites suivants du plan de cascade |
| `doAfterMepApproved` | Installation approuvée | Passage à l'état suivant du workflow |
| `doAfterMepRejected` | Installation rejetée | Rollback ou clôture |
| `doAfterMepCanceled` | Annulation d'installation | Nettoyage et notification |
| `doAfterRollback` | Rollback effectué | Mise à jour descripteur état rollback |
| `doAfterCancelRejected` | Demande d'annulation rejetée | Notification |
| `doWhenExpired` | Demande expirée | Clôture et notification |
| `doAfterFail` | Échec de la CD | Notification d'erreur, mise à jour descripteur |

### Stage 3 — Notification Teams (toujours exécuté)
Quelle que soit l'issue (succès ou erreur), une notification est envoyée dans Teams :
- Téléchargement du template HTML depuis GitLab (`resources/templates/doafter/`)
- Construction du message avec les variables d'environnement (app, version, site, statut)
- Envoi via `NotificationService`

### Stage 4 — Fin Pipeline
- Nettoyage du workspace Jenkins

### Condition préalable indispensable
Le pipeline `ProxyCD` est déclenché par le plugin avec le `NomManifest`. Mais il a besoin que **l'artefact correspondant soit présent dans le feed attendu** (champ `feed` du descripteur). Si l'artefact est absent, Jenkins lève une erreur explicite.

---

## Séquence complète

```
1. L'utilisateur sélectionne son projet (build préalable effectué)
2. Appuie sur Ctrl+B
3. Vérification du token Jenkins
4. Lecture du manifest : "da01_correction_bug_42"
5. Appel API Jenkins :
   POST /job/<pipeline_deploy>/buildWithParameters
   Paramètre : NomManifest=da01_correction_bug_42
6. Suivi jusqu'à la fin du déploiement
7. Résultat affiché
```

---

## Paramètre envoyé à Jenkins

| Nom du paramètre | Valeur |
|---|---|
| `NomManifest` | Nom du manifest sans extension |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Aucun projet sélectionné | "Veuillez sélectionner un projet dans l'explorateur" |
| Token Jenkins absent | Boîte de saisie du token |
| Échec du déploiement | "ERREUR : echec de l'exécution du déploiement" |
