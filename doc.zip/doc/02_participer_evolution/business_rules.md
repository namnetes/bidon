# Fonction 2 — Participer à une évolution

**Raccourci clavier :** `Ctrl+2`
**Menu :** zDevOps > Participer à une évolution

---

## Contexte et objectif

Lorsqu'une évolution (branche `feature_XXX`) a déjà été créée par un collègue ou par soi-même sur un autre poste, cette fonction permet de **rejoindre cette évolution** : elle clone ou met à jour le dépôt localement, bascule sur la bonne branche et synchronise les sources depuis GitLab.

C'est la fonction à utiliser quand :
- Un autre développeur a créé l'évolution et vous devez travailler dessus.
- Vous reprenez du travail sur un poste différent où le projet n'est pas encore présent.
- Vous souhaitez passer d'une branche à une autre sur un dépôt déjà cloné.

---

## Concepts clés

### Évolution existante
Contrairement à la fonction "Démarrer une évolution", ici le nom de l'évolution est **sélectionné dans une liste** des branches déjà présentes dans GitLab pour l'application choisie. L'utilisateur ne crée pas de nouvelle branche.

### Lecture du manifest
Quand l'utilisateur sélectionne une évolution dans la liste, le plugin va **lire le manifest de cette évolution directement dans GitLab** (sans cloner) et affiche automatiquement :
- Le **type de composant** (BATCH ou TP)
- La **description** de l'évolution

Ces deux champs sont en **lecture seule** : ils reflètent ce qui a été défini lors de la création de l'évolution. L'utilisateur ne peut pas les modifier depuis cette fenêtre.

---

## Saisies requises par l'utilisateur

| Champ | Obligatoire | Règles de validation |
|---|---|---|
| **Code de l'application** | Oui | 4 caractères, commence par `da` ou `dy`, doit exister dans GitLab |
| **Nom de l'évolution** | Oui | Sélection dans la liste déroulante (liste chargée depuis GitLab), non vide |

---

## Règles métier détaillées

### RG-01 : Validation du code application
- Format attendu : `da` ou `dy` suivi de 2 caractères alphanumériques → pattern `d[ay][a-z0-9]{2}`.
- L'existence dans GitLab est vérifiée : si le projet n'existe pas, un message d'erreur est affiché et la liste des évolutions reste vide.
- Le champ est coloré en **vert** si valide, **rouge** si invalide.

### RG-02 : Chargement des évolutions disponibles
- Dès que le champ "Code de l'application" perd le focus, le plugin interroge GitLab et charge **toutes les branches** du dépôt dans la liste déroulante.
- La liste est en **lecture seule** (`SWT.READ_ONLY`) : l'utilisateur ne peut que choisir dans la liste, pas taper un nom libre.
- L'autocomplétion est active pour faciliter la recherche dans la liste.

### RG-03 : Affichage automatique des informations de l'évolution
Quand l'utilisateur sélectionne une évolution :
1. Le plugin interroge GitLab pour lire le fichier manifest de cette branche.
2. Il affiche automatiquement le **type de composant** et la **description** en champs grisés (non éditables).
3. Si le manifest est introuvable (branche sans manifest, ex. `master`), les champs restent vides.

### RG-04 : Gestion du dépôt local non existant (cas nominal)
Si le dépôt de l'application n'est pas encore cloné localement :
1. Clone complet du dépôt depuis GitLab depuis `master` (avec barre de progression).
2. Installation des hooks Git (protection de `master`).
3. Création de la branche locale `feature_XXX` depuis `master`.
4. Bascule (`checkout`) sur la branche `feature_XXX`.
5. Pull (mise à jour) de la branche depuis GitLab.
6. Configuration du dépôt Git local.
7. Import du projet dans IDz.

### RG-05 : Gestion du dépôt local existant
Si le dépôt est déjà présent dans le workspace, le plugin propose deux options :

**Option A — Supprimer et recréer**
1. Confirmation de suppression demandée.
2. Le répertoire local est supprimé.
3. La procédure "cas nominal" ci-dessus est appliquée.
4. Message de confirmation.

**Option B — Mettre à jour**
Utilise `participateLocalEvolution` :
1. Bascule directement sur la branche `feature_XXX` dans le dépôt local existant (opération locale uniquement, pas de clone).
2. Pull de la branche depuis GitLab.
3. Configuration du dépôt.
4. Import dans IDz.

> **Différence importante avec Option A :** l'option B est beaucoup plus rapide car elle ne re-clone pas le dépôt. Elle convient quand le dépôt est déjà à jour et qu'on veut juste changer de branche.

### RG-06 : Bouton Reset
Vide les champs (code application, liste des évolutions, type composant, description).

### RG-07 : Bouton Quitter
Ferme la boîte de dialogue sans action.

---

## Séquence complète (cas nominal — dépôt non existant)

```
1. L'utilisateur ouvre la boîte de dialogue (Ctrl+2)
2. Saisit le code application (ex : "da01")
   → La liste des branches est chargée depuis GitLab
3. Sélectionne l'évolution dans la liste (ex : "feature_correction_bug_42")
   → Le manifest est lu : type "BATCH", description affichée
4. Clique sur "Valider"
   → Clone du dépôt da01 depuis GitLab (master)
   → Hooks installés
   → Branche feature_correction_bug_42 créée localement
   → Checkout sur feature_correction_bug_42
   → Pull depuis GitLab
   → Import dans IDz
5. Le projet "da01" apparaît dans l'explorateur IDz sur feature_correction_bug_42
```

---

## Différence avec "Démarrer une évolution"

| | Démarrer | Participer |
|---|---|---|
| Nom de l'évolution | Saisi librement | Choisi dans une liste |
| Branche créée dans GitLab ? | Oui (nouvelle branche) | Non (la branche existe déjà) |
| Manifest créé ? | Oui | Non (manifest déjà existant) |
| Type et description | Saisis par l'utilisateur | Lus depuis le manifest GitLab |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Code application inexistant dans GitLab | "L'application n'existe pas dans GitLab" |
| Aucune évolution sélectionnée | "Le nom de l'évolution est requis" |
| Échec du clone | "Échec de la connexion à l'évolution XXX du dépôt YYY" |
| Impossible de charger les branches | "Impossible de charger la liste des branches" |
