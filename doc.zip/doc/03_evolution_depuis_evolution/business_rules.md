# Fonction 3 — Démarrer une évolution à partir d'une autre

**Raccourci clavier :** `Ctrl+8`
**Menu :** zDevOps > Démarrer une évolution à partir d'une autre

---

## Contexte et objectif

Cette fonction couvre un cas spécifique : une nouvelle évolution doit être démarrée **non pas depuis `master`** (branche principale), mais **depuis une autre évolution déjà en cours**. Autrement dit, la nouvelle évolution a pour point de départ le code d'une branche `feature_XXX` existante plutôt que le code de référence.

### Quand l'utiliser ?
- Quand l'évolution B dépend fonctionnellement de l'évolution A, et qu'A n'est pas encore intégrée en `master`.
- Quand on veut créer une sous-évolution (par exemple une correction urgente dans le périmètre d'une évolution plus large).
- Quand on souhaite brancher à partir d'un état intermédiaire du code, différent de `master`.

---

## Concepts clés

### Évolution de base (branche source)
C'est la branche `feature_XXX` existante depuis laquelle la nouvelle évolution sera créée. Elle est sélectionnée dans une liste déroulante.

### Nouvelle évolution
C'est la branche `feature_YYY` à créer. Le nom est saisi librement (mêmes règles que pour "Démarrer une évolution").

### Relation entre les deux
La nouvelle branche `feature_YYY` est créée **à partir du commit HEAD de `feature_XXX`**, pas de `master`. Cela signifie qu'elle hérite de tous les changements de l'évolution de base.

---

## Saisies requises par l'utilisateur

| Champ | Obligatoire | Règles |
|---|---|---|
| **Code de l'application** | Oui | 4 caractères, commence par `da` ou `dy` |
| **Nom de l'évolution de base** | Oui | Sélection dans la liste déroulante (READ ONLY), non vide |
| **Nom de la nouvelle évolution** | Oui | Alphanumérique + `_`, sans espace, ne commence pas par `feature`, pas déjà existant sous `feature_YYY` |
| **Description** | Oui | Texte libre, non vide |

---

## Règles métier détaillées

### RG-01 : Validation du code application
- Identique à la fonction "Démarrer une évolution" : 4 chars, `da` ou `dy`.
- Coloré en vert si valide, rouge si invalide.
- À la perte de focus, le plugin charge les branches du projet dans GitLab.

### RG-02 : Chargement des évolutions de base disponibles
- Toutes les branches du dépôt sont chargées dans le combo **"Nom de l'évolution de base"** (liste READ ONLY).
- L'utilisateur choisit la branche de départ dans cette liste.

### RG-03 : Chargement des noms disponibles pour la nouvelle évolution
- Quand l'utilisateur sélectionne l'évolution de base, le combo **"Nom de l'évolution"** est alimenté avec les mêmes branches (pour que l'utilisateur puisse voir ce qui existe déjà).
- Le nom de la nouvelle évolution est une saisie libre mais soumise aux mêmes contraintes qu'en fonction 1 : pas de doublon, pas d'espace, pas de préfixe `feature`, caractères alphanumériques + `_` uniquement.

### RG-04 : Construction de la nouvelle branche
Le plugin appelle `manageBranchByBranch` qui effectue les opérations suivantes :
1. Clone du dépôt depuis GitLab.
2. Checkout de l'évolution de base (`feature_XXX`).
3. Création de la nouvelle branche `feature_YYY` depuis `feature_XXX`.
4. Configuration du dépôt local.
5. Import dans IDz.

> **Important :** le manifest de la nouvelle branche `feature_YYY` hérite du contenu du manifest de `feature_XXX`. Il peut ensuite être modifié via la fonction "Gérer les composants du manifest".

### RG-05 : Gestion du dépôt local existant
Même comportement que les autres fonctions d'évolution :
- **Supprimer et recréer :** supprime le dépôt local, puis applique la procédure `createEvolutionFromExisting`.
- **Mettre à jour :** commit la branche courante, bascule sur `master`, met à jour `master`, crée `feature_YYY` depuis `master` (via `updateNewEvolution`).

> **Attention :** en cas de mise à jour, la nouvelle branche est créée depuis `master` et non depuis l'évolution de base. Ce comportement peut sembler incohérent avec l'objectif de la fonction. C'est une limitation connue de l'implémentation actuelle.

### RG-06 : Description
La description est stockée dans le manifest de la nouvelle évolution. Elle est encodée en JSON pour les caractères spéciaux.

---

## Séquence complète (cas nominal)

```
1. L'utilisateur ouvre la boîte de dialogue (Ctrl+8)
2. Saisit le code application (ex : "da01")
   → Toutes les branches de "da01" sont chargées
3. Sélectionne l'évolution de base (ex : "feature_evolution_a")
4. Saisit le nom de la nouvelle évolution (ex : "correction_dans_a")
   → Le plugin vérifie que "feature_correction_dans_a" n'existe pas
5. Saisit une description
6. Clique sur "Valider"
   → Clone du dépôt
   → Checkout de feature_evolution_a
   → Création de feature_correction_dans_a depuis feature_evolution_a
   → Configuration et import dans IDz
7. Confirmation affichée
```

---

## Différence avec "Démarrer une évolution"

| Critère | Démarrer une évolution | Démarrer depuis une autre |
|---|---|---|
| Branche source | `master` | Une branche `feature_XXX` existante |
| Cas d'usage | Démarrer un nouveau sujet | Sous-évolution ou dépendance |
| Nom de branche résultant | `feature_<nom>` | `feature_<nom>` (identique) |
| Manifest initial | Créé depuis zéro | Hérite du manifest de la branche source |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Nom de l'évolution de base non sélectionné | "Le nom de l'évolution est requis" |
| Nouvelle évolution déjà existante | "L'évolution feature_XXX existe déjà dans le dépôt distant" |
| Caractères non autorisés dans le nom | "Seuls les caractères alphanumériques et '_' sont attendus" |
| Échec du clone | "Échec de l'opération de clone du dépôt XXX" |
