# Fonction 4 — Consulter les sources d'un code application

**Raccourci clavier :** `Ctrl+9`
**Menu :** zDevOps > Consulter les sources d'un code application

---

## Contexte et objectif

Cette fonction permet de **consulter les sources d'une application en lecture seule**, sans créer d'évolution ni modifier quoi que ce soit. Elle clone le dépôt GitLab sur la branche `master` (branche de référence, représentant le code officiellement intégré) et l'ouvre dans IDz.

### Quand l'utiliser ?
- Pour lire le code d'une application sans intention de le modifier.
- Pour comprendre comment une application est structurée avant de démarrer une évolution.
- Pour consulter le dernier état intégré d'un programme.
- Pour une revue de code ou une analyse d'impact.

---

## Concepts clés

### Branche `master`
Dans ce contexte, `master` est la branche principale du dépôt GitLab. Elle contient uniquement le code **officiellement intégré et validé**. Aucune évolution en cours n'y est présente.

### Mode lecture seule
Le dépôt est cloné sur `master` et reste sur cette branche. Aucune branche `feature_` n'est créée. Les hooks Git installés protègent `master` contre les commits accidentels.

### `applications.json`
Même contrainte que pour les évolutions : l'application doit être référencée dans ce fichier de référence GitLab, sinon la consultation est refusée.

---

## Saisies requises par l'utilisateur

| Champ | Obligatoire | Règles |
|---|---|---|
| **Code de l'application** | Oui | 4 caractères, commence par `da` ou `dy`, doit exister dans GitLab ET dans `applications.json` |

---

## Règles métier détaillées

### RG-01 : Validation du code application
- Format : `d[ay][a-z0-9]{2}` — 4 caractères commençant par `da` ou `dy`.
- Coloré en **vert** si le projet est trouvé dans GitLab.
- Coloré en **rouge** si le projet est introuvable.
- La validation se déclenche à la perte de focus du champ.

### RG-02 : Double vérification obligatoire
Avant d'agir, le plugin vérifie :
1. Que le code existe dans **GitLab** (projet présent dans le groupe).
2. Que le code est référencé dans le fichier **`applications.json`** (liste des applications autorisées).
Si l'une des deux vérifications échoue, la consultation est bloquée.

### RG-03 : Dépôt non cloné (cas nominal)
1. Clone du dépôt depuis GitLab, branche `master`.
2. Configuration du dépôt local (hooks Git, protection de `master`).
3. Import dans IDz : le projet apparaît dans l'explorateur.

### RG-04 : Dépôt déjà cloné localement
Le plugin détecte que le projet est déjà présent dans le workspace et propose deux options :

**Option A — Supprimer et recréer**
1. Confirmation demandée.
2. Suppression du dépôt local.
3. Nouveau clone depuis GitLab sur `master`.
4. Configuration et import dans IDz.

**Option B — Mettre à jour**
1. Si la branche courante n'est pas `master` : commit automatique des changements en cours, puis bascule sur `master`.
2. Pull (mise à jour) de `master` depuis GitLab.
3. Installation des hooks.
4. Import dans IDz.

> Cette option est particulièrement utile pour rafraîchir le dépôt quand on était sur une évolution et qu'on veut revenir voir le code de référence.

### RG-05 : Absence de création de branche
Contrairement aux fonctions 1, 2 et 3, **aucune branche `feature_`** n'est créée. Le workspace reste sur `master` après l'opération.

---

## Séquence complète (cas nominal)

```
1. L'utilisateur ouvre la boîte de dialogue (Ctrl+9)
2. Saisit le code application (ex : "da01")
   → Le plugin vérifie l'existence dans GitLab et dans applications.json
   → Le champ passe en vert
3. Clique sur "Valider"
   → Clone du dépôt da01 sur master
   → Hooks installés
   → Import dans IDz
4. Le projet "da01" apparaît sur la branche master
5. Le développeur peut lire les sources (pas d'évolution créée)
```

---

## Différence avec "Démarrer/Participer à une évolution"

| Critère | Démarrer / Participer | Consulter les sources |
|---|---|---|
| Branche résultante | `feature_XXX` | `master` |
| Manifest créé ? | Oui | Non |
| Modifiable ? | Oui | Non (protection de master) |
| Usage | Développement | Lecture / analyse |
| Champs requis | Code + nom évolution + description + type | Code uniquement |

---

## Erreurs possibles

| Situation | Message affiché |
|---|---|
| Code non trouvé dans GitLab | "Application inexistante dans GitLab" |
| Code non référencé dans applications.json | "Le code application XXX n'est pas référencé dans le fichier de référence" |
| Code invalide (format incorrect) | "Format attendu : daXX ou dyXX" |
| Échec du clone | "Échec de l'opération de clone du dépôt XXX" |
