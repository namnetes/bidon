# Fonction 7 — Gérer les dépendances du manifest

**Raccourci clavier :** `Ctrl+7`
**Menu :** zDevOps > Gérer les dépendances du manifest

---

## Contexte et objectif

Une évolution peut avoir besoin de **copybooks ou de structures de données** qui sont développés dans une autre évolution, d'une autre application, et qui ne sont pas encore intégrés en `master`. Dans ce cas, il faut déclarer une **dépendance** dans le manifest : cela indique au pipeline de build qu'il doit aller chercher les fichiers nécessaires dans cette autre évolution.

Cette fonction permet de **déclarer, modifier ou supprimer les dépendances** d'une évolution vers d'autres évolutions d'autres applications.

### Quand l'utiliser ?
- Quand votre application utilise un copybook développé dans une autre application, dont la version en cours de développement n'est pas encore en `master`.
- Quand le build Jenkins remonte une erreur de copybook non trouvé.
- Quand la liste des dépendances doit être mise à jour suite à la livraison d'une évolution dépendante.

---

## Concepts clés

### Dépendance
Une dépendance est un lien vers une **branche d'évolution d'une autre application**. Elle est stockée dans le manifest sous la forme du **nom du fichier manifest** de la branche dépendante (ex : `da02_evolution_partagee`), pas directement le nom de la branche.

### Nom de manifest vs nom de branche
- Nom de branche dans GitLab : `feature_evolution_partagee`
- Nom du manifest correspondant : `da02_evolution_partagee`

Le plugin fait la correspondance automatiquement : quand l'utilisateur coche une branche, le plugin interroge GitLab pour récupérer le nom du manifest de cette branche, et c'est ce nom qui est enregistré dans les dépendances.

### Impact sur la MAJ des copybooks
Quand la fonction "Mettre à jour les copybooks" est exécutée, elle lit les dépendances du manifest et va télécharger les copybooks de type `.cpy`, `.dcl`, `.in2` des évolutions dépendantes dans le répertoire `dex_read_only/`.

---

## Prérequis

- Un projet doit être sélectionné dans l'explorateur IDz.
- Le projet doit contenir un fichier manifest unique dans `META-INF/`.
- Le token GitLab doit être configuré.

---

## Règles métier détaillées

### RG-01 : Lecture du manifest et pré-chargement des dépendances existantes
À l'ouverture de la boîte de dialogue :
1. Le manifest du projet actif est lu.
2. Les métadonnées (code application, objet, nom évolution, type composant, type application, description) sont affichées en **lecture seule**.
3. La liste des dépendances **déjà déclarées** est mémorisée pour pré-cocher les branches correspondantes quand l'utilisateur navigue dans l'arbre.

### RG-02 : Recherche d'une application à lier
Le champ de filtre/recherche (zone droite) sert à chercher l'application dont on veut déclarer une dépendance. Les règles sont :
- La saisie doit être exactement **4 caractères**.
- Le code doit commencer par `da` ou `dy`.
- Dès que ces conditions sont réunies, le chargement des branches est déclenché automatiquement.

### RG-03 : Chargement asynchrone des branches
La recherche des branches d'une application dans GitLab est effectuée **en arrière-plan** (Job Eclipse) pour ne pas bloquer l'interface. Pendant le chargement :
- Un message "Le chargement des branches est en cours..." est affiché en rouge dans l'en-tête.
- L'arbre est vide.

Quand le chargement est terminé :
- L'arbre affiche le projet et toutes ses branches.
- Les branches déjà déclarées en dépendance sont **pré-cochées**.
- La branche courante du projet actif est **exclue** de la liste (on ne peut pas se déclarer dépendant de sa propre branche).

### RG-04 : Sélection des branches dépendantes
L'utilisateur **coche** les branches de l'application trouvée dont il veut dépendre. Pour chaque branche cochée :
1. Le plugin interroge GitLab pour récupérer le **nom du fichier manifest** de cette branche.
2. Ce nom est ajouté à l'ensemble `branchsSelected`.
3. La zone de résumé en bas de la boîte est mise à jour en temps réel.

Pour chaque branche décochée, le nom du manifest correspondant est **retiré** de l'ensemble.

### RG-05 : Zone de résumé des dépendances
Un label en bas de la boîte affiche en permanence la liste des dépendances sélectionnées :
```
dépendances = [da02_evolution_partagee, da03_autre_dep]
```
Si aucune dépendance n'est sélectionnée :
```
dépendances = []
```

### RG-06 : Validation et sauvegarde
Quand l'utilisateur clique sur **"Valider"** :
1. La liste `branchsSelected` (noms de manifests) est écrite dans le champ `dependancies` du manifest.
2. Le manifest est réécrit sur le disque.
3. Le projet IDz est rafraîchi.

Si aucune dépendance n'est sélectionnée, `dependancies` est réinitialisé à `[""]` (liste avec une chaîne vide, convention du système).

### RG-07 : Bouton Reset du filtre
Vide le champ de recherche et efface l'arbre. Le message d'information initial est rétabli.

### RG-08 : Bouton Valider désactivé
Si la saisie dans le champ de filtre ne correspond pas à un code application valide (4 chars, `da`/`dy`), le bouton "Valider" est désactivé pour éviter une sauvegarde incohérente.

---

## Structure des dépendances dans le manifest

```json
{
  "dependancies": [
    "da02_evolution_partagee",
    "da03_autre_dependance"
  ]
}
```

Le format d'une dépendance est : `<code_application>_<nom_evolution>`.
Cette information correspond au `manifest_name` de l'évolution dépendante, tel que lu dans son fichier `.mf.json`.

---

## Séquence complète

```
1. L'utilisateur ouvre la boîte de dialogue (Ctrl+7)
   → Manifest du projet courant chargé
   → Dépendances existantes mémorisées
2. Saisit "da02" dans le champ de filtre
   → Les branches de da02 sont chargées (en arrière-plan)
   → L'arbre affiche da02 et ses branches
   → Les branches déjà déclarées sont pré-cochées
3. Coche "feature_evolution_partagee"
   → Le plugin récupère le manifest name : "da02_evolution_partagee"
   → Résumé : dépendances = [da02_evolution_partagee]
4. Clique sur "Valider"
   → Le manifest est mis à jour avec dependancies: ["da02_evolution_partagee"]
   → Le projet IDz est rafraîchi
```

---

## Erreurs possibles

| Situation | Comportement |
|---|---|
| Code application invalide (format) | Message d'erreur en rouge, arbre vide, bouton Valider désactivé |
| Application non trouvée dans GitLab | Arbre vide, message d'erreur |
| Manifest de la branche non trouvé | La branche n'est pas ajoutée aux dépendances |
| Erreur de chargement des branches | "Impossible de charger la liste des branches" |
| Erreur d'écriture du manifest | Message d'avertissement |
