# Glossaire zDevOps — Termes et concepts

Ce glossaire explique tous les termes techniques du monde mainframe et de la plateforme zDevOps.  
Il est destiné aux débutants et à toute personne qui n'est pas familière avec l'univers IBM z/OS.

---

## A

### API REST
Interface de communication entre logiciels via le protocole HTTP. Le plugin communique avec GitLab et Jenkins exclusivement via leurs API REST : il envoie des requêtes HTTP et reçoit des réponses en JSON.

### applications.json
Fichier de référence hébergé dans GitLab (dépôt `app.params`). Il liste toutes les applications mainframe autorisées dans le système zDevOps, avec leur code, leur type et leur numéro d'artefact suivant. Consulté par le plugin à chaque création d'évolution pour vérifier que l'application est autorisée.

### Artefact
Résultat d'une compilation : le fichier `.tar` produit par le pipeline `BuildAndPush` et stocké dans Artifactory. Il contient les modules charge (binaires z/OS) et les métadonnées du build.

### Artifactory (JFrog)
Entrepôt d'artefacts centralisé. Stocke les `.tar` produits par les builds. Organisé en trois feeds :
- **scratch** : artefacts produits par le build, non encore validés
- **staging** : artefacts en cours de recette
- **stable** : artefacts validés, prêts pour la production

### Assembleur (ASM)
Langage de programmation de très bas niveau pour mainframe z/OS. Les sources assembleur ont l'extension `.asm` et se trouvent dans le répertoire `asm/` du projet.

### Audit qualité
Analyse automatique du code source d'une évolution pour détecter des anomalies (normes, métriques, copybooks). Déclenché par la fonction **Audit (Ctrl+6)** via le pipeline Jenkins `auditEtQualite`.

---

## B

### BATCH
Type d'application mainframe qui s'exécute de façon différée, généralement la nuit (traitements en masse, calculs). Les applications BATCH ont un code commençant par `da`. Elles utilisent principalement le répertoire `src/` (programmes COBOL) et `skl/` (squelettes JCL).

### BGB (Background Batch)
Type de module charge (objet compilé) pour les programmes COBOL BATCH. Un programme COBOL en `src/` produit lors du build : `LOD` (module charge principal), `BGB` (module batch de débogage) et optionnellement `DBR` (module DBRM pour DB2).

### BGT (Background Transaction)
Équivalent du BGB pour les programmes TP (CICS). Un programme COBOL en `srt/` produit : `LOT`, `BGT`, et optionnellement `DBR`.

### Blue Ocean
Interface graphique moderne de Jenkins pour visualiser l'exécution des pipelines. Le plugin ouvre automatiquement la vue Blue Ocean dans IDz dès qu'un job Jenkins démarre.

### Build
Étape de **compilation et d'assemblage** des programmes sources. Dans zDevOps, le build est effectué par IBM DBB/zAppBuild sur le mainframe z/OS. Le plugin déclenche le build via la fonction **Builder (Ctrl+0)**.

### BuildAndPush
Pipeline Jenkins qui orchestre le build complet : clone du dépôt sur z/OS USS → compilation par DBB → analyse SonarQube → création du TAR → envoi vers Artifactory scratch.

---

## C

### CICS (Customer Information Control System)
Moniteur transactionnel IBM sur mainframe z/OS. Les programmes TP tournent dans CICS. Lors d'un déploiement de programme TP, un **phasein** doit être effectué dans le(s) CICS concerné(s) pour recharger le nouveau module.

### Clean Unitaire
Opération qui **retire** un composant de l'environnement TU (annule un Promote Unitaire). Déclenché par clic droit sur un fichier dans IDz, il appelle le pipeline Jenkins `CleanUnitaire`.

### COBOL
Principal langage de programmation mainframe. Les sources COBOL ont les extensions `.cbl` ou `.cob` et se trouvent dans `src/` (BATCH) ou `srt/` (TP). C'est le langage le plus répandu dans les applications LCL.

### Code application
Identifiant de 4 caractères d'une application mainframe. Convention :
- `daXX` → application **BATCH** (ex: `da01`, `daab`)
- `dyXX` → application **TP / CICS** (ex: `dy01`, `dyxz`)

### Copybook (COPY / CPY)
Fichier de définitions partagées utilisé par les programmes COBOL via l'instruction `COPY <nom>` ou `EXEC SQL INCLUDE <nom>`. Équivalent d'un fichier d'en-tête (`#include`) en C/C++. Les copybooks sont dans les répertoires `cpy/` (copybooks COBOL), `dcl/` (déclarations DB2), `in2/` (includes niveau 2).

### Couloir
Circuit de promotion d'un composant vers un environnement cible. Déterminé par le type d'application :
- Application `STD` → couloir `STDA`
- Application `CRF` → couloir `CRFA`
- Autre type → le type lui-même

Le couloir conditionne les PDS cibles dans lesquels les objets compilés sont copiés.

---

## D

### DA / DA (code application)
Voir **Code application**. `da` = BATCH.

### DB2
Système de gestion de base de données relationnelle IBM sur mainframe z/OS. Les programmes COBOL qui accèdent à DB2 via SQL embarqué produisent un **DBRM** lors de la compilation, qui doit être **BIND** pour créer un plan d'exécution.

### DBB (IBM Dependency Based Build)
Outil IBM qui effectue la **compilation** des programmes mainframe sur z/OS Unix System Services (USS). Il gère les dépendances entre fichiers (copybooks, includes), détermine ce qui doit être recompilé, et produit les modules charge.

### DBRM (Database Request Module)
Objet produit lors de la compilation d'un programme COBOL DB2. Contient les requêtes SQL pré-compilées. Doit être bindé (voir **BIND**) pour être exécutable.

### DCL
Répertoire contenant les déclarations SQL DB2 (fichiers `.dcl`). Ces fichiers sont des copybooks spéciaux pour DB2.

### DEX / dex_read_only
Répertoire local dans le projet IDz contenant les **copybooks externes** téléchargés depuis GitLab. Il est entièrement géré par le plugin (vidé et recréé à chaque exécution de la fonction **Mettre à jour les copybooks**). Ne pas modifier son contenu manuellement.

### Descripteur (descriptor / `.desc.json`)
Fichier JSON produit après un build réussi et stocké dans Artifactory. Étend le manifest avec les informations de build : numéro de build, feed de stockage, tag Git, état du déploiement par site, résultats d'audit.

### DY (code application)
Voir **Code application**. `dy` = TP (transactionnel CICS).

---

## E

### Environnement
Dans zDevOps, les environnements sont : **TU** (Test Unitaire), **CQ** (Contrôle Qualité), **IL** (Intégration et Liaison), **PU** (Pré-Unification), puis les environnements de production (**DEVD**, **X000**, **X00Y**, **LIME**, etc.).

### Équinox Secure Storage (Eclipse)
Coffre-fort chiffré fourni par Eclipse (OSGi Equinox) pour stocker des données sensibles (tokens, mots de passe). Le plugin l'utilise pour stocker les tokens GitLab et Jenkins. Les données ne sont jamais stockées en clair.

### Évolution
Unité de travail d'un développeur. Matérialisée par une branche Git `feature_<nom>` dans GitLab. Une évolution a un manifest, une liste de composants, et un cycle de vie (build → audit → déploiement → mise en production).

---

## F

### FabCI
Infrastructure Jenkins interne LCL. Il existe une instance par toolchain :
- `dev` → `https://fabci.ci.lcl.group.gca`
- `rec` → `https://fabci-rct.ci.lcl.group.gca`
- `frm` → `https://formation.ci.lcl.group.gca`
- `prd` → `https://fabci-prd.ci.lcl.group.gca`

### Feature branch
Voir **Évolution**. Dans Git, une branche de fonctionnalité nommée `feature_<nom>`.

### Feed
Dans Artifactory, un feed est un espace de stockage d'artefacts. zDevOps utilise trois feeds pour le cycle de vie des artefacts :
- **scratch** : après le build (non validé)
- **staging** : après promotion en recette
- **stable** : artefact validé pour la production

---

## G

### Git
Système de gestion de version utilisé pour stocker les sources mainframe. Chaque application a son propre dépôt Git dans GitLab.

### GitLab
Plateforme web qui héberge les dépôts Git des applications mainframe. URL interne : `scm.saas.cagip.group.gca`. Le plugin utilise son API REST pour créer des branches, lire des fichiers, gérer les manifests.

### gitlab4j
Bibliothèque Java qui simplifie les appels à l'API REST GitLab. Utilisée par le plugin pour toutes les interactions GitLab (dans `GitLabService.java`).

---

## H

### HLQ (High Level Qualifier)
Préfixe des noms de fichiers z/OS (les PDS). Sur mainframe, les fichiers sont nommés `HLQ.SOUS_QUALIFICATIF.NOM_MEMBRE`. Le HLQ identifie l'environnement ou l'application.

### Hooks Git
Scripts exécutés automatiquement par Git avant ou après certaines opérations (commit, push). Le plugin installe des hooks sur les dépôts locaux pour protéger la branche `master` contre les modifications accidentelles.

---

## I

### IBM Developer for z/OS (IDz)
L'IDE (environnement de développement) utilisé par les développeurs mainframe LCL. Basé sur Eclipse, il intègre un éditeur COBOL, un explorateur de projet, des vues dédiées mainframe. Le plugin zDevOps s'y intègre sous forme d'extension Eclipse.

### IN2 (includes niveau 2)
Répertoire contenant des fichiers d'include de deuxième niveau (`.in2`). Utilisés dans les programmes COBOL qui nécessitent des inclusions imbriquées.

---

## J

### JCL (Job Control Language)
Langage de commande du mainframe z/OS. Un JCL décrit comment exécuter un programme : quelle bibliothèque (PDS) utiliser, quels fichiers en entrée/sortie, quel programme lancer. Les pipelines PromoteUnitaire et CleanUnitaire **génèrent des JCL dynamiquement** et les soumettent au z/OS.

### Jenkins
Serveur d'automatisation qui exécute les pipelines CI/CD. Dans zDevOps, Jenkins s'appelle **FabCI**. Les pipelines sont écrits en Groovy (Jenkinsfiles).

### JGit
Implémentation Java de Git (bibliothèque pure Java). Le plugin utilise JGit pour toutes les opérations Git locales : clone, commit, push, pull, checkout — sans subprocess ni appel à la commande `git`.

---

## L

### Link-Edit (Link)
Étape après la compilation COBOL : elle assemble les modules compilés (`.obj`) en un **module charge** exécutable (load module). Produit les types LOD (BATCH) ou LOT (TP).

### LOD (Load module)
Module charge BATCH produit par le link-edit d'un programme COBOL BATCH. C'est le fichier exécutable final.

### LOT (Load Transaction)
Module charge TP/CICS produit par le link-edit d'un programme COBOL TP.

---

## M

### Manifest (`.mf.json`)
Fichier JSON situé dans `META-INF/` de chaque projet. Décrit une évolution : code application, type de composant, description, liste des fichiers à compiler (`content`), dépendances vers d'autres évolutions. C'est le "bon de commande" envoyé à Jenkins pour compiler.

### Master
Branche principale du dépôt Git d'une application. Elle contient le **code officiellement intégré et validé**. On ne développe jamais directement sur master : tout développement se fait sur une branche `feature_`.

### META-INF/
Répertoire dans chaque projet IDz contenant :
- Le fichier manifest (`.mf.json`)
- Les fichiers de rapport copybooks générés par la fonction MAJ copybooks
- Le fichier `zapp.yaml` (configuration zAppBuild)

### Module charge
Fichier binaire exécutable sur z/OS, résultat de la compilation et du link-edit d'un programme source. Stocké dans un PDS de type load library (`.LOADLIB`).

### MSK (Masque)
Type de composant pour les applications TP : fichiers de définition d'écran CICS (masques BMS compilés). Dans `msk/`.

---

## P

### Phasein
Opération qui recharge un module charge dans le moniteur transactionnel CICS sans arrêter les transactions en cours. Indispensable après le déploiement d'un programme TP pour que CICS utilise la nouvelle version.

### Pipeline
Séquence d'étapes automatisées dans Jenkins. Dans zDevOps les pipelines principaux sont :
- `BuildAndPush` : compile et archive
- `ProxyCD` : orchestre le déploiement
- `auditEtQualite` : analyse qualité
- `PromoteUnitaire` : déploiement unitaire TU
- `CleanUnitaire` : nettoyage unitaire TU

### PDS (Partitioned Data Set)
Fichier z/OS contenant plusieurs membres, analogue à un répertoire avec des fichiers à l'intérieur. Les programmes sources, les modules charge, les JCL sont tous stockés dans des PDS sur le mainframe.

### PL/I (Programming Language One)
Langage de programmation mainframe IBM. Les sources PL/I ont l'extension `.pli`.

### Promote
Déplacer un artefact d'un feed Artifactory vers un feed de niveau supérieur (scratch → staging → stable), ou déployer un composant vers un environnement cible.

### Promote Unitaire
Voir **Promote Unitaire** dans les fonctions. Déploie un **seul** composant dans l'environnement TU pour test rapide.

### ProxyCD
Pipeline Jenkins qui transmet la demande de déploiement au service CD de CAGIP. Orchestre les installations sur les environnements de production.

---

## R

### REXX
Langage de script mainframe z/OS. Les sources REXX se trouvent dans `srx/`.

---

## S

### Site de déploiement
Environnement de production z/OS cible. Dans zDevOps les sites sont : `DEVIPROD`, `DEVD`, `LIME`, `X000`, `X00Y` (pilote), `SNEP`. Les environnements pré-production sont : `DEV`, `REC`, `PPR4`, `ASS1`, `PCERT`.

### SonarQube
Outil d'analyse statique de code. Dans zDevOps, il analyse les sources COBOL et PL/I pour détecter des problèmes de qualité, de sécurité et de conformité. La **quality gate** doit être passée avant qu'un artefact puisse être promu.

### SPN (Spanning)
Type de composant pour des programmes qui font du "spanning" (spanning = enchevêtrement de modules). Stockés dans `spn/`.

### Stockage sécurisé Eclipse
Voir **Equinox Secure Storage**.

---

## T

### Token (Personal Access Token)
Clé d'identification personnelle générée depuis l'interface d'un service (GitLab ou Jenkins). Remplace le mot de passe pour les accès programmatiques. À ne jamais partager.

### Toolchain
L'environnement CI/CD actif, déterminé par `zdevops.ini`. Chaque toolchain a sa propre instance GitLab (groupes), Jenkins et ses propres paramètres. Valeurs : `dev`, `rec`, `frm`, `prd`.

### TP (Transactionnel)
Type d'application mainframe qui s'exécute en temps réel, gérée par le moniteur CICS. Les applications TP ont un code commençant par `dy`.

### TU (Test Unitaire)
Premier environnement de test, dédié aux tests individuels d'un développeur. C'est l'environnement cible du Promote Unitaire et du Clean Unitaire.

---

## U

### USS (Unix System Services)
Couche Unix intégrée au mainframe z/OS. IBM DBB et zAppBuild s'exécutent dans USS. Les fichiers sources Git sont clonés dans USS pour être compilés.

---

## V

### Version (manifest_number)
Numéro unique attribué à chaque évolution lors de sa création. Format typique : date + séquence (ex: `20250401-001`). Ce numéro identifie l'évolution dans Jenkins et Artifactory.

---

## W

### Workspace Eclipse
Répertoire local sur le poste du développeur où Eclipse (IDz) stocke les projets. Le fichier `zdevops.ini` doit être à la racine de ce workspace.

---

## Z

### zAppBuild
Framework de build open source IBM (GitHub `IBM/dbb-zappbuild`). Contient les scripts Groovy pour compiler chaque type de langage mainframe (COBOL, PL/I, Assembleur, REXX, BMS…). Appelé par Jenkins lors du pipeline `BuildAndPush`.

### zDevOps.ini
Fichier de configuration du plugin, à placer à la racine du workspace Eclipse. Contient au minimum :
```
zdevops.toolchain=prd
```

### z/OS
Système d'exploitation mainframe d'IBM. Environnement dans lequel tournent toutes les applications LCL mainframe. La compilation et l'exécution des programmes se font exclusivement sur z/OS.
