# Documentation du plugin zDevOps IDz

> ## ⚠ Statut : DÉPRÉCIÉ
>
> **Le plugin Eclipse IDz est abandonné** au profit de la combinaison :
> - **VS Code** — éditeur de sources mainframe
> - **zDevOps TUI** — interface terminal remplaçant toutes les fonctions CI/CD du plugin
>
> Ce plugin ne reçoit plus de nouvelles fonctionnalités.
> La documentation ci-dessous est conservée à titre de **référence historique**
> et pour documenter le comportement attendu de la TUI de remplacement.
>
> → Voir le projet de remplacement : `zdevops-tui/`

Bienvenue dans la documentation complète du **plugin zDevOps** pour IBM Developer for z/OS (IDz).

Ce plugin est un **outil de développement** qui permet aux développeurs mainframe LCL de gérer l'intégralité de leur cycle de développement — depuis la création d'une branche de travail jusqu'au déclenchement de la compilation et du déploiement — **sans quitter leur IDE**.

> **Vous débutez ?** Commencez par lire le [glossaire](glossaire.md) pour comprendre les termes techniques, puis le [flux complet](flux_complet.md) pour avoir une vue d'ensemble du parcours de développement.

---

## Qu'est-ce que zDevOps ?

**zDevOps** est la plateforme de CI/CD (intégration et déploiement continus) de LCL pour les applications mainframe IBM z/OS. Elle repose sur :

- **GitLab** : le gestionnaire de code source (où sont stockés les programmes COBOL, PL/I, Assembler…)
- **Jenkins / FabCI** : le serveur d'automatisation qui compile, teste et déploie les programmes
- **IBM DBB** : l'outil IBM qui effectue la compilation sur le mainframe z/OS
- **JFrog Artifactory** : l'entrepôt d'artefacts (binaires compilés)
- **SonarQube** : l'outil d'analyse de qualité du code

Le **plugin IDz** est le point d'entrée de tout ce système pour le développeur : il orchestre les interactions entre l'IDE, GitLab et Jenkins.

---

## Architecture en un coup d'œil

```
┌─────────────────────────────────────────────────────────────────┐
│                    Poste du développeur (Windows)               │
│                                                                 │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │         IDz (Eclipse)  +  Plugin zDevOps                 │   │
│  │                                                          │   │
│  │  • Crée/gère les branches Git (GitLab)                   │   │
│  │  • Édite les sources COBOL/PL/I/ASM                      │   │
│  │  • Gère le manifest (liste des fichiers à compiler)      │   │
│  │  • Déclenche les pipelines Jenkins via API REST           │   │
│  │  • Affiche les logs Jenkins en temps réel (Blue Ocean)   │   │
│  └──────────────────────────────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────────────┘
                     │ HTTPS
         ┌───────────┴───────────┐
         │                       │
         ▼                       ▼
  ┌─────────────┐        ┌──────────────┐
  │   GitLab    │        │   Jenkins    │
  │  (FabCI)    │        │  (FabCI-PRD) │
  │             │        │              │
  │  Dépôts Git │        │  Pipelines : │
  │  des applis │        │  BuildAndPush│
  │  Manifests  │        │  ProxyCD     │
  │  Copybooks  │        │  Promote     │
  └─────────────┘        └──────┬───────┘
                                │
                                ▼
                        ┌──────────────┐
                        │  Mainframe   │
                        │   z/OS USS   │
                        │              │
                        │  DBB/zApp    │
                        │  Compile     │
                        │  COBOL/PLI   │
                        │  Déploie PDS │
                        └──────────────┘
```

---

## Table des matières

### Prise en main
- [Glossaire](glossaire.md) — tous les termes techniques expliqués pour les débutants
- [Flux complet de développement](flux_complet.md) — du code à la production, étape par étape
- [Architecture technique du plugin](architecture_technique.md) — pour les développeurs du plugin

### Fonctions du plugin (par menu `zDevOps`)

| N° | Fonction | Raccourci | Description courte |
|---|---|---|---|
| 1 | [Démarrer une évolution](01_demarrer_evolution/business_rules.md) | `Ctrl+1` | Crée une nouvelle branche de développement |
| 2 | [Participer à une évolution](02_participer_evolution/business_rules.md) | `Ctrl+2` | Rejoindre une branche existante |
| 3 | [Évolution depuis une évolution](03_evolution_depuis_evolution/business_rules.md) | `Ctrl+8` | Créer une sous-branche depuis une branche existante |
| 4 | [Consulter les sources](04_consulter_sources/business_rules.md) | `Ctrl+9` | Lire le code en lecture seule (branche master) |
| 5 | [Mettre à jour les copybooks](05_maj_copybooks/business_rules.md) | `Ctrl+4` | Synchroniser les fichiers COBOL partagés |
| 6 | [Gérer les composants du manifest](06_gestion_composants_manifest/business_rules.md) | `Ctrl+5` | Choisir les fichiers à compiler |
| 7 | [Gérer les dépendances du manifest](07_gestion_dependances_manifest/business_rules.md) | `Ctrl+7` | Déclarer les dépendances sur d'autres évolutions |
| 8 | [Builder](08_builder/business_rules.md) | `Ctrl+0` | Compiler les sources via Jenkins |
| 9 | [Déployer](09_deployer/business_rules.md) | `Ctrl+B` | Déployer vers l'environnement cible via Jenkins |
| 10 | [Audit](10_audit/business_rules.md) | `Ctrl+6` | Analyser la qualité du code via Jenkins |
| 11 | [Promote Unitaire](11_promote_unitaire/business_rules.md) | Clic droit | Promouvoir un seul composant en environnement TU |
| 12 | [Clean Unitaire](12_clean_unitaire/business_rules.md) | Clic droit | Retirer un composant de l'environnement TU |
| 13 | [GitLab Token](13_gitlab_token/business_rules.md) | `Ctrl+E` | Configurer son token d'accès GitLab |
| 14 | [Jenkins Token](14_jenkins_token/business_rules.md) | `Ctrl+K` | Configurer son token d'accès Jenkins |

### Référence technique
- [Interface plugin ↔ Jenkins/GitLab](interface_plugin_jenkins.md) — contrats d'interface exhaustifs : appels HTTP exacts, paramètres, réponses, comportements
- [Infrastructure Jenkins FabCI](infrastructure_jenkins.md) — pipelines, stages, codes retour, configuration par toolchain

### Analyse critique
- [Vue d'ensemble de l'analyse](analyse/README.md) — tableau de synthèse de tous les risques
- [Bugs avérés](analyse/bugs_averes.md) — M1–M5 (critiques) et m1–m5 (mineurs) avec preuves et corrections
- [Questions d'architecture](analyse/questions_architecture.md) — dettes techniques, choix discutables, zones d'ombre (A1–A13)
- [Risques de sécurité](analyse/risques_securite.md) — risques spécifiques à un SI bancaire critique (S1–S6)
- [Risques processus CI/CD](analyse/risques_processus.md) — fragilités dans la chaîne de déploiement mainframe (P1–P9)

---

## Prérequis pour utiliser le plugin

### Logiciels
- **IBM Developer for z/OS (IDz)** version 16 ou supérieure (basé sur Eclipse 4.x)
- **Java 17** (fourni avec IDz)
- Accès réseau interne LCL (VPN si travail à distance)

### Accès et droits
- Un compte **GitLab** (`scm.saas.cagip.group.gca`) avec droits Developer sur votre groupe d'application
- Un compte **Jenkins** (FabCI) avec droits de déclenchement sur les pipelines

### Configuration minimale
1. Le fichier `zdevops.ini` doit exister à la racine du **workspace Eclipse** avec au minimum :
   ```
   zdevops.toolchain=prd
   ```
   Valeurs possibles : `dev`, `rec`, `frm`, `prd`.

2. Configurer le **token GitLab** (voir [Fonction 13](13_gitlab_token/business_rules.md))
3. Configurer le **token Jenkins** (voir [Fonction 14](14_jenkins_token/business_rules.md))

---

## Premier démarrage — en 5 étapes

```
Étape 1 — Installer le plugin dans IDz
   Help > Install New Software > Site p2 zDevOps

Étape 2 — Créer zdevops.ini à la racine du workspace
   Contenu minimal : zdevops.toolchain=prd

Étape 3 — Configurer le token GitLab (Ctrl+E)
   Saisir votre Personal Access Token GitLab

Étape 4 — Configurer le token Jenkins (Ctrl+K)
   Saisir votre API Token Jenkins

Étape 5 — Démarrer votre première évolution (Ctrl+1)
   Saisir le code de votre application (ex: da01)
```

---

## Où trouver de l'aide ?

- **Jira** : tickets zDevOps — `https://jira.fr.cly:8443/browse/ZDO-XXXX`
- **Source du plugin** : `https://scm.saas.cagip.group.gca/fr.lcl.zdevops/dev/plugins_idz`
- **Responsables** : Équipe zDevOps LCL
